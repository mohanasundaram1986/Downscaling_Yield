library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)
library(ncdf4)

library(raster)
library(gstat)
library(sp)

setwd('G:/OneDrive/AIT/papers/workspace/')
TEMP = "G:/OneDrive/AIT/papers/workspace"
tempdir()
# setwd('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5_p1_n1.RData')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_2.RData')
# basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3.shp")
# # basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s1_n4.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")


basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia5.shp")
basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia4.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s2.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s4.shp")
# basin10 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s10.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_seg_sw.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")
sea = readOGR("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/gis/sea_count_sa.shp")
# fishnet1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2_df <- fortify(fishnet2)

sam <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")

basin_p=basin
basin_p1=basin1
basin_p2=basin2
basin_p3=basin3
basin_p4=basin4
basin_p10=basin10
plot(basin_p2)

yld_corr = read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")
yld_cr1 = read_excel("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_comp1.xlsx","mean")
yld_cr3 = read_excel("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_comp1.xlsx","max")

# p1 <- "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model_et/"
# R1 <- list.files(p1, pattern = "tif$",full.names = TRUE)


y2000 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2000.tif")

y2001 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2001.tif")
y2002 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2002.tif")
y2003 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2003.tif")
y2004 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2004.tif")
y2005 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2005.tif")
y2006 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2006.tif")
y2007 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2007.tif")
y2008 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2008.tif")
y2009 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2009.tif")
y2010 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2010.tif")
y2011 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2011.tif")
y2012 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2012.tif")
y2013 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2013.tif")
y2014 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2014.tif")
y2015 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/mode_cwu/cwu_2015.tif")

plot(y2003)

p1 <- "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/data/gdhy_v1.2_v1.3_20190128/rice_major/New folder/"
R1 <- list.files(p1, pattern = "tif$",full.names = TRUE)

g_yld<- stack(R1)
g_yld1 = crop(g_yld,sea)

p2 = "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/data/india_yield/ras/"
R2 <- list.files(p2, pattern = "tif$",full.names = TRUE)
i_yld<- stack(R2)

p3 <- "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model_et/"
R3 <- list.files(p1, pattern = "tif$",full.names = TRUE)
et_s<- stack(R3)

# i_yld1 = crop(i_yld,sea)

plot(i_yld[[2]])
plot(sea, add=T)

plot(y2000_m)
plot(sea, add=T)
# plot(g_yld1[[5]])



# p1 <- "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/data/aphrodite/data/"
# R1 <- list.files(p1, pattern = "nc$")
# 
# ap_rain <- raster::stack(file.path(p1, R1), varname = "precip")
# 

#rmse
# yld_corr1 = data.frame(yld_corr)
yld_cr2 = data.frame(yld_cr1)
yld_cr4 = data.frame(yld_cr3)

rind = rep(1:16,each=4)
cind = seq(1,128, by =2)
rmse = matrix(data= NA, ncol=4, nrow=16)
mad = matrix(data= NA, ncol=4, nrow=16)
cor1 = matrix(data= NA, ncol=4, nrow=16)
mae = matrix(data= NA, ncol=4, nrow=16)

rmse1 = matrix(data= NA, ncol=4, nrow=16)
mad1 = matrix(data= NA, ncol=4, nrow=16)
# cor1 = matrix(data= NA, ncol=4, nrow=16)
mae1 = matrix(data= NA, ncol=4, nrow=16)


for (i in 1:length(rind)){
  
    if (cind[i]%%8 ==1){
      rmse[rind[i],1] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],1] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      mae[rind[i],1] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      # mean(abs((y_actual-y_predict)/y_actual))*100
      rmse1[rind[i],1] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],1] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],1] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
      # cor1[rind[i],1] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
    }
    if (cind[i]%%8 ==3){
      rmse[rind[i],2] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],2] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      cor1[rind[i],2] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
      mae[rind[i],2] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      
      rmse1[rind[i],2] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],2] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],2] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
    }
    if (cind[i]%%8 ==5){
      rmse[rind[i],3] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],3] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      cor1[rind[i],3] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
      mae[rind[i],3] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      
      rmse1[rind[i],3] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],3] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],3] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
    }
    if (cind[i]%%8 ==7){
      rmse[rind[i],4] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],4] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      cor1[rind[i],4] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
      mae[rind[i],4] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      
      rmse1[rind[i],4] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],4] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],4] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
    }

  
}

mad
mad1
rmse
rmse1
mae

# 
# library(Hmisc)
# res_2000<-rcorr(as.matrix(y_2000))
# res_2001<-rcorr(as.matrix(y_2001))
# res_2002<-rcorr(as.matrix(y_2002))
# res_2003<-rcorr(as.matrix(y_2003))
# res_2004<-rcorr(as.matrix(y_2004))
# res_2005<-rcorr(as.matrix(y_2005))
# res_2006<-rcorr(as.matrix(y_2006))
# res_2007<-rcorr(as.matrix(y_2007))
# res_2008<-rcorr(as.matrix(y_2008))
# res_2009<-rcorr(as.matrix(y_2009))
# res_2010<-rcorr(as.matrix(y_2010))
# res_2011<-rcorr(as.matrix(y_2011))
# res_2012<-rcorr(as.matrix(y_2012))
# res_2013<-rcorr(as.matrix(y_2013))
# res_2014<-rcorr(as.matrix(y_2014))
# res_2015<-rcorr(as.matrix(y_2015))
# # res2[[3]][1,]
# 
# res_2000_1= res_2000[[3]][1,2:5]
# res_2001_1= res_2001[[3]][1,2:5]
# res_2002_1= res_2002[[3]][1,2:5]
# res_2003_1= res_2003[[3]][1,2:5]
# res_2004_1= res_2004[[3]][1,2:5]
# res_2005_1= res_2005[[3]][1,2:5]
# res_2006_1= res_2006[[3]][1,2:5]
# res_2007_1= res_2007[[3]][1,2:5]
# res_2008_1= res_2008[[3]][1,2:5]
# res_2009_1= res_2009[[3]][1,2:5]
# res_2010_1= res_2010[[3]][1,2:5]
# res_2011_1= res_2011[[3]][1,2:5]
# res_2012_1= res_2012[[3]][1,2:5]
# res_2013_1= res_2013[[3]][1,2:5]
# res_2014_1= res_2014[[3]][1,2:5]
# res_2015_1= res_2015[[3]][1,2:5]
# 
# 
# chart.Correlation(res_2000_1, histogram=TRUE, pch=19,
#                   method = c("pearson"))
# 
# plot(res_2000_1)
# 
# 
# res3 = data.frame(res_2000_1,res_2001_1,res_2002_1,res_2003_1,res_2004_1,
#                   res_2005_1,res_2006_1,res_2007_1,res_2008_1,res_2009_1,
#                   res_2010_1,res_2011_1,res_2012_1,res_2013_1,res_2014_1, res_2015_1)
# res4 = t(res3)
# colnames(res4)=c("NDVI","EVI","LAI","GPP")
# rownames(res4)=c("2000","2001","2002","2003",
#                  "2004","2005","2006","2007",
#                  "2008","2009","2010","2011",
#                  "2012","2013","2014","2015")
# 
# library(plotrix)
# mad_mean = data.frame(mad)
# colnames(mad_mean) <- c("NDVI", "EVI", "LAI","GPP")

# library(reshape2)
# library(ggplot2)
# year = seq(2015,2000,-1)
# var = c("NDVI","EVI","LAI","GPP")
# mad.df <- reshape2::melt(mad, c("y", "x"), value.name = "z")
# mad1.df <- reshape2::melt(mad1, c("y", "x"), value.name = "z")
# rmse.df <- reshape2::melt(rmse, c("y", "x"), value.name = "z")
# rmse1.df <- reshape2::melt(rmse1, c("y", "x"), value.name = "z")
# 
# mad_mean = ggplot(data=mad.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'MAD (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# 
# mad_max = ggplot(data=mad1.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'MAD (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# 
# rmse_mean = ggplot(data=rmse.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'RMSE (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# 
# rmse_max = ggplot(data=rmse1.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'RMSE (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# mad_mean
# mad_max
# rmse_mean
# rmse_max
# 
# path1 = "C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/"
# ggsave(filename="mad_mean.tiff", plot=mad_mean, path=path1, dpi=300)
# ggsave(filename="mad_max.tiff", plot=mad_max, path=path1, dpi=300)
# ggsave(filename="rmse_mean.tiff", plot=rmse_mean, path=path1, dpi=300)
# ggsave(filename="rmse_max.tiff", plot=rmse_max, path=path1, dpi=300)
# 
# library(ggplot2)
# ggplot(data = mad_mean, aes(x=)) + 
#   geom_tile()
# 
# 
# extent(g_yld1[[1]])= extent(y2000_m);
# 
# plot(y2000_m)
# plot(g_yld1[[1]])




plot(y2001,legend=FALSE)
plot(sea, add=T)
plot(y2002,legend=FALSE)
plot(sea, add=T)
plot(y2003,legend=FALSE)
plot(sea, add=T)
plot(y2004,legend=FALSE)
plot(sea, add=T)
plot(y2005,legend=FALSE)
plot(sea, add=T)


image(y2000)

plot(y2001,
     # maxpixels=ncell(zreate),
     # col=qcol,
     # colNA=mapbg,
     # xaxt='n',
     # yaxt='n',
     # ext=map_extent,
     # breaks=tq,
     # bty='n',
     legend=FALSE)
plot(sea, add=T)
image(y2000)
image(y2000)
image(y2000)
image(y2000)


par(mfrow=c(1,1), cex=3, mar=c(3,3,3,7), bg=bgcol, col=txtcol)

# first plot


#third plot and par() call
par(mfrow=c(1,1), cex=3, mar=c(3,3,3,7), bg=bgcol, col=txtcol, new=TRUE)
plot(r0,
     maxpixels=ncell(r0),
     col="#9e9ac8",
     xaxt='n',
     yaxt='n',
     ext=map_extent, #PRENAFILTERING fix
     bty='n',
     legend=FALSE)

y2000_m1 <- rasterToPoints(y2000)
#Make the points a dataframe for ggplot
df <- data.frame(y2000_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2000_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2000") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2000_m1

y2001_m1 <- rasterToPoints(y2001)
#Make the points a dataframe for ggplot
df <- data.frame(y2001_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2001_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2001") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2002_m1 <- rasterToPoints(y2002)
#Make the points a dataframe for ggplot
df <- data.frame(y2002_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2002_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2003_m1 <- rasterToPoints(y2003)
#Make the points a dataframe for ggplot
df <- data.frame(y2003_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2003_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


y2004_m1 <- rasterToPoints(y2004)
#Make the points a dataframe for ggplot
df <- data.frame(y2004_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2004_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2005_m1 <- rasterToPoints(y2005)
#Make the points a dataframe for ggplot
df <- data.frame(y2005_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2005_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2006_m1 <- rasterToPoints(y2006)
#Make the points a dataframe for ggplot
df <- data.frame(y2006_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2006_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2007_m1 <- rasterToPoints(y2007)
#Make the points a dataframe for ggplot
df <- data.frame(y2007_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2007_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2008_m1 <- rasterToPoints(y2008)
#Make the points a dataframe for ggplot
df <- data.frame(y2008_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2008_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2009_m1 <- rasterToPoints(y2009)
#Make the points a dataframe for ggplot
df <- data.frame(y2009_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2009_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2010_m1 <- rasterToPoints(y2010)
#Make the points a dataframe for ggplot
df <- data.frame(y2010_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2010_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2011_m1 <- rasterToPoints(y2011)
#Make the points a dataframe for ggplot
df <- data.frame(y2011_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2011_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2012_m1 <- rasterToPoints(y2012)
#Make the points a dataframe for ggplot
df <- data.frame(y2012_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2012_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
y2013_m1 <- rasterToPoints(y2013)
#Make the points a dataframe for ggplot
df <- data.frame(y2013_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2013_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2014_m1 <- rasterToPoints(y2014)
#Make the points a dataframe for ggplot
df <- data.frame(y2014_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2014_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2015_m1 <- rasterToPoints(y2015)
#Make the points a dataframe for ggplot
df <- data.frame(y2015_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2015_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )



#--------------------------------------------------------------------

g_yld1_2000 <- rasterToPoints(g_yld1[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2000)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2000=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2000") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

# y2000_m1

g_yld1_2001 <- rasterToPoints(g_yld1[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2001)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2001=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2001") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2002 <- rasterToPoints(g_yld1[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2002)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2002=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2003 <- rasterToPoints(g_yld1[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2003)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2003=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


g_yld1_2004 <- rasterToPoints(g_yld1[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2004)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2004=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2005 <- rasterToPoints(g_yld1[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2005)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2005=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2006 <- rasterToPoints(g_yld1[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2006)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2006=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2007 <- rasterToPoints(g_yld1[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2007)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2007=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2008 <- rasterToPoints(g_yld1[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2008)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2008=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2009 <- rasterToPoints(g_yld1[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2009)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2009=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2010 <- rasterToPoints(g_yld1[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2010)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2010=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2011 <- rasterToPoints(g_yld1[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2011)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2011=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2012 <- rasterToPoints(g_yld1[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2012)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2012=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
g_yld1_2013 <- rasterToPoints(g_yld1[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2013)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2013=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2014 <- rasterToPoints(g_yld1[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2014)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2014=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2015 <- rasterToPoints(g_yld1[[16]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2015)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2015=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

#----------------------------------------------------------------------
i_yld1_2000 <- rasterToPoints(i_yld1[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2000)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2000=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2000") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2000_m1

i_yld1_2001 <- rasterToPoints(i_yld1[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2001)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2001=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2001") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2002 <- rasterToPoints(i_yld1[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2002)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2002=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2003 <- rasterToPoints(i_yld1[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2003)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2003=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


i_yld1_2004 <- rasterToPoints(i_yld1[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2004)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2004=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2005 <- rasterToPoints(i_yld1[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2005)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2005=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2006 <- rasterToPoints(i_yld1[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2006)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2006=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2007 <- rasterToPoints(i_yld1[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2007)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2007=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2008 <- rasterToPoints(i_yld1[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2008)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2008=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2009 <- rasterToPoints(i_yld1[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2009)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2009=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2010 <- rasterToPoints(i_yld1[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2010)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2010=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2011 <- rasterToPoints(i_yld1[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2011)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2011=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2012 <- rasterToPoints(i_yld1[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2012)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2012=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
i_yld1_2013 <- rasterToPoints(i_yld1[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2013)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2013=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2014 <- rasterToPoints(i_yld1[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2014)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2014=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2015 <- rasterToPoints(i_yld1[[16]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2015)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2015=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


#--------------------------------------------------------------------
plot()
memory.limit(size=56000)
library(patchwork)
combined2 = y2000_m1+g_yld1_2000+i_yld1_2000+
            y2001_m1+g_yld1_2001+i_yld1_2001+
            y2002_m1+g_yld1_2002+i_yld1_2002+
            y2003_m1+g_yld1_2003+i_yld1_2003
combined3 = combined2 + plot_layout(ncol = 3, guides = "collect")
combined3

path1 = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/maps/New folder/new_maps/save/"

ggsave(filename="method.tiff", plot=combined3, path=path1, dpi=300)
ggsave(filename="lapse_rate2_temp.tiff", plot=combined3, path=path1, dpi=300)


#--------------------------
yld_cr2 = data.frame(yld_cr1)
yld_cr4 = data.frame(yld_cr3)



mae_2000 = ggplot(yld_cr2, aes(x = yld_cr2[,7], y = yld_cr2[,8])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2000_1 = mae_2000+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[1,4], digits = 2),"t/ha"), size=3)
mae_2000_1

mae_2001 = ggplot(yld_cr2, aes(x = yld_cr2[,11], y = yld_cr2[,12])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2001_1 = mae_2001+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[2,2], digits = 2),"t/ha"), size=3)
mae_2001_1

mae_2002 = ggplot(yld_cr2, aes(x = yld_cr2[,23], y = yld_cr2[,24])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2002_1 = mae_2001+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[3,4], digits = 2),"t/ha"), size=3)
mae_2002_1

mae_2003 = ggplot(yld_cr2, aes(x = yld_cr2[,27], y = yld_cr2[,28])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2003_1 = mae_2003+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[4,2], digits = 2),"t/ha"), size=3)
mae_2003_1

mae_2004 = ggplot(yld_cr2, aes(x = yld_cr2[,39], y = yld_cr2[,40])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2004_1 = mae_2004+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[5,4], digits = 2),"t/ha"), size=3)
mae_2004_1


mae_2005 = ggplot(yld_cr2, aes(x = yld_cr2[,47], y = yld_cr2[,48])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2005_1 = mae_2005+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[6,4], digits = 2),"t/ha"), size=3)
mae_2005_1

mae_2006 = ggplot(yld_cr2, aes(x = yld_cr2[,53], y = yld_cr2[,54])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2006_1 = mae_2006+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[7,3], digits = 2),"t/ha"), size=3)
mae_2006_1

mae_2007 = ggplot(yld_cr2, aes(x = yld_cr2[,59], y = yld_cr2[,60])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2007_1 = mae_2006+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[8,2], digits = 2),"t/ha"), size=3)
mae_2007_1

mae_2008 = ggplot(yld_cr2, aes(x = yld_cr2[,67], y = yld_cr2[,68])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2008_1 = mae_2008+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[9,2], digits = 2),"t/ha"), size=3)
mae_2008_1

mae_2009 = ggplot(yld_cr2, aes(x = yld_cr2[,79], y = yld_cr2[,80])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2009_1 = mae_2009+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[10,4], digits = 2),"t/ha"), size=3)
mae_2009_1

mae_2010 = ggplot(yld_cr2, aes(x = yld_cr2[,87], y = yld_cr2[,88])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2010_1 = mae_2010+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[11,4], digits = 2),"t/ha"), size=3)
mae_2010_1


mae_2011 = ggplot(yld_cr2, aes(x = yld_cr2[,89], y = yld_cr2[,90])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2011_1 = mae_2011+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[12,1], digits = 2),"t/ha"), size=3)
mae_2011_1


mae_2012 = ggplot(yld_cr2, aes(x = yld_cr2[,99], y = yld_cr2[,100])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2012_1 = mae_2012+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[13,2], digits = 2),"t/ha"), size=3)
mae_2012_1


mae_2013 = ggplot(yld_cr2, aes(x = yld_cr2[,105], y = yld_cr2[,106])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2013_1 = mae_2013+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[14,1], digits = 2),"t/ha"), size=3)
mae_2013_1


mae_2014 = ggplot(yld_cr2, aes(x = yld_cr2[,115], y = yld_cr2[,116])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2014_1 = mae_2014+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[15,2], digits = 2),"t/ha"), size=3)
mae_2014_1


mae_2015 = ggplot(yld_cr2, aes(x = yld_cr2[,127], y = yld_cr2[,128])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2015_1 = mae_2015+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[16,4], digits = 2),"t/ha"), size=3)
mae_2015_1


a=plot(x = yld_cr2[,127], y = yld_cr2[,128], main="Scatterplot Example",
     xlab="Car Weight ", ylab="Miles Per Gallon ", pch=19)

# m <- rbind(c(1,2,3,4), c(5,6,7,8), c(9,10,11,12),c(13,14,15,16))
# layout(m)


tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/cwu1.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = terrain.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(y2001, xaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2001", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2002, xaxt='n',yaxt='n', ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2002", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2003, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2003", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2004, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2004", line=0.5,cex = 0.5)

#---2
par(mai=c(0.4,0.2,0,0))
image(y2005, xaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2005", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2006, xaxt='n',yaxt='n', ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2006", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2007, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2007", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2008, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2008", line=0.5,cex = 0.5)

#--3
par(mai=c(0.4,0.2,0,0))
image(y2009, xaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2009", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2010, xaxt='n',yaxt='n', ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2010", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2011, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2011", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2012, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2012", line=0.5,cex = 0.5)

#--4


par(mai=c(0.4,0.2,0,0))

plot(y2013,xaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,5),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Crop water productivity [kg/m3]', side=1, font=1, line=2.0, cex=0.8))

# image(y2013, xaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
#       legend=FALSE,col=colors,zlim=c(0,7000))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="Latitude", line=2, cex = 0.5)
mtext(side=3, text="2013", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2014,yaxt='n', ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=1, text="Longitude", line=2, cex = 0.5)
mtext(side=3, text="2014", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2015, yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,5))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=1, text="Longitude", line=2, cex = 0.5)
mtext(side=3, text="2015", line=0.5,cex = 0.5)

# par(mai=c(0.4,0.2,0,0))
# image(y2004, xaxt='n',yaxt='n',ylab="Latitude",cex.main=1, cex.lab=0.5, cex.axis=0.5,
#       legend=FALSE,col=colors,zlim=c(0,7000))
# 
# plot(sea, border="grey", lwd=0.01, add=T)
# # text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
# mtext(side=2, text="Latitude", line=2, cex = 0.5)
# mtext(side=3, text="2004", line=0.5,cex = 0.5)
# 

dev.off()
#---------



par(mai=c(0.4,0.2,0,0))
image(g_yld1[[2]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2001", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2001, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[2]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,11], y = yld_cr2[,12], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[2,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[3]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2002", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2002, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[3]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,23], y = yld_cr2[,24], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[3,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[4]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2003", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2003, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[4]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,27], y = yld_cr2[,28], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[4,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#------------------------
tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/r2.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[5]], xaxt='n',ylab="2004",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2004", line=2, cex = 0.5)
mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2004, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[5]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,39], y = yld_cr2[,40], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[5,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[6]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2005", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2005, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[6]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,47], y = yld_cr2[,48], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[6,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[7]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2006", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2006, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[7]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,53], y = yld_cr2[,54], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[7,3], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[8]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2007", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2007, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[8]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,59], y = yld_cr2[,60], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[8,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#-------------------------------------------------------

tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/r3.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[9]], xaxt='n',ylab="2004",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2008", line=2, cex = 0.5)
mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2008, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[9]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,67], y = yld_cr2[,68], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[9,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[10]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2009", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2009, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[10]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,79], y = yld_cr2[,80], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[10,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[11]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2010", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2010, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[11]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,87], y = yld_cr2[,88], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[11,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[12]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2011", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2011, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[12]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,89], y = yld_cr2[,90], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[12,1], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#-------------------------------------------------------


tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/r4.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[13]], xaxt='n',ylab="2004",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2012", line=2, cex = 0.5)
mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2012, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[13]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,99], y = yld_cr2[,100], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[13,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[14]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2013", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2013, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[14]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,105], y = yld_cr2[,106], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[14,1], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[15]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2014", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2014, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[15]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,115], y = yld_cr2[,116], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[15,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[16]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2015", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2015, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[16]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,127], y = yld_cr2[,128], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[16,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#-------------------------------------------------------




# param3p_p10=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
#                  par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])
# 
# save(param3p_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/param_3p_p10.RData")
# save(lr_y_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_y_p10.RData")
# save(lr_x_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_x_p10.RData")
# save(lr_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_p10.RData")



