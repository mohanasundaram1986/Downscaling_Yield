library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)


# path1 = "C:/Users/WEM/OneDrive/AIT/papers/recharge paper/GIS"
# path2 = "C:/Users/ezhil/OneDrive/AIT/papers/recharge paper"
# # 
# sample1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/et_GEE/gis/sample1.shp")
ri_2015 <- read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/NEW_NDVI.xlsx", sheet = "ri_2015")
ri_2016 <- read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/NEW_NDVI.xlsx", sheet = "ri_2016")
ri_2017 <- read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/NEW_NDVI.xlsx", sheet = "ri_2017")
ri_2018 <- read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/NEW_NDVI.xlsx", sheet = "ri_2018")
ri_2019 <- read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/NEW_NDVI.xlsx", sheet = "ri_2019")

# bound = readOGR ("C:/Users/ezhil/OneDrive/AIT/papers/et_GEE/gis/bound_wgs1.shp")
# month = c('Jan','Feb','Mar','Apl','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
# 
# 
# # path = "C:/Users/ezhil/OneDrive/AIT/papers/landuse_mapping/maps"
# # re = read_excel("C:/Users/ezhil/OneDrive/AIT/papers/landuse_mapping/analysis/rs/rs_ana.xlsx", sheet = "Sheet1")
# # path = "C:/Users/WEM/OneDrive/AIT/papers/landuse_mapping/maps"
# # re <- read_excel("C:/Users/WEM/OneDrive/AIT/papers/landuse_mapping/analysis/rs/rs_ana.xlsx", sheet = "Sheet1")
# re_test = ndvi
# # cn = colnames(re[1,10:length(re[1,])])
# data = data.frame(re_test)
# #ndwi
# f_lst_m = re_test[1:12,1]
# f_lst_l = re_test[1:12,3]
# c_lst_m = re_test[13:24,1]
# c_lst_l = re_test[13:24,3]
# w_lst_m = re_test[25:36,1]
# w_lst_l = re_test[25:36,3]
# u_lst_m = re_test[37:48,1]
# u_lst_l = re_test[37:48,3]
# # f_nd1 = re_test[2:13,18]
# # c_nd1 = re_test[18:29,18]
# # b_nd1 = re_test[37:48,18]
# # w_nd1 = re_test[59:70,18]
# # u_nd1 = re_test[75:86,18]
# 
# #ndvi
# # f_nd = re_test[2:13,2]
# # c_nd = re_test[18:29,2]
# # b_nd = re_test[37:48,2]
# # w_nd = re_test[59:70,2]
# # u_nd = re_test[75:86,2]
# # 
# # f_nd1 = re_test[2:13,5]
# # c_nd1 = re_test[18:29,5]
# # b_nd1 = re_test[37:48,5]
# # w_nd1 = re_test[59:70,5]
# # u_nd1 = re_test[75:86,5]
# 
# 
# 
# months1 = factor(c('Jan','Feb','Mar','Apl','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'))
# colnames(f_lst_m) = c('f_lst_m')
# colnames(f_lst_l) = c('f_lst_l')
# colnames(c_lst_m) = c('c_lst_m')
# colnames(c_lst_l) = c('c_lst_l')
# colnames(w_lst_m) = c('w_lst_m')
# colnames(w_lst_l) = c('w_lst_l')
# colnames(u_lst_m) = c('u_lst_m')
# colnames(u_lst_l) = c('u_lst_l')
# 
# 
# # colnames(f_nd1) = c('f_ndvi_har')
# # colnames(c_nd1) = c('c_ndvi_har')
# # colnames(b_nd1) = c('b_ndvi_har')
# # colnames(w_nd1) = c('w_ndvi_har')
# # colnames(u_nd1) = c('u_ndvi_har')
# 
# 
# df = data.frame(months1,f_lst_m, f_lst_l)
# df1 = data.frame(months1,c_lst_m, c_lst_l)
# df2 = data.frame(months1,w_lst_m, w_lst_l)
# df3 = data.frame(months1,u_lst_m, u_lst_l)
# 
# # df$f_ndvi <- as.numeric(as.character(df$f_ndvi))
# # df$c_ndvi <- as.numeric(as.character(df$c_ndvi))
# # df$b_ndvi <- as.numeric(as.character(df$b_ndvi))
# # df$w_ndvi <- as.numeric(as.character(df$w_ndvi))
# # df$u_ndvi <- as.numeric(as.character(df$u_ndvi))
# 
# # df$f_ndvi_har <- as.numeric(as.character(df$f_ndvi_har))
# # df$c_ndvi_har <- as.numeric(as.character(df$c_ndvi_har))
# # df$b_ndvi_har <- as.numeric(as.character(df$b_ndvi_har))
# # df$w_ndvi_har <- as.numeric(as.character(df$w_ndvi_har))
# # df$u_ndvi_har <- as.numeric(as.character(df$u_ndvi_har))
# 
# 
# months2 <- factor(months1, levels = months1)
# 
# 
# 
# # # Add a second line
# # plot(f_nd, pch = 19, col = "blue", type = "l", lty = 2)
# # lines(f_nd1, col = "red", add=TRUE)
# 
# 
# # p1 = ggplot(df,aes(x=months1,y = round(f_ndvi, digits = 2))) 
# # p1 = p1 + geom_point()
# # p2 = ggplot(df, aes(x=months1, y = round(f_ndvi_har, digits = 2), add=TRUE))
# # p2 = p1+ geom_line()
# # p2
# 
# # ggplot(df, aes(months1)) + geom_line(aes(y = f_ndvi))
# 
# # ggplot() + geom_line(aes(x=df$months1,y=df$f_ndvi),color='red') + 
# #         geom_line(aes(x=df$months1,y=df$c_ndvi),color='blue') + 
# #         ylab('Values')+xlab('date')
# # 
# # 
# # nmonths = 24
# # x = seq(as.Date("2015/1/1"), by = "month", length.out = nmonths)
# # 
# # prescription1 <- data.frame(
# #         x,
# #         Percent.Change = 25 + runif(nmonths,1,100)
# # )
# # 
# # prescription2 <- data.frame(
# #         x,
# #         Percent.Change = 75 + runif(nmonths,1,50)
# # )
# # 
# # cols = c("dates", "Difference")
# # colnames(prescription1) = cols
# # colnames(prescription2) = cols



# p1 = ggplot(data = df, aes(x = months1, y = f_ndvi, group=1, fill = "forest"), color = "forestgreen") + geom_point() +
#      ggplot(data = df, aes(x = months1, y = f_ndvi_har, group=1, fill = "forest_pred"), color = "forestgreen") + geom_line()
# 
# p1

ri_2015 = data.frame(ri_2015)
ri_2016 = data.frame(ri_2016)
ri_2017 = data.frame(ri_2017)
ri_2018 = data.frame(ri_2018)
ri_2019 = data.frame(ri_2019)

colors1 <- c("Predicted NDVI" = "black", "Gap filled NDVI"= "red")
colors2 = c("Actual NDVI with missing values" = "forestgreen")
# colors1 = c("Predicted NDVI" = "forestgreen","Gap filled NDVI" = "black", "Mask" = "red")
months1 = factor(c(ri_2015$time), levels = c(ri_2015$time))
months2 = factor(c(ri_2016$time), levels = c(ri_2016$time))
months3 = factor(c(ri_2017$time), levels = c(ri_2017$time))
months4 = factor(c(ri_2018$time), levels = c(ri_2018$time))
months5 = factor(c(ri_2019$time), levels = c(ri_2019$time))

# , levels = ri_2015_1$system.time_start...1))
# months1 <- factor(c(crop_df$system.time_start...1), levels = c(crop_df$system.time_start...1))

r = ggplot() +
  # geom_line(data = df, aes(x = months1, y = u_ndvi_har, group=1), color = "gold") +
  # 
  geom_line(data=ri_2015, aes(x=months1, y = ri_2015$pred_ndvi, group =1, color = "Predicted NDVI"), size = 1.0) +
  geom_line(data=ri_2015, aes(x=months1, y = ri_2015$tot_ndvi, group =1, color = "Gap filled NDVI"), size = 1.5) +
  geom_point(data=ri_2015, aes(x=months1, y = ri_2015$LS_NDVI, group=1, fill = "Actual NDVI with missing values"), color="forestgreen", size=2.5) +
  
  
  xlab('Months') +
  ylab('NDVI')+
  #
  # Change the legend
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 12)
        # axis.text.x = element_text(angle = 180, vjust = 0.5, hjust=1)
  )+
  
  theme(legend.position="top")
  # coord_equal()

r1 = r+annotate(geom="text", x=10, y=1, label = paste("R1"), size=5)
r1_1 = r1 + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


print(r1_1)
#---



r2 = ggplot() +
  # geom_line(data = df, aes(x = months1, y = u_ndvi_har, group=1), color = "gold") +
  # 
  geom_line(data=ri_2016, aes(x=months2, y = ri_2016$pred_ndvi, group =1, color = "Predicted NDVI"), size = 1.0) +
  geom_line(data=ri_2016, aes(x=months2, y = ri_2016$tot_ndvi, group =1, color = "Gap filled NDVI"), size = 1.5) +
  geom_point(data=ri_2016, aes(x=months2, y = ri_2016$LS_NDVI, group=1, fill = "Actual NDVI with missing values"), color="forestgreen", size=2.5) +
  
  
  xlab('Months') +
  ylab('NDVI')+
  #
  # Change the legend
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 12)
        # axis.text.x = element_text(angle = 180, vjust = 0.5, hjust=1)
  )+
  
  theme(legend.position="top")
# coord_equal()

r2 = r2+annotate(geom="text", x=10, y=1, label = paste("R2"), size=5)
r2_1 = r2 + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


print(r2_1)


r3 = ggplot() +
  # geom_line(data = df, aes(x = months1, y = u_ndvi_har, group=1), color = "gold") +
  # 
  geom_line(data=ri_2017, aes(x=months3, y = ri_2017$pred_ndvi, group =1, color = "Predicted NDVI"), size = 1.0) +
  geom_line(data=ri_2017, aes(x=months3, y = ri_2017$tot_ndvi, group =1, color = "Gap filled NDVI"), size = 1.5) +
  geom_point(data=ri_2017, aes(x=months3, y = ri_2017$LS_NDVI, group=1, fill = "Actual NDVI with missing values"), color="forestgreen", size=2.5) +
  
  
  xlab('Months') +
  ylab('NDVI')+
  #
  # Change the legend
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 12)
        # axis.text.x = element_text(angle = 180, vjust = 0.5, hjust=1)
  )+
  
  theme(legend.position="top")
# coord_equal()

r3 = r3+annotate(geom="text", x=10, y=1, label = paste("R3"), size=5)
r3_1 = r3 + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


print(r3_1)


r4 = ggplot() +
  # geom_line(data = df, aes(x = months1, y = u_ndvi_har, group=1), color = "gold") +
  # 
  geom_line(data=ri_2018, aes(x=months4, y = ri_2018$pred_ndvi, group =1, color = "Predicted NDVI"), size = 1.0) +
  geom_line(data=ri_2018, aes(x=months4, y = ri_2018$tot_ndvi, group =1, color = "Gap filled NDVI"), size = 1.5) +
  geom_point(data=ri_2018, aes(x=months4, y = ri_2018$LS_NDVI, group=1, fill = "Actual NDVI with missing values"), color="forestgreen", size=2.5) +
  
  
  xlab('Months') +
  ylab('NDVI')+
  #
  # Change the legend
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 12)
        # axis.text.x = element_text(angle = 180, vjust = 0.5, hjust=1)
  )+
  
  theme(legend.position="top")
# coord_equal()

r4 = r4+annotate(geom="text", x=10, y=1, label = paste("R4"), size=5)
r4_1 = r4 + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


print(r4_1)


r5 = ggplot() +
  # geom_line(data = df, aes(x = months1, y = u_ndvi_har, group=1), color = "gold") +
  # 
  geom_line(data=ri_2019, aes(x=months5, y = ri_2019$pred_ndvi, group =1, color = "Predicted NDVI"), size = 1.0) +
  geom_line(data=ri_2019, aes(x=months5, y = ri_2019$tot_ndvi, group =1, color = "Gap filled NDVI"), size = 1.5) +
  geom_point(data=ri_2019, aes(x=months5, y = ri_2019$LS_NDVI, group=1, fill = "Actual NDVI with missing values"), color="forestgreen", size=2.5) +
  
  
  xlab('Months') +
  ylab('NDVI')+
  #
  # Change the legend
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 12)
        # axis.text.x = element_text(angle = 180, vjust = 0.5, hjust=1)
  )+
  
  theme(legend.position="top")
# coord_equal()

r5 = r5+annotate(geom="text", x=10, y=1, label = paste("R5"), size=5)
r5_1 = r5 + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


print(r5_1)
#---



err1 = ri_2015$pred_ndvi - ri_2015$tot_ndvi
err1.sqr = err1^2
rmse1 = sqrt(mean(err1.sqr, na.rm=T))

err2 = ri_2016$pred_ndvi - ri_2016$tot_ndvi
err2.sqr = err2^2
rmse2 = sqrt(mean(err2.sqr,na.rm=T))

err3 = ri_2017$pred_ndvi - ri_2017$tot_ndvi
err3.sqr = err3^2
rmse3 = sqrt(mean(err3.sqr,na.rm=T))

err4 = ri_2018$pred_ndvi - ri_2018$tot_ndvi
err4.sqr = err4^2
rmse4 = sqrt(mean(err4.sqr,na.rm=T))

err5 = ri_2019$pred_ndvi - ri_2019$tot_ndvi
err5.sqr = err5^2
rmse5 = sqrt(mean(err5.sqr,na.rm=T))



rmse1
rmse2
# err3 = data[,8] - data[,9]
# err3.sqr = err3^2
# rmse3 = sqrt(mean(err3.sqr,na.rm=T))
# 
# err4 = data[,11] - data[,12]
# err4.sqr = err4^2
# rmse4 = sqrt(mean(err4.sqr,na.rm=T))


#wilmont_index
# mean_obs = mean(obs_bf1[,2]) 
# mean_mod = mean(mod_bf1[,2]) 
# mean_m1 = mean(m1_bf1[,2])
# mean_m2 = mean(m2_bf1[,2])
# 
# 
# wi1 = 1- sum((obs_bf1[,2] - mod_bf1[,2])^2)/sum((abs(mod_bf1[,2]-mean_obs)+abs(obs_bf1[,2]-mean_obs))^2)
# wi2 = 1- sum((obs_bf1[,2] - m1_bf1[,2])^2)/sum((abs(m1_bf1[,2]-mean_obs)+abs(obs_bf1[,2]-mean_obs))^2)
# wi3 = 1- sum((obs_bf1[,2] - m2_bf1[,2])^2)/sum((abs(m2_bf1[,2]-mean_obs)+abs(obs_bf1[,2]-mean_obs))^2)
# 
# #efficiency
# nse1 = 1 - sum((obs_bf1[,2] - mod_bf1[,2])^2)/sum((obs_bf1[,2]-mean_obs)^2)
# nse2 = 1 - sum((obs_bf1[,2] - m1_bf1[,2])^2)/sum((obs_bf1[,2]-mean_obs)^2)
# nse3 = 1 - sum((obs_bf1[,2] - m2_bf1[,2])^2)/sum((obs_bf1[,2]-mean_obs)^2)

#mean bias
# mbe1 = mean(mod_bf1[,2]-obs_bf1[,2])
# mbe2 = mean(m1_bf1[,2]-obs_bf1[,2])
# mbe3 = mean(m2_bf1[,2]-obs_bf1[,2])

#relative bias

rb1 = sum(err1, na.rm =T)/sum(crop_df$tot_ndvi,na.rm =T)
rb2 = sum(err2,na.rm =T)/sum(crop_df$tot_lst,na.rm =T)
# rb3 = sum(data[,8]-data[,9],na.rm =T)/sum(data[,8],na.rm =T)
# rb4 = sum(data[,11]-data[,12],na.rm =T)/sum(data[,11],na.rm =T)
rb1
rb2


#mean bs per err

mape1 = mean(abs((err1)/crop_df$tot_ndvi), na.rm=T)
mape2 = mean(abs((err2)/crop_df$tot_lst),na.rm=T)
mape1
mape2
# mape3 = mean(abs((data[,8] - data[,9])/data[,8]),na.rm=T)
# mape4 = mean(abs((data[,11] - data[,12])/data[,11]),na.rm=T)


#pearson coeeficient

# r1 = sum(((obs_bf1[,2]-mean_obs)*(mod_bf1[,2]-mean_mod)))/((sqrt(sum((obs_bf1[,2]-mean_obs)^2)))*(sqrt(sum((mod_bf1[,2]-mean_mod)^2))))
# r2 = sum(((obs_bf1[,2]-mean_obs)*(m1_bf1[,2]-mean_m1)))/((sqrt(sum((obs_bf1[,2]-mean_obs)^2)))*(sqrt(sum((m1_bf1[,2]-mean_m1)^2))))
# r3 = sum(((obs_bf1[,2]-mean_obs)*(m2_bf1[,2]-mean_m2)))/((sqrt(sum((obs_bf1[,2]-mean_obs)^2)))*(sqrt(sum((m2_bf1[,2]-mean_m2)^2))))

#corr coeft
# n=18
# # cc1 = ((n*sum(obs_bf1[,2]*mod_bf1[,2])) - (sum(obs_bf1[,2])*sum(mod_bf1[,2]))) /sqrt((n*sum((obs_bf1[,2]^2))-sum(obs_bf1[,2])^2)*(n*sum((mod_bf1[,2]^2))-sum(mod_bf1[,2])^2))
# 
# cc1 = r1^2
# cc2 = r2^2
# cc3 = r3^2

f1 = ggplot(ri_2015, aes(x = tot_ndvi, y = pred_ndvi)) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Actual NDVI",
    y = "Predicted NDVI"
    # color = "Gear",
    # title = "Relation between Mile per hours and drat",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,1)+
  ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank()
  )+
  
  geom_abline(intercept = 0, slope = 1)+
  coord_equal() 
  
f1 = f1+annotate(geom="text", x=0.25, y=1, label = paste("RMSE = ", round(rmse1, digits = 2)), size=5)
         
f1

f2 = ggplot(ri_2016, aes(x = tot_ndvi, y = pred_ndvi)) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Actual NDVI",
    y = "Predicted NDVI"
    # color = "Gear",
    # title = "Relation between Mile per hours and drat",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,1)+
  ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank()
  )+
  
  geom_abline(intercept = 0, slope = 1)+
  coord_equal() 

f2 = f2+annotate(geom="text", x=0.25, y=1, label = paste("RMSE = ", round(rmse2, digits = 2)), size=5)

f2

f3 = ggplot(ri_2017, aes(x = tot_ndvi, y = pred_ndvi)) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Actual NDVI",
    y = "Predicted NDVI"
    # color = "Gear",
    # title = "Relation between Mile per hours and drat",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,1)+
  ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank()
  )+
  
  geom_abline(intercept = 0, slope = 1)+
  coord_equal() 

f3 = f3+annotate(geom="text", x=0.25, y=1, label = paste("RMSE = ", round(rmse3, digits = 2)), size=5)

f3

f4 = ggplot(ri_2018, aes(x = tot_ndvi, y = pred_ndvi)) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Actual NDVI",
    y = "Predicted NDVI"
    # color = "Gear",
    # title = "Relation between Mile per hours and drat",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,1)+
  ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank()
  )+
  
  geom_abline(intercept = 0, slope = 1)+
  coord_equal() 

f4 = f4+annotate(geom="text", x=0.25, y=1, label = paste("RMSE = ", round(rmse4, digits = 2)), size=5)

f4

f5 = ggplot(ri_2019, aes(x = tot_ndvi, y = pred_ndvi)) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Actual NDVI",
    y = "Predicted NDVI"
    # color = "Gear",
    # title = "Relation between Mile per hours and drat",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,1)+
  ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank()
  )+
  
  geom_abline(intercept = 0, slope = 1)+
  coord_equal() 

f5 = f5+annotate(geom="text", x=0.25, y=1, label = paste("RMSE = ", round(rmse5, digits = 2)), size=5)

f5



c1 = ggplot(crop_df, aes(x = tot_lst, y = pred_lst)) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Actual LST(C)",
    y = "Predicted LST(C)"
    # color = "Gear",
    # title = "Relation between Mile per hours and drat",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(15,45)+
  ylim(15,45)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank()
  )+
  geom_abline(intercept = 0, slope = 1)+
  coord_equal()

c2 = c1+annotate(geom="text", x=25, y=45, label = paste("RMSE = ", round(rmse2, digits = 2),"C"), size=5)

c2


# w1 = ggplot(df2, aes(x = w_lst_m, y = w_lst_l)) +
#   geom_point(size=3)+
#   stat_smooth(method = "lm",
#               col = "#C42126",
#               se = FALSE,
#               size = 1) +
#   labs(
#     x = "MODIS-LST(C)",
#     y = "L8-LST(C)"
#     # color = "Gear",
#     # title = "Relation between Mile per hours and drat",
#     # subtitle = "Relationship break down by gear class",
#     # caption = "Authors own computation"
#   ) +
#   xlim(20,40)+
#   ylim(20,40)+
#   theme_bw()+
#   
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_text(size=10),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_blank(),
#         # panel.grid.minor = element_blank(),
#         legend.position = "",
#         legend.key = element_blank()
#   )+
#   geom_abline(intercept = 0, slope = 1)
# 
# w2 = w1+annotate(geom="text", x=24, y=35, label = paste("RMSE = ", round(rmse3, digits = 2), "C"), size=3)
# 
# w2
# 
# u1 = ggplot(df3, aes(x = u_lst_m, y = u_lst_l)) +
#   geom_point(size=3)+
#   stat_smooth(method = "lm",
#               col = "#C42126",
#               se = FALSE,
#               size = 1) +
#   labs(
#     x = "MODIS-LST(C)",
#     y = "L8-LST(C)"
#     # color = "Gear",
#     # title = "Relation between Mile per hours and drat",
#     # subtitle = "Relationship break down by gear class",
#     # caption = "Authors own computation"
#   ) +
#   xlim(20,40)+
#   ylim(20,40)+
#   theme_bw()+
#   
#   theme(axis.title.x = element_text(size=10),
#         axis.title.y = element_text(size=10),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_blank(),
#         # panel.grid.minor = element_blank(),
#         legend.position = "",
#         legend.key = element_blank()
#   )+
#   geom_abline(intercept = 0, slope = 1)
# 
# u2 = u1+annotate(geom="text", x=24, y=35, label = paste("RMSE = ", round(rmse4, digits = 2), "C"), size=3)
# 
# u2


memory.limit(size=56000)
library(patchwork)
combined = r5_1 + f5& theme(legend.position = "top")
combined1 = combined + plot_layout(ncol = 2, guides = "collect")
combined1
path1 = "C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/maps"
ggsave(filename="r5.tiff", plot=combined1, path=path1, dpi=300)



# my3cols <- c('mod','obs','m1','m2')
# ToothGrowth$dose <- as.factor(ToothGrowth$dose)
# # 1. Create a box plot (bp)
# p <- ggplot(ToothGrowth, aes(x = dose, y = len))
# bxp <- p + geom_boxplot(aes(color = dose)) +
#   scale_color_manual(values = my3cols)
# # 2. Create a dot plot (dp)
# dp <- p + geom_dotplot(aes(color = dose, fill = dose), 



# names(lst1)=c('month','modis','landsat')
# 
# month = c('Jan','Feb','Mar','Apl','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
# month1 = factor(month, level=month);
# group1 =rep(c('lst'),12)
#  
# lst2 = data.frame(lst1,group1)      
# # month1 = order()
# a=ggplot(lst2, aes(x =month1,y = modis, group=group1)) + 
#   geom_point(size =2, color = "red")+
#   geom_line(size =1)+
#   # geom_point(aes(y=mod),size =2, color="red")+
#   # geom_line(aes(y=mod),size =1, color="blue")+
#   labs(
#     x = "Months in 2018",
#     y = "LST (C)"
#     # color = "Gear",
#     # title = "Relation between Mile per hours and drat",
#     # subtitle = "Relationship break down by gear class",
#     # caption = "Authors own computation"
#   ) +
#   # # xlim(20,35)+
#   ylim(20,35)+
#   # theme_bw() +
#   # scale_colour_manual(values = c("black")) +
#   # scale_fill_gradientn(colours = rainbow(20), limits=c(-50,50))+
#   # 
# # theme(axis.title.x = element_text(size=14),
# #       axis.title.y = element_text(size=14),
# #       axis.text.x = element_text(size=14),
# #       axis.text.y = element_text(size=14),
# #       # panel.grid.major = element_blank(),
# #       # panel.grid.minor = element_blank(),
# #       legend.position = "right",
# #       legend.key = element_blank()
# # )
# #   scale_fill_discrete(name = "Dose", labels = c("A"))
#  theme(legend.position="bottom")
# # a1
# 
# # )+
# a
# 
#   # scale_x_date(date_labels="%b", date_breaks="month", expand=c(0,0))
#   
# # a
#   z# geom_line(aes(y = mod, colour = "mod"))
# # scale_x_continuous(expand = c(0, 0)) 
#   # scale_y_continuous(limits=c(0,50), breaks=seq(0, 50, 10), expand = c(0, 0))
# 
# 
# roc2 = ggplot(NULL,lst1, aes(x = month, y = mod)) +
#   geom_line()
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  # labs(
  #   x = "Observed Runoff (mm/year)",
  #   y = "Modelled Runoff (mm/year)"
  #   # color = "Gear",
  #   # title = "Relation between Mile per hours and drat",
  #   # subtitle = "Relationship break down by gear class",
  #   # caption = "Authors own computation"
  # ) +
  # # xlim(20,35)+
  # ylim(20,35)+
  # 
  # theme(axis.title.x = element_text(size=14),
  #       axis.title.y = element_text(size=14),
  #       axis.text.x = element_text(size=14),
  #       axis.text.y = element_text(size=14),
  #       # panel.grid.major = element_blank(),
  #       # panel.grid.minor = element_blank(),
  #       legend.position = "",
  #       legend.key = element_blank()
  # )
  # )+
  # geom_abline(intercept = 0, slope = 1)

# roc2





