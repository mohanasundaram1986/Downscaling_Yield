library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)
library(ncdf4)

library(raster)
library(gstat)
library(sp)

setwd('G:/OneDrive/AIT/papers/workspace/')
TEMP = "G:/OneDrive/AIT/papers/workspace"
tempdir()
# setwd('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5_p1_n1.RData')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_2.RData')
# basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3.shp")
# # basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s1_n4.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")


basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia5.shp")
basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia4.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s2.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s4.shp")
# basin10 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s10.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_seg_sw.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")
sea = readOGR("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/gis/sea_count_sa.shp")
# fishnet1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2_df <- fortify(fishnet2)

sam <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")

basin_p=basin
basin_p1=basin1
basin_p2=basin2
basin_p3=basin3
basin_p4=basin4
basin_p10=basin10
plot(basin_p2)

yld_corr = read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")
yld_cr1 = read_excel("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_comp1.xlsx","mean")
yld_cr3 = read_excel("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_comp1.xlsx","max")

cwu = read.csv("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/cwu.csv")
et = read.csv("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/et.csv")
yield = read.csv("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield.csv")


# p1 <- "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model_et/"
# R1 <- list.files(p1, pattern = "tif$",full.names = TRUE)


year = c(seq(2001,2015,1))
cwu1 = data.frame(cwu)
et1 = data.frame(et)
yield1 = data.frame(yield)
colnames(cwu1)[2:16]=year[1:15]
colnames(et1)[2:16]=year[1:15]
colnames(yield1)[2:16]=year[1:15]

cwu1.df <- reshape2::melt(cwu1)
et1.df <- reshape2::melt(et1)
yield1.df <- reshape2::melt(yield1)

# cwu2.df <- reshape2::melt(cwu1, c("COUNTRY","variable"), value.name = value)
tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/cwu_country.tiff", units="in", width=9, height=5, res=400)

cwu1_m = ggplot(data=cwu1.df,aes(x=variable,y=COUNTRY))+
                    geom_raster(aes(fill=value))+
                    scale_fill_gradient(low="grey90", high="red")+
                    labs(fill= 'CWP (kg/m^3)')+
        # geom_tile()+
                    theme_bw()+
                    theme(axis.title.x = element_blank(),
                          axis.title.y = element_blank(),
                          axis.text.x = element_text(size=10),
                          axis.text.y = element_text(size=10),
                          # panel.grid.major = element_text(size=10),
                          # panel.grid.minor =  element_text(size=10),
                          legend.title=element_text(size=10),
                          legend.text=element_text(size=10),
                          legend.position = "right",
                          legend.key = element_blank(),
                          plot.title = element_text(size=8)
                    )

cwu1_m

dev.off()
#-------------------------------------------------------

tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/et_country.tiff", units="in", width=9, height=5, res=400)

et1_m = ggplot(data=et1.df,aes(x=variable,y=COUNTRY))+
  geom_raster(aes(fill=value))+
  scale_fill_gradient(low="grey90", high="green")+
  labs(fill= 'ET (m3/ha)')+
  # geom_tile()+
  theme_bw()+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_text(size=10),
        # panel.grid.minor =  element_text(size=10),
        legend.title=element_text(size=10),
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

et1_m

dev.off()
#------
tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/yield_country.tiff", units="in", width=9, height=5, res=400)

yield1_m = ggplot(data=yield1.df,aes(x=variable,y=COUNTRY))+
  geom_raster(aes(fill=value))+
  scale_fill_gradient(low="grey90", high="blue")+
  labs(fill= 'Rice-Yield (t/ha)')+
  # geom_tile()+
  theme_bw()+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_text(size=10),
        # panel.grid.minor =  element_text(size=10),
        legend.title=element_text(size=10),
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

yield1_m

dev.off()
#------



# param3p_p10=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
#                  par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])
# 
# save(param3p_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/param_3p_p10.RData")
# save(lr_y_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_y_p10.RData")
# save(lr_x_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_x_p10.RData")
# save(lr_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_p10.RData")



