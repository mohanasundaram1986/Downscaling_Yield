library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)
library(ncdf4)

library(raster)
library(gstat)
library(sp)

# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1.RData')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_2.RData')
basin <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n1.shp")
basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
basin3 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n1_s.shp")

basin_p=basin
basin_p1=basin1
basin_p2=basin2
basin_p3=basin3
plot(basin_p3)


p1 <- "F:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/data/gdhy_v1.2_v1.3_20190128/rice_major/"
R1 <- list.files(p1, pattern = "nc4")

ap_rice <- raster::stack(file.path(p1, R1), varname = "var")

p2 <- "F:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/data/gdhy_v1.2_v1.3_20190128/rice_second/"
R2 <- list.files(p2, pattern = "nc4")

ap_rice_s <- raster::stack(file.path(p2, R2), varname = "var")

ap_rice1 <- crop(ap_rice,basin)
ap_rice1_major = mask(ap_rice1,basin)

ap_rice2 <- crop(ap_rice_s,basin)
ap_rice1_second = mask(ap_rice2,basin)

plot(ap_rice1_major[[4]])
plot(ap_rice1_second[[4]])

#get the date from the names of the layers and extract the month
idx_1_a <- seq(as.Date('1970-01-01'), as.Date('2005-12-31'), 'day')
idx_2_a <- seq(as.Date('1970-01-01'), as.Date('2005-12-31'), 'month')
idx_3_a <- seq(1,12)

names(s1_ap1)=idx_1_a

indices_a <- format(as.Date(names(s1_ap1), format = "X%Y.%m.%d"), format = "%y.%m")
indices_a <- as.numeric(indices_a)

#sum layers
month_ap<- stackApply(s1_ap1, indices_a, fun = sum)
names(month_ap) <- idx_2_a

#mean_month
indices1_a <- format(as.Date(names(month_ap), format = "X%Y.%m.%d"), format = "%m")
indices1_a <- as.numeric(indices1_a)

month_ap1<- stackApply(month_ap, indices1_a, fun = mean)
names(month_ap1) = idx_3_a

indices2_a = names(month_ap1)
# indices2 = as.numeric(indices2)

#yearly rainfall
year_ap = sum(month_ap1)

#RESAMPLE

# month_rcm_f26_r = list();



month_ap_c_p1 = crop(month_ap_r,basin_p3)

s1_gcm1_c_p1 = crop(s1_gcm1,basin_p3)


dem_c_p1 <- crop(dem,basin_p3)
dem_m_p1 = mask(dem_c_p1, basin_p3)

month_gcm1_resam_p1 =list();
month_ap_resam_p1 = list();

for (i in 1:432){
  #241:432
  print(i)
  # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  month_ap_resam_p1[[i]] = resample(month_ap_c_p1[[i]],dem_c_p1,'bilinear')
  month_gcm1_resam_p1[[i]] = resample(s1_gcm1_c_p1[[i]],dem_c_p1,'bilinear')
}

# month_rcm_f85_r = list()
# for (i in 1:360){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   month_rcm_f85_r[[i]] = resample(month_rcm_f85[[i]],r3,'bilinear')
# }

# for (i in 1:432){
#   #241:432
#   print(i)
#   month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
# }

month_ap_resam1_p1 = stack(month_ap_resam_p1)
month_gcm1_resam1_p1 = stack(month_gcm1_resam_p1)
# month_rcm_f26_r = stack(month_rcm_f26_r)
# month_rcm_f85_r = stack(month_rcm_f85_r)

save(month_ap_r, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_5_month_ap_r.RData")
# # Save multiple objects
# save(data1, data2, file = "data.RData")
# # To load the data again
# load("data.RData")


# focal analsyis and laprserate--------------------------------------------------
yy = (month_ap_resam1_p1)
xx = (month_gcm1_resam1_p1)

w=c(5,5)

dem_m1_p1 = stack(replicate(432,dem_m_p1))
yy = sch_5_p1[[1:432]]
xx = sch_5_p1[[433:864]]
# xx = sch_5_p1[[865:1296]]

yy_p3 = crop(yy,basin_p3)
xx_p3 = crop(xx,basin_p3)

yy_p3 = mask(yy_p3,basin_p3)
xx_p3 = mask(xx_p3,basin_p3)

yy_p3_s = yy_p3[[1:180]]

#biascorrection
xx_p3_jan = xx_p3[[jan]]
xx_p3_feb = xx_p3[[feb]]
xx_p3_mar = xx_p3[[mar]]
xx_p3_apl = xx_p3[[apl]]
xx_p3_may = xx_p3[[may]]
xx_p3_jun = xx_p3[[jun]]
xx_p3_jul = xx_p3[[jul]]
xx_p3_aug = xx_p3[[aug]]
xx_p3_sep = xx_p3[[sep]]
xx_p3_oct = xx_p3[[oct]]
xx_p3_nov = xx_p3[[nov]]
xx_p3_dec = xx_p3[[dec]]

xx_p3_jan1 <- calc(xx_p3_jan, fun = mean)
xx_p3_feb1 <- calc(xx_p3_feb, fun = mean)
xx_p3_mar1 <- calc(xx_p3_mar, fun = mean)
xx_p3_apl1 <- calc(xx_p3_apl, fun = mean)
xx_p3_may1 <- calc(xx_p3_may, fun = mean)
xx_p3_jun1 <- calc(xx_p3_jun, fun = mean)
xx_p3_jul1 <- calc(xx_p3_jul, fun = mean)
xx_p3_aug1 <- calc(xx_p3_aug, fun = mean)
xx_p3_sep1 <- calc(xx_p3_sep, fun = mean)
xx_p3_oct1 <- calc(xx_p3_oct, fun = mean)
xx_p3_nov1 <- calc(xx_p3_nov, fun = mean)
xx_p3_dec1 <- calc(xx_p3_dec, fun = mean)

#----------------
yy_p3_jan = yy_p3[[jan]]
yy_p3_feb = yy_p3[[feb]]
yy_p3_mar = yy_p3[[mar]]
yy_p3_apl = yy_p3[[apl]]
yy_p3_may = yy_p3[[may]]
yy_p3_jun = yy_p3[[jun]]
yy_p3_jul = yy_p3[[jul]]
yy_p3_aug = yy_p3[[aug]]
yy_p3_sep = yy_p3[[sep]]
yy_p3_oct = yy_p3[[oct]]
yy_p3_nov = yy_p3[[nov]]
yy_p3_dec = yy_p3[[dec]]

yy_p3_jan1 <- calc(yy_p3_jan, fun = mean)
yy_p3_feb1 <- calc(yy_p3_feb, fun = mean)
yy_p3_mar1 <- calc(yy_p3_mar, fun = mean)
yy_p3_apl1 <- calc(yy_p3_apl, fun = mean)
yy_p3_may1 <- calc(yy_p3_may, fun = mean)
yy_p3_jun1 <- calc(yy_p3_jun, fun = mean)
yy_p3_jul1 <- calc(yy_p3_jul, fun = mean)
yy_p3_aug1 <- calc(yy_p3_aug, fun = mean)
yy_p3_sep1 <- calc(yy_p3_sep, fun = mean)
yy_p3_oct1 <- calc(yy_p3_oct, fun = mean)
yy_p3_nov1 <- calc(yy_p3_nov, fun = mean)
yy_p3_dec1 <- calc(yy_p3_dec, fun = mean)

#------------

ls_jan = yy_p3_jan1/xx_p3_jan1
ls_feb = yy_p3_feb1/xx_p3_feb1
ls_mar = yy_p3_mar1/xx_p3_mar1
ls_apl = yy_p3_apl1/xx_p3_apl1
ls_may = yy_p3_may1/xx_p3_may1
ls_jun = yy_p3_jun1/xx_p3_jun1
ls_jul = yy_p3_jul1/xx_p3_jul1
ls_aug = yy_p3_aug1/xx_p3_aug1
ls_sep = yy_p3_sep1/xx_p3_sep1
ls_oct = yy_p3_oct1/xx_p3_oct1
ls_nov = yy_p3_nov1/xx_p3_nov1
ls_dec = yy_p3_dec1/xx_p3_dec1

xx_p3_bias = list();

for (i in 1:180){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  
  if(i%%12 == 1){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_jan
    
  } else if(i%%12 == 2){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_feb
    
  } else if(i%%12 == 3){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_mar
    
  } else if(i%%12 == 4){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_apl
    
  } else if(i%%12 == 5){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_may
    
  } else if(i%%12 == 6){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_jun
    
  } else if(i%%12 == 7){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_jul
    
  } else if(i%%12 == 8){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_aug
    
  } else if(i%%12 == 9){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_sep
    
  } else if(i%%12 == 10){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_oct
    
  } else if(i%%12 == 11){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_nov
    
  } else if(i%%12 == 0){
    xx_p3_bias[[i]] = xx_p3[[i]] * ls_dec
    
  }  else {
    NULL
  }
  
}

xx_p3_bias = stack(xx_p3_bias)

plot(xx_p3_bias[[1]])
plot(xx_p3[[1]])
plot(yy_p3[[1]])
plot((yy_p3[[1]]-xx_p3[[1]])/xx_p3[[1]])
plot((yy_p3[[1]]-xx_p3_bias[[1]])/xx_p3_bias[[1]])


plot(ls_dec)

st_lr2 = stack(st_lr1_jan1,st_lr1_feb1,st_lr1_mar1,st_lr1_apl1,
               st_lr1_may1,st_lr1_jun1,st_lr1_jul1,st_lr1_aug1,
               st_lr1_sep1,st_lr1_oct1,st_lr1_nov1,st_lr1_dec1)


y <- overlay(s, s, fun=function(x, y) { sqrt(x^2 + y^2) } )



#memory allocation
if(.Platform$OS.type == "windows") withAutoprint({
  memory.size()
  memory.size(TRUE)
  memory.limit()
})
memory.limit(size=56000)

gc()

plot(xx[[3]])
# xx = sch_5_p1[[433:864]]
#focal extract
# vxx <- getValuesFocal(xx, 1, nrow(xx), ngb=w, na.rm=T, pad =T)
vyy <- getValuesFocal(yy_p3, 1, nrow(yy), ngb=w, na.rm =T, pad =F)
vzz <- getValuesFocal(dem_m1_p1, 1, nrow(dem_m1_p1), ngb=w, na.rm =T, pad =F)
vxx <- getValuesFocal(xx_p3_bias, 1, nrow(xx_p3_bias), ngb=w, na.rm =T, pad =F)

plot(vxx[[1]])

#seperating neighbour pixels
vyy_ex1 <- lapply(vyy,"[",1:1512,2)
# vxx_ex20 <- lapply(vxx,"[",1:1512,20)
# vxx_ex10 <- lapply(vxx,"[",1:1512,10)
vzz_ex1 <- lapply(vzz,"[",1:1512,1)

# vv1 = as.matrix(vxx_ex1[[1]])
# vv1
# vall = cbind(vxx_ex1,vxx_ex2,vxx_ex3,vyy_ex1)

st_ras = raster(ncol=27, nrow = 56)

x = xx_p3_bias[[1]]
plot(x)

f_y1 =list()
f_z1 = list()
f_fit1 = list()
# f_fit[[1:2]] <- raster(x)
# test_ras=list()
# 
# extent(x)=extent(r3)
# crs(x) = crs(r3)

fit1 =rep(NA,nrow(vxx[[1]]))
for (j in 1:180){
  fit1 =rep(NA,nrow(vxx[[1]]))
  for (k in 1:3604){
    y1 = vxx[[j]][k,]
    x1 = vzz[[j]][k,]
    xy = na.omit(data.frame(x = x1, y =y1))
    if (nrow(xy)>4){
      fit1[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
    }
    else{
      fit1[k] = NA
    }
  }
  f_fit1[[j]] <- raster(x)
  values(f_fit1[[j]])=fit1
  print(j)
}

plot(f_fit1[[160]])

st_lr1_p3 = stack(f_fit1)

# st_lr1_n2 = st_lr1_n1*100


sch_5_p1 = stack(yy,xx,st_lr1_n1)

# save(sch_5,'F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4.RData')
save(sch_5_p1, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5_p1.RData")


yy = sch_5[[1:432]]
# yy1 = stack(mask(yy,basin_p1))

# proj4string(s1_gcm_all) <- utm47Q
# extent(s1_gcm_all) = ap_5km


# projection(b) <- "+init=epsg:28992"
# transform to longitude/latitude
# eqcyl = CRS("+init=epsg:4087")
# yy1_p <- projectRaster(yy, crs = eqcyl, method='ngb')
# proj4string(yy) <- eqcyl


# yy_p = spTransform(yy[[1]], eqcyl)

# projection(yy1) <- CRS("+init=epsg:4087")



xx = sch_5[[433:864]]

# xx1_p <- projectRaster(xx, crs = eqcyl, method='ngb')

# xx1 = stack(mask(xx,basin_p1))

st_lr1 = sch_5[[865:1296]]
# st_lr1_p <- projectRaster(st_lr1, crs = eqcyl, method='ngb')

# st_lr1_s = stack(mask(st_lr1,basin_p1))

xx1_p1 = list();
st_lr1_p1 =list();

for (i in 1:432){
  #241:432
  print(i)
  # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  xx1_p1[[i]] = resample(xx1_p[[i]],yy1_p[[1]],'bilinear')
  st_lr1_p1[[i]] = resample(st_lr1_p[[i]],yy1_p[[1]],'bilinear')
}



xx1_p2 = stack(xx1_p1)
st_lr1_p2 = stack(st_lr1_p1)
yy1_p2 = stack(yy1_p)



plot(st_lr1_p[[1]])


# s1_gcm_all = s1_gcm1_c[[1:23741]]*86400

#fitting month sequence
jun = seq(6,180,12)
jul = seq(7,180,12)
aug = seq(8,180,12)
sep = seq(9,180,12)
oct = seq(10,180,12)
nov = seq(11,180,12)
dec = seq(12,180,12)
jan = seq(1,180,12)
feb = seq(2,180,12)
mar = seq(3,180,12)
apl = seq(4,180,12)
may = seq(5,180,12)

m_seq = seq(1,360,36)

jun2 = seq(6,360,12)
jul2 = seq(7,360,12)
aug2 = seq(8,360,12)
sep2 = seq(9,360,12)
oct2 = seq(10,360,12)
nov2 = seq(11,360,12)
dec2 = seq(12,360,12)
jan2 = seq(1,360,12)
feb2 = seq(2,360,12)
mar2 = seq(3,360,12)
apl2 = seq(4,360,12)
may2 = seq(5,360,12)

b_mjj <- c()
b_aso <- c()
b_ndjfma <- c()
for (i in 1:430){
  if(i%%12 == 5){
    b_mjj <- c(b_mjj, i)
    b_mjj <- c(b_mjj, i+1)
    b_mjj <- c(b_mjj, i+2)
    
  } 
  
}
for (i in 1:430){
  if(i%%12 == 8){
    b_aso <- c(b_aso, i)
    b_aso <- c(b_aso, i+1)
    b_aso <- c(b_aso, i+2)
  } 
}
for (i in 1:428){
  if(i%%12 == 11){
    b_ndjfma <- c(b_ndjfma, i)
    b_ndjfma <- c(b_ndjfma, i+1)
    b_ndjfma <- c(b_ndjfma, i+2)
    b_ndjfma <- c(b_ndjfma, i+3)
    b_ndjfma <- c(b_ndjfma, i+4)
  } 
}
#future
f_mjj <- c()
f_aso <- c()
f_ndjfma <- c()
for (i in 1:358){
  if(i%%12 == 5){
    f_mjj <- c(f_mjj, i)
    f_mjj <- c(f_mjj, i+1)
    f_mjj <- c(f_mjj, i+2)
  } 
}
for (i in 1:358){
  if(i%%12 == 8){
    f_aso <- c(f_aso, i)
    f_aso <- c(f_aso, i+1)
    f_aso <- c(f_aso, i+2)
  } 
}
for (i in 1:356){
  if(i%%12 == 11){
    f_ndjfma <- c(f_ndjfma, i)
    f_ndjfma <- c(f_ndjfma, i+1)
    f_ndjfma <- c(f_ndjfma, i+2)
    f_ndjfma <- c(f_ndjfma, i+3)
    f_ndjfma <- c(f_ndjfma, i+4)
  } 
}




st_lr1_jan = st_lr1[[jan]]
st_lr1_feb = st_lr1[[feb]]
st_lr1_mar = st_lr1[[mar]]
st_lr1_apl = st_lr1[[apl]]
st_lr1_may = st_lr1[[may]]
st_lr1_jun = st_lr1[[jun]]
st_lr1_jul = st_lr1[[jul]]
st_lr1_aug = st_lr1[[aug]]
st_lr1_sep = st_lr1[[sep]]
st_lr1_oct = st_lr1[[oct]]
st_lr1_nov = st_lr1[[nov]]
st_lr1_dec = st_lr1[[dec]]

st_lr1_jan1 <- calc(st_lr1_jan, fun = mean)
st_lr1_feb1 <- calc(st_lr1_feb, fun = mean)
st_lr1_mar1 <- calc(st_lr1_mar, fun = mean)
st_lr1_apl1 <- calc(st_lr1_apl, fun = mean)
st_lr1_may1 <- calc(st_lr1_may, fun = mean)
st_lr1_jun1 <- calc(st_lr1_jun, fun = mean)
st_lr1_jul1 <- calc(st_lr1_jul, fun = mean)
st_lr1_aug1 <- calc(st_lr1_aug, fun = mean)
st_lr1_sep1 <- calc(st_lr1_sep, fun = mean)
st_lr1_oct1 <- calc(st_lr1_oct, fun = mean)
st_lr1_nov1 <- calc(st_lr1_nov, fun = mean)
st_lr1_dec1 <- calc(st_lr1_dec, fun = mean)

st_lr2 = stack(st_lr1_jan1,st_lr1_feb1,st_lr1_mar1,st_lr1_apl1,
               st_lr1_may1,st_lr1_jun1,st_lr1_jul1,st_lr1_aug1,
               st_lr1_sep1,st_lr1_oct1,st_lr1_nov1,st_lr1_dec1)

st_lr3 = stack(replicate(36, st_lr2))
plot(st_lr3[[2]])
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_feb = stack(replicate(30, st_lr1_feb1))
# st_lr2_mar = stack(replicate(30, st_lr1_mar1))
# st_lr2_apl = stack(replicate(30, st_lr1_apl1))
# st_lr2_may = stack(replicate(30, st_lr1_may1))
# st_lr2_jun = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))


#---functions

# fun2=function(x) { if (is.na(x[1])){ NA } else { cochrane.orcutt(lm(x[1:36] ~ x[37:72]+x[73:108]))$coefficients[2] }}
# fun3 <- function(x) { lm(x ~ v1)$coefficients[2] }
# # x2 <- calc(s, fun)
fun4 = function(x) { if (is.na(x[1])){ NA } else { m <- lm(x[1:36] ~ x[37:72]+x[73:108]);summary(m)$coefficients[,1]}}

fun1 <- function(x) { if (is.na(x[1])){ NA }
  else { lm(x[1:36] ~ x[37:72]+x[73:108])$coefficients[1]}}

nlayers = 15

coeffun <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[16:30]
  x2 <- x[31:45]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1) & !is.na(x2))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(obs[x.nona] ~ x1[x.nona] + x2[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1:3]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}

coeffun_nonl <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[16:30]
  # x2 <- x[73:108]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(obs[x.nona] ~ x1[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1:2]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}


# fun1 <- function(x) { if (is.na(x[1]))
# { NA } 
#   else {model = summary(lm(x[1:36] ~ x[37:72]));model$r.squared}}
# 
# fun2 <- function(x) { model <- summary(lm(x ~ time)); c(model$coefficients[2,1], model$r.squared) }
# x2 <- calc(s, fun2)
#---stacking------------

c2 = (yy1[[jan]])
v1 = xx1[[jan]]

p1 = calc(c2, fun3)

s2 = stack(yy1_p2[[jan]],xx1_p2[[jan]],st_lr1_p2[[jan]])

all(is.na(yy1_p2))
all(is.na(xx1_p2))
all(is.na(st_lr1_p2))


sch_jan3 = stack(yy_p3[[jan]],xx_p3_bias[[jan]],st_lr1_p3[[jan]])
sch_feb3 = stack(yy_p3[[feb]],xx_p3_bias[[feb]],st_lr1_p3[[feb]])
sch_mar3 = stack(yy_p3[[mar]],xx_p3_bias[[mar]],st_lr1_p3[[mar]])
sch_apl3 = stack(yy_p3[[apl]],xx_p3_bias[[apl]],st_lr1_p3[[apl]])
sch_may3 = stack(yy_p3[[may]],xx_p3_bias[[may]],st_lr1_p3[[may]])
sch_jun3 = stack(yy_p3[[jun]],xx_p3_bias[[jun]],st_lr1_p3[[jun]])
sch_jul3 = stack(yy_p3[[jul]],xx_p3_bias[[jul]],st_lr1_p3[[jul]])
sch_aug3 = stack(yy_p3[[aug]],xx_p3_bias[[aug]],st_lr1_p3[[aug]])
sch_sep3 = stack(yy_p3[[sep]],xx_p3_bias[[sep]],st_lr1_p3[[sep]])
sch_oct3 = stack(yy_p3[[oct]],xx_p3_bias[[oct]],st_lr1_p3[[oct]])
sch_nov3 = stack(yy_p3[[nov]],xx_p3_bias[[nov]],st_lr1_p3[[nov]])
sch_dec3 = stack(yy_p3[[dec]],xx_p3_bias[[dec]],st_lr1_p3[[dec]])

sch_jan3_nonl = stack(yy_p3[[jan]],xx_p3_bias[[jan]])
sch_feb3_nonl = stack(yy_p3[[feb]],xx_p3_bias[[feb]])
sch_mar3_nonl = stack(yy_p3[[mar]],xx_p3_bias[[mar]])
sch_apl3_nonl = stack(yy_p3[[apl]],xx_p3_bias[[apl]])
sch_may3_nonl = stack(yy_p3[[may]],xx_p3_bias[[may]])
sch_jun3_nonl = stack(yy_p3[[jun]],xx_p3_bias[[jun]])
sch_jul3_nonl = stack(yy_p3[[jul]],xx_p3_bias[[jul]])
sch_aug3_nonl = stack(yy_p3[[aug]],xx_p3_bias[[aug]])
sch_sep3_nonl = stack(yy_p3[[sep]],xx_p3_bias[[sep]])
sch_oct3_nonl = stack(yy_p3[[oct]],xx_p3_bias[[oct]])
sch_nov3_nonl = stack(yy_p3[[nov]],xx_p3_bias[[nov]])
sch_dec3_nonl = stack(yy_p3[[dec]],xx_p3_bias[[dec]])

#------------parameter estimation----------
par_jan3 <- calc(sch_jan3, coeffun)
par_feb3 <- calc(sch_feb3, coeffun)
par_mar3 <- calc(sch_mar3, coeffun)
par_apl3 <- calc(sch_apl3, coeffun)
par_may3 <- calc(sch_may3, coeffun)
par_jun3 <- calc(sch_jun3, coeffun)
par_jul3 <- calc(sch_jul3, coeffun)
par_aug3 <- calc(sch_aug3, coeffun)
par_sep3 <- calc(sch_sep3, coeffun)
par_oct3 <- calc(sch_oct3, coeffun)
par_nov3 <- calc(sch_nov3, coeffun)
par_dec3 <- calc(sch_dec3, coeffun)

par_jan3_nonl <- calc(sch_jan3_nonl, coeffun_nonl)
par_feb3_nonl <- calc(sch_feb3_nonl, coeffun_nonl)
par_mar3_nonl <- calc(sch_mar3_nonl, coeffun_nonl)
par_apl3_nonl <- calc(sch_apl3_nonl, coeffun_nonl)
par_may3_nonl <- calc(sch_may3_nonl, coeffun_nonl)
par_jun3_nonl <- calc(sch_jun3_nonl, coeffun_nonl)
par_jul3_nonl <- calc(sch_jul3_nonl, coeffun_nonl)
par_aug3_nonl <- calc(sch_aug3_nonl, coeffun_nonl)
par_sep3_nonl <- calc(sch_sep3_nonl, coeffun_nonl)
par_oct3_nonl <- calc(sch_oct3_nonl, coeffun_nonl)
par_nov3_nonl <- calc(sch_nov3_nonl, coeffun_nonl)
par_dec3_nonl <- calc(sch_dec3_nonl, coeffun_nonl)
#-----------------
plot(par_jan3_nonl[[1]])

save(par_jan3, par_feb3, par_mar3,
     par_apl3,par_may3,par_jun3,
     par_jul3,par_aug3,par_sep3,
     par_oct3,par_nov3,par_dec3,
     file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1.RData")

save(par_jan3_nonl, par_feb3_nonl, par_mar3_nonl,
     par_apl3_nonl,par_may3_nonl,par_jun3_nonl,
     par_jul3_nonl,par_aug3_nonl,par_sep3_nonl,
     par_oct3_nonl,par_nov3_nonl,par_dec3_nonl,
     file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1_nonl.RData")


plot(par_jan3[[7]])

# save(sch_5, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5.RData")

summary_feb <- calc(sch_jan2, fun1, forceapply=TRUE)

summary_mar <- calc(sch_mar, fun1)
summary_apl <- calc(sch_apl, fun1)

summary_jul <- calc(sch_jul, fun1)

summary_aug <- calc(sch_aug, fun1)
summary_jan <- calc(sch_jan, fun1)
summary_feb <- calc(sch_feb, fun1)

summary_mar <- calc(sch_mar, fun1)
summary_apl <- calc(sch_apl, fun1)

summary_jul <- calc(sch_jul, fun1)

summary_aug <- calc(sch_aug, fun1)

plot(summary_aug)



r <- raster(ncols=36, nrows=18)
r[] <- 1:ncell(r)
s <- stack(r, r*2, sqrt(r))

# regression of values in one brick (or stack) with 'time'
time <- 1:nlayers(s)
fun <- function(x) { lm(x ~ time)$coefficients[2] }
x2 <- calc(s, fun)
# To get slope and r.squared, you'd need to adapt the function a little

fun2 <- function(x) { model <- summary(lm(x ~ time)); c(model$coefficients[2,1], model$r.squared) }
x2 <- calc(s, fun2)

#----feb

rcmv_r = list()
apv_r = list()
# lp_r = list()
rcm_p_nolr =list()
rcm_f26 =list()
pred_rcm1_3p = list();

for (i in 1:180){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  
  if(i%%12 == 1){
    pred_rcm1_3p[[i]] = (par_jan3[[3]] * st_lr1_p3[[i]])+(par_jan3[[2]] * xx_p3_bias[[i]])+ par_jan3[[1]]
    
  } else if(i%%12 == 2){
    pred_rcm1_3p[[i]] = (par_feb3[[3]] * st_lr1_p3[[i]])+(par_feb3[[2]] * xx_p3_bias[[i]])+ par_feb3[[1]]
    
  } else if(i%%12 == 3){
    pred_rcm1_3p[[i]] = (par_mar3[[3]] * st_lr1_p3[[i]])+(par_mar3[[2]] * xx_p3_bias[[i]])+ par_mar3[[1]]
    
  } else if(i%%12 == 4){
    pred_rcm1_3p[[i]] = (par_apl3[[3]] * st_lr1_p3[[i]])+(par_apl3[[2]] * xx_p3_bias[[i]])+ par_apl3[[1]]
    
  } else if(i%%12 == 5){
    pred_rcm1_3p[[i]] = (par_may3[[3]] * st_lr1_p3[[i]])+(par_may3[[2]] * xx_p3_bias[[i]])+ par_may3[[1]]
    
  } else if(i%%12 == 6){
    pred_rcm1_3p[[i]] = (par_jun3[[3]] * st_lr1_p3[[i]])+(par_jun3[[2]] * xx_p3_bias[[i]])+ par_jun3[[1]]
    
  } else if(i%%12 == 7){
    pred_rcm1_3p[[i]] = (par_jul3[[3]] * st_lr1_p3[[i]])+(par_jul3[[2]] * xx_p3_bias[[i]])+ par_jul3[[1]]
    
  } else if(i%%12 == 8){
    pred_rcm1_3p[[i]] = (par_aug3[[3]] * st_lr1_p3[[i]])+(par_aug3[[2]] * xx_p3_bias[[i]])+ par_aug3[[1]]
    
  } else if(i%%12 == 9){
    pred_rcm1_3p[[i]] = (par_sep3[[3]] * st_lr1_p3[[i]])+(par_sep3[[2]] * xx_p3_bias[[i]])+ par_sep3[[1]]
    
  } else if(i%%12 == 10){
    pred_rcm1_3p[[i]] = (par_oct3[[3]] * st_lr1_p3[[i]])+(par_oct3[[2]] * xx_p3_bias[[i]])+ par_oct3[[1]]
    
  } else if(i%%12 == 11){
    pred_rcm1_3p[[i]] = (par_nov3[[3]] * st_lr1_p3[[i]])+(par_nov3[[2]] * xx_p3_bias[[i]])+ par_nov3[[1]]
    
  } else if(i%%12 == 0){
    pred_rcm1_3p[[i]] = (par_dec3[[3]] * st_lr1_p3[[i]])+(par_dec3[[2]] * xx_p3_bias[[i]])+ par_dec3[[1]]
    
  }  else {
    NULL
  }
  
}

pred_rcm1_2p = list();

for (i in 1:180){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  
  if(i%%12 == 1){
    pred_rcm1_2p[[i]] = (par_jan3_nonl[[2]] * xx_p3_bias[[i]])+ par_jan3_nonl[[1]]
    
  } else if(i%%12 == 2){
    pred_rcm1_2p[[i]] = (par_feb3_nonl[[2]] * xx_p3_bias[[i]])+ par_feb3_nonl[[1]]
    
  } else if(i%%12 == 3){
    pred_rcm1_2p[[i]] = (par_mar3_nonl[[2]] * xx_p3_bias[[i]])+ par_mar3_nonl[[1]]
    
  } else if(i%%12 == 4){
    pred_rcm1_2p[[i]] = (par_apl3_nonl[[2]] * xx_p3_bias[[i]])+ par_apl3_nonl[[1]]
    
  } else if(i%%12 == 5){
    pred_rcm1_2p[[i]] = (par_may3_nonl[[2]] * xx_p3_bias[[i]])+ par_may3_nonl[[1]]
    
  } else if(i%%12 == 6){
    pred_rcm1_2p[[i]] = (par_jun3_nonl[[2]] * xx_p3_bias[[i]])+ par_jun3_nonl[[1]]
    
  } else if(i%%12 == 7){
    pred_rcm1_2p[[i]] = (par_jul3_nonl[[2]] * xx_p3_bias[[i]])+ par_jul3_nonl[[1]]
    
  } else if(i%%12 == 8){
    pred_rcm1_2p[[i]] = (par_aug3_nonl[[2]] * xx_p3_bias[[i]])+ par_aug3_nonl[[1]]
    
  } else if(i%%12 == 9){
    pred_rcm1_2p[[i]] = (par_sep3_nonl[[2]] * xx_p3_bias[[i]])+ par_sep3_nonl[[1]]
    
  } else if(i%%12 == 10){
    pred_rcm1_2p[[i]] = (par_oct3_nonl[[2]] * xx_p3_bias[[i]])+ par_oct3_nonl[[1]]
    
  } else if(i%%12 == 11){
    pred_rcm1_2p[[i]] = (par_nov3_nonl[[2]] * xx_p3_bias[[i]])+ par_nov3_nonl[[1]]
    
  } else if(i%%12 == 0){
    pred_rcm1_2p[[i]] = (par_dec3_nonl[[2]] * xx_p3_bias[[i]])+ par_dec3_nonl[[1]]
    
  }  else {
    NULL
  }
  
}

# rcm_f85 =list()
# 
# for (i in 1:360){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
#   if(i%%12 == 1){
#     rcm_f85[[i]] = (par_jan2[[3]] * st_lr1_jan1[[1]])+(par_jan2[[2]] * month_rcm_f85_r[[i]])+ par_jan2[[1]]
#     
#   } else if(i%%12 == 2){
#     rcm_f85[[i]] = (par_feb2[[3]] * st_lr1_feb1[[1]])+(par_feb2[[2]] * month_rcm_f85_r[[i]])+ par_feb2[[1]]
#     
#   } else if(i%%12 == 3){
#     rcm_f85[[i]] = (par_mar2[[3]] * st_lr1_mar1[[1]])+(par_mar2[[2]] * month_rcm_f85_r[[i]])+ par_mar2[[1]]
#     
#   } else if(i%%12 == 4){
#     rcm_f85[[i]] = (par_apl2[[3]] * st_lr1_apl1[[1]])+(par_apl2[[2]] * month_rcm_f85_r[[i]])+ par_apl2[[1]]
#     
#   } else if(i%%12 == 5){
#     rcm_f85[[i]] = (par_may2[[3]] * st_lr1_may1[[1]])+(par_may2[[2]] * month_rcm_f85_r[[i]])+ par_may2[[1]]
#     
#   } else if(i%%12 == 6){
#     rcm_f85[[i]] = (par_jun2[[3]] * st_lr1_jun1[[1]])+(par_jun2[[2]] * month_rcm_f85_r[[i]])+ par_jun2[[1]]
#     
#   } else if(i%%12 == 7){
#     rcm_f85[[i]] = (par_jul2[[3]] * st_lr1_jul1[[1]])+(par_jul2[[2]] * month_rcm_f85_r[[i]])+ par_jul2[[1]]
#     
#   } else if(i%%12 == 8){
#     rcm_f85[[i]] = (par_aug2[[3]] * st_lr1_aug1[[1]])+(par_aug2[[2]] * month_rcm_f85_r[[i]])+ par_aug2[[1]]
#     
#   } else if(i%%12 == 9){
#     rcm_f85[[i]] = (par_sep2[[3]] * st_lr1_sep1[[1]])+(par_sep2[[2]] * month_rcm_f85_r[[i]])+ par_sep2[[1]]
#     
#   } else if(i%%12 == 10){
#     rcm_f85[[i]] = (par_oct2[[3]] * st_lr1_oct1[[1]])+(par_oct2[[2]] * month_rcm_f85_r[[i]])+ par_oct2[[1]]
#     
#   } else if(i%%12 == 11){
#     rcm_f85[[i]] = (par_nov2[[3]] * st_lr1_nov1[[1]])+(par_nov2[[2]] * month_rcm_f85_r[[i]])+ par_nov2[[1]]
#     
#   } else if(i%%12 == 0){
#     rcm_f85[[i]] = (par_dec2[[3]] * st_lr1_dec1[[1]])+(par_dec2[[2]] * month_rcm_f85_r[[i]])+ par_dec2[[1]]
#     
#   }  else {
#     NULL
#   }
#   
# }

pred_rcm1_2p_s = stack(pred_rcm1_2p)
pred_rcm1_3p_s = stack(pred_rcm1_3p)

stat_ras_bl_s = stack(yy_p3_s, xx_p3_bias)
stat_ras_2p_s = stack(yy_p3_s, pred_rcm1_2p_s)
stat_ras_3p_s= stack(yy_p3_s, pred_rcm1_3p_s)

fun_mae_nolr <- function(x) {mean(abs((x[1:180] - x[181:360])))}
sd_mae_nolr <- calc(stat_ras_2p_s, fun_mae_nolr)

plot(sd_mae_nolr)

#rmse
fun_sqrt_nolr <- function(x) {sqrt(mean((x[1:180] - x[181:360])^2))}
sd_sqrt_nolr <- calc(stat_ras_2p_s, fun_sqrt_nolr)

plot(sd_sqrt_nolr)

#r2

# function(x, y) summary(lm(y~x))$r.squared
# fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
# sd_r2 <- calc(stat_ras, fun_r2)
# 
# plot(sd_r2)

fun_mae <- function(x) {mean(abs((x[1:180] - x[181:360])))}
sd_mae <- calc(stat_ras_3p_s, fun_mae)

plot(sd_mae)

#rmse
fun_sqrt <- function(x) {sqrt(mean((x[1:180] - x[181:360])^2))}
sd_sqrt <- calc(stat_ras_3p_s, fun_sqrt)

plot(sd_sqrt)

#bilinear
fun_mae_bl <- function(x) {mean(abs((x[1:180] - x[181:360])))}
sd_mae_bl <- calc(stat_ras_bl_s, fun_mae_bl)

plot(sd_mae_bl)

#rmse
fun_sqrt_bl <- function(x) {sqrt(mean((x[1:180] - x[181:360])^2))}
sd_sqrt_bl <- calc(stat_ras_bl_s, fun_sqrt_bl)

plot(sd_sqrt_bl)


plot(((sd_sqrt-sd_sqrt_nolr)/(sd_sqrt_nolr))*100)

#r2

# function(x, y) summary(lm(y~x))$r.squared
fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
sd_r2 <- calc(stat_ras_2p, fun_r2)




plot(rcm_f85[[3250]])
plot(month_rcm_f85_r[[350]])



# for (i in 1:360){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   month_rcm_f26_r[[i]] = resample(rcm_f26[[i]],r3,'bilinear')
# }
# 
# for (i in 1:360){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   month_rcm_f85_r[[i]] = resample(rcm_f85[[i]],r3,'bilinear')
# }



#calcualte seaon avg
rcm_f26_mjj = rcm_f26_s[[f_mjj]]
rcm_f26_aso = rcm_f26_s[[f_aso]]
rcm_f26_ndjfma = rcm_f26_s[[f_ndjfma]]

rcm_f26_mjj1 <- calc(rcm_f26_mjj, fun = mean)
rcm_f26_aso1 <- calc(rcm_f26_aso, fun = mean)
rcm_f26_ndjfma1 <- calc(rcm_f26_ndjfma, fun = mean)

rcm_f85_mjj = rcm_f85_s[[f_mjj]]
rcm_f85_aso = rcm_f85_s[[f_aso]]
rcm_f85_ndjfma = rcm_f85_s[[f_ndjfma]]

rcm_f85_mjj1 <- calc(rcm_f85_mjj, fun = mean)
rcm_f85_aso1 <- calc(rcm_f85_aso, fun = mean)
rcm_f85_ndjfma1 <- calc(rcm_f85_ndjfma, fun = mean)


#apv
ap_mjj = month_ap_r[[b_mjj]]
ap_aso = month_ap_r[[b_aso]]
ap_ndjfma = month_ap_r[[b_ndjfma]]

ap_mjj1 <- calc(ap_mjj, fun = mean)
ap_aso1 <- calc(ap_aso, fun = mean)
ap_ndjfma1 <- calc(ap_ndjfma, fun = mean)

plot(ap_mjj1)
