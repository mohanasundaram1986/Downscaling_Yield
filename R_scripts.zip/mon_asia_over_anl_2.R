library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)
library(ncdf4)

library(raster)
library(gstat)
library(sp)

setwd('G:/OneDrive/AIT/papers/workspace/')
TEMP = "G:/OneDrive/AIT/papers/workspace"
tempdir()
# setwd('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5_p1_n1.RData')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_2.RData')
# basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3.shp")
# # basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s1_n4.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")


basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia5.shp")
basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia4.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s2.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s4.shp")
# basin10 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s10.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_seg_sw.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")
sea = readOGR("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/gis/sea_count_sa.shp")
# fishnet1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2_df <- fortify(fishnet2)

sam <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")

basin_p=basin
basin_p1=basin1
basin_p2=basin2
basin_p3=basin3
basin_p4=basin4
basin_p10=basin10
plot(basin_p2)

yld_corr = read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")
yld_cr1 = read_excel("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_comp1.xlsx","mean")
yld_cr3 = read_excel("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_comp1.xlsx","max")

# p1 <- "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model_et/"
# R1 <- list.files(p1, pattern = "tif$",full.names = TRUE)


# y2000 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model_et/model_et2_2001.tif")
# y2000_m = mask(y2000,sea)
y2000 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2000.tif")
y2001 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2001.tif")
y2002 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2002.tif")
y2003 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2003.tif")
y2004 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2004.tif")
y2005 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2005.tif")
y2006 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/lai_2006.tif")
y2007 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2007.tif")
y2008 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2008.tif")
y2009 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2009.tif")
y2010 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2010.tif")
y2011 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/ndvi_2011.tif")
y2012 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2012.tif")
y2013 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/ndvi_2013.tif")
y2014 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2014.tif")
y2015 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2015.tif")


y2000 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2000.tif")
y2001 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2001.tif")
y2002 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2002.tif")
y2003 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2003.tif")
y2004 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2004.tif")
y2005 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2005.tif")
y2006 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/lai_2006.tif")
y2007 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2007.tif")
y2008 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2008.tif")
y2009 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2009.tif")
y2010 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2010.tif")
y2011 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/ndvi_2011.tif")
y2012 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2012.tif")
y2013 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/ndvi_2013.tif")
y2014 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/evi_2014.tif")
y2015 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/param_sel/gpp_2015.tif")

plot(y2015)

yy2000 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2000.tif")
yy2001 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2001.tif")
yy2002 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2002.tif")
yy2003 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2003.tif")
yy2004 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2004.tif")
yy2005 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2005.tif")
yy2006 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2006.tif")
yy2007 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2007.tif")
yy2008 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2008.tif")
yy2009 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2009.tif")
yy2010 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2010.tif")
yy2011 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2011.tif")
yy2012 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2012.tif")
yy2013 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2013.tif")
yy2014 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2014.tif")
yy2015 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2015.tif")

yy2000 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2000.tif")
yy2001 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2001.tif")
yy2002 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2002.tif")
yy2003 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2003.tif")
yy2004 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2004.tif")
yy2005 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2005.tif")
yy2006 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2006.tif")
yy2007 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2007.tif")
yy2008 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2008.tif")
yy2009 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2009.tif")
yy2010 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2010.tif")
yy2011 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2011.tif")
yy2012 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2012.tif")
yy2013 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2013.tif")
yy2014 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2014.tif")
yy2015 = raster("H:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2015.tif")

plot(yy2015)


install.packages("zoo")                            # Install zoo package
library("zoo")  

stepsize = (y2000@extent@ymax - y2000@extent@ymin) / y2000@nrows
y_y2000 = seq(y2000@extent@ymax - stepsize / 2, y2000@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2000 = data.frame(y_y2000)
x_y2000 = data.frame(rowMeans(as.matrix(y2000), na.rm = TRUE))
xx_y2000 = data.frame(rowMeans(as.matrix(yy2000), na.rm = TRUE))
# Then you add this to your existing plot:
x_2000_ma=rollmean(x_y2000, k = 200)
xx_2000_ma=rollmean(xx_y2000, k = 200)
data_y2000<- data.frame(x_2000_ma,xx_2000_ma,x_y2000[1:length(x_2000_ma[,1]),1],
                        xx_y2000[1:length(x_2000_ma[,1]),1],y_y2000[1:length(x_2000_ma[,1]),1])


data1 <- data.frame(data_y2000[,3],data_y2001[,3],data_y2002[,3],
                    data_y2003[,3],data_y2004[,3],data_y2005[,3],
                    data_y2006[,3],data_y2007[,3],data_y2008[,3],
                    data_y2009[,3],data_y2010[,3],data_y2011[,3],
                    data_y2012[,3],data_y2013[,3],data_y2014[,3],
                    data_y2015[,3])
                    
library(reshape)
meltData <- melt(data1)

tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/a.tiff", units="in", width=6, height=5, res=400)

boxplot(data_y2000[,3],data_y2001[,3],data_y2002[,3],data_y2002[,3],
        data_y2004[,3],data_y2005[,3],data_y2006[,3],data_y2007[,3],
        data_y2008[,3],data_y2009[,3],data_y2010[,3],data_y2011[,3],
        data_y2012[,3],data_y2013[,3],data_y2014[,3],data_y2015[,3],
        names = c("2000\nGPP","2001\nEVI","2002\nGPP","2003\nEVI",
                  "2004\nGPP","2005\nGPP","2006\nLAI","2007\nEVI",
                  "2008\nEVI","2009\nGPP","2010\nGPP","2011\nNDVI",
                  "2012\nEVI","2013\nNDVI","2014\nEVI","2015\nGPP"),ylab='EVI[-] /NDVI[-] /LAI[-] /GPP[kgC/m2]')

dev.off()
tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/b.tiff", units="in", width=6, height=5, res=400)

# tick <- seq_along(tmp$names)
# axis(1, at = tick, labels = F)
# text(tick, par("usr")[3] - 0.3, tmp$names, srt = 90, xpd = T)

boxplot(data_y2000[,4],data_y2001[,4],data_y2002[,4],data_y2002[,4],
        data_y2004[,4],data_y2005[,4],data_y2006[,4],data_y2007[,4],
        data_y2008[,4],data_y2009[,4],data_y2010[,4],data_y2011[,4],
        data_y2012[,4],data_y2013[,4],data_y2014[,4],data_y2015[,4],
        names = c("2000","2001","2002","2003",
                  "2004","2005","2006","2007",
                  "2008","2009","2010","2011",
                  "2012","2013","2014","2015"),ylab='Rice Yield [t/ha]')

dev.off()


colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2000=ggplot(data_y2000)+
  geom_point(aes(x=data_y2000[,3],y=data_y2000[,5],color="GPP"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2000[,1],y=data_y2000[,5],color="Mavg_GPP"),size=0.5)+
  ggtitle("2000")+
  xlab("GPP[kgC/m2]") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a2000
b2000=ggplot(data_y2000)+
  geom_point(aes(x=data_y2000[,4],y=data_y2000[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2000[,2],y=data_y2000[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2000")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000
#---2001
stepsize = (y2001@extent@ymax - y2001@extent@ymin) / y2001@nrows
y_y2001 = seq(y2001@extent@ymax - stepsize / 2, y2001@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2001 = data.frame(y_y2001)
x_y2001 = data.frame(rowMeans(as.matrix(y2001), na.rm = TRUE))
xx_y2001 = data.frame(rowMeans(as.matrix(yy2001), na.rm = TRUE))
# Then you add this to your existing plot:
x_2001_ma=rollmean(x_y2001, k = 200)
xx_2001_ma=rollmean(xx_y2001, k = 200)
data_y2001<- data.frame(x_2001_ma,xx_2001_ma,x_y2001[1:length(x_2001_ma[,1]),1],
                        xx_y2001[1:length(x_2001_ma[,1]),1],y_y2001[1:length(x_2001_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2001=ggplot(data_y2001)+
  geom_point(aes(x=data_y2001[,3],y=data_y2001[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2001[,1],y=data_y2001[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2001")+
  xlab("EVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors3)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2001=ggplot(data_y2001)+
  geom_point(aes(x=data_y2001[,4],y=data_y2001[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2001[,2],y=data_y2001[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2001")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2001

#----2002
stepsize = (y2002@extent@ymax - y2002@extent@ymin) / y2002@nrows
y_y2002 = seq(y2002@extent@ymax - stepsize / 2, y2002@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2002 = data.frame(y_y2002)
x_y2002 = data.frame(rowMeans(as.matrix(y2002), na.rm = TRUE))
xx_y2002 = data.frame(rowMeans(as.matrix(yy2002), na.rm = TRUE))
# Then you add this to your existing plot:
x_2002_ma=rollmean(x_y2002, k = 200)
xx_2002_ma=rollmean(xx_y2002, k = 200)
data_y2002<- data.frame(x_2002_ma,xx_2002_ma,x_y2002[1:length(x_2002_ma[,1]),1],
                        xx_y2002[1:length(x_2002_ma[,1]),1],y_y2002[1:length(x_2002_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2002=ggplot(data_y2002)+
  geom_point(aes(x=data_y2002[,3],y=data_y2002[,5],color="GPP"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2002[,1],y=data_y2002[,5],color="Mavg_GPP"),size=0.5)+
  ggtitle("2002")+
  xlab("GPP[kgC/m2]") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2002=ggplot(data_y2002)+
  geom_point(aes(x=data_y2002[,4],y=data_y2002[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2002[,2],y=data_y2002[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2002")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2003
stepsize = (y2003@extent@ymax - y2003@extent@ymin) / y2003@nrows
y_y2003 = seq(y2003@extent@ymax - stepsize / 2, y2003@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2003 = data.frame(y_y2003)
x_y2003 = data.frame(rowMeans(as.matrix(y2003), na.rm = TRUE))
xx_y2003 = data.frame(rowMeans(as.matrix(yy2003), na.rm = TRUE))
# Then you add this to your existing plot:
x_2003_ma=rollmean(x_y2003, k = 200)
xx_2003_ma=rollmean(xx_y2003, k = 200)
data_y2003<- data.frame(x_2003_ma,xx_2003_ma,x_y2003[1:length(x_2003_ma[,1]),1],
                        xx_y2003[1:length(x_2003_ma[,1]),1],y_y2003[1:length(x_2003_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2003=ggplot(data_y2003)+
  geom_point(aes(x=data_y2003[,3],y=data_y2003[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2003[,1],y=data_y2003[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2003")+
  xlab("EVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors3)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2003=ggplot(data_y2003)+
  geom_point(aes(x=data_y2003[,4],y=data_y2003[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2003[,2],y=data_y2003[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2003")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2004
stepsize = (y2004@extent@ymax - y2004@extent@ymin) / y2004@nrows
y_y2004 = seq(y2004@extent@ymax - stepsize / 2, y2004@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2004 = data.frame(y_y2004)
x_y2004 = data.frame(rowMeans(as.matrix(y2004), na.rm = TRUE))
xx_y2004 = data.frame(rowMeans(as.matrix(yy2004), na.rm = TRUE))
# Then you add this to your existing plot:
x_2004_ma=rollmean(x_y2004, k = 200)
xx_2004_ma=rollmean(xx_y2004, k = 200)
data_y2004<- data.frame(x_2004_ma,xx_2004_ma,x_y2004[1:length(x_2004_ma[,1]),1],
                        xx_y2004[1:length(x_2004_ma[,1]),1],y_y2004[1:length(x_2004_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2004=ggplot(data_y2004)+
  geom_point(aes(x=data_y2004[,3],y=data_y2004[,5],color="GPP"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2004[,1],y=data_y2004[,5],color="Mavg_GPP"),size=0.5)+
  ggtitle("2004")+
  xlab("GPP[kgC/m2]") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2004=ggplot(data_y2004)+
  geom_point(aes(x=data_y2004[,4],y=data_y2004[,5],color="Rice-Yield"))+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2004[,2],y=data_y2004[,5],color="Mavg_Rice-Yield"))+
  ggtitle("2004")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000
#----2005
stepsize = (y2005@extent@ymax - y2005@extent@ymin) / y2005@nrows
y_y2005 = seq(y2005@extent@ymax - stepsize / 2, y2005@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2005 = data.frame(y_y2005)
x_y2005 = data.frame(rowMeans(as.matrix(y2005), na.rm = TRUE))
xx_y2005 = data.frame(rowMeans(as.matrix(yy2005), na.rm = TRUE))
# Then you add this to your existing plot:
x_2005_ma=rollmean(x_y2005, k = 200)
xx_2005_ma=rollmean(xx_y2005, k = 200)
data_y2005<- data.frame(x_2005_ma,xx_2005_ma,x_y2005[1:length(x_2005_ma[,1]),1],
                        xx_y2005[1:length(x_2005_ma[,1]),1],y_y2005[1:length(x_2005_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2005=ggplot(data_y2005)+
  geom_point(aes(x=data_y2005[,3],y=data_y2005[,5],color="GPP"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2005[,1],y=data_y2005[,5],color="Mavg_GPP"),size=0.5)+
  ggtitle("2005")+
  xlab("GPP[kgC/m2]") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2005=ggplot(data_y2005)+
  geom_point(aes(x=data_y2005[,4],y=data_y2005[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2005[,2],y=data_y2005[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2005")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2006
stepsize = (y2006@extent@ymax - y2006@extent@ymin) / y2006@nrows
y_y2006 = seq(y2006@extent@ymax - stepsize / 2, y2006@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2006 = data.frame(y_y2006)
x_y2006 = data.frame(rowMeans(as.matrix(y2006), na.rm = TRUE))
xx_y2006 = data.frame(rowMeans(as.matrix(yy2006), na.rm = TRUE))
# Then you add this to your existing plot:
x_2006_ma=rollmean(x_y2006, k = 200)
xx_2006_ma=rollmean(xx_y2006, k = 200)
data_y2006<- data.frame(x_2006_ma,xx_2006_ma,x_y2006[1:length(x_2006_ma[,1]),1],
                        xx_y2006[1:length(x_2006_ma[,1]),1],y_y2006[1:length(x_2006_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2006=ggplot(data_y2006)+
  geom_point(aes(x=data_y2006[,3],y=data_y2006[,5],color="LAI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2006[,1],y=data_y2006[,5],color="Mavg_LAI"),size=0.5)+
  ggtitle("2006")+
  xlab("LAI") +
  ylab("Latitude") +
  scale_color_manual(values = colors2)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2006=ggplot(data_y2006)+
  geom_point(aes(x=data_y2006[,4],y=data_y2006[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2006[,2],y=data_y2006[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2006")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2007
stepsize = (y2007@extent@ymax - y2007@extent@ymin) / y2007@nrows
y_y2007 = seq(y2007@extent@ymax - stepsize / 2, y2007@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2007 = data.frame(y_y2007)
x_y2007 = data.frame(rowMeans(as.matrix(y2007), na.rm = TRUE))
xx_y2007 = data.frame(rowMeans(as.matrix(yy2007), na.rm = TRUE))
# Then you add this to your existing plot:
x_2007_ma=rollmean(x_y2007, k = 200)
xx_2007_ma=rollmean(xx_y2007, k = 200)
data_y2007<- data.frame(x_2007_ma,xx_2007_ma,x_y2007[1:length(x_2007_ma[,1]),1],
                        xx_y2007[1:length(x_2007_ma[,1]),1],y_y2007[1:length(x_2007_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2007=ggplot(data_y2007)+
  geom_point(aes(x=data_y2007[,3],y=data_y2007[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2007[,1],y=data_y2007[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2007")+
  xlab("EVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors3)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2007=ggplot(data_y2007)+
  geom_point(aes(x=data_y2007[,4],y=data_y2007[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2007[,2],y=data_y2007[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2007")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2008
stepsize = (y2008@extent@ymax - y2008@extent@ymin) / y2008@nrows
y_y2008 = seq(y2008@extent@ymax - stepsize / 2, y2008@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2008 = data.frame(y_y2008)
x_y2008 = data.frame(rowMeans(as.matrix(y2008), na.rm = TRUE))
xx_y2008 = data.frame(rowMeans(as.matrix(yy2008), na.rm = TRUE))
# Then you add this to your existing plot:
x_2008_ma=rollmean(x_y2008, k = 200)
xx_2008_ma=rollmean(xx_y2008, k = 200)
data_y2008<- data.frame(x_2008_ma,xx_2008_ma,x_y2008[1:length(x_2008_ma[,1]),1],
                        xx_y2008[1:length(x_2008_ma[,1]),1],y_y2008[1:length(x_2008_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2008=ggplot(data_y2008)+
  geom_point(aes(x=data_y2008[,3],y=data_y2008[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2008[,1],y=data_y2008[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2008")+
  xlab("EVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors3)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2008=ggplot(data_y2008)+
  geom_point(aes(x=data_y2008[,4],y=data_y2008[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2008[,2],y=data_y2008[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2008")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2002
stepsize = (y2009@extent@ymax - y2009@extent@ymin) / y2009@nrows
y_y2009 = seq(y2009@extent@ymax - stepsize / 2, y2009@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2009 = data.frame(y_y2009)
x_y2009 = data.frame(rowMeans(as.matrix(y2009), na.rm = TRUE))
xx_y2009 = data.frame(rowMeans(as.matrix(yy2009), na.rm = TRUE))
# Then you add this to your existing plot:
x_2009_ma=rollmean(x_y2009, k = 200)
xx_2009_ma=rollmean(xx_y2009, k = 200)
data_y2009<- data.frame(x_2009_ma,xx_2009_ma,x_y2009[1:length(x_2009_ma[,1]),1],
                        xx_y2009[1:length(x_2009_ma[,1]),1],y_y2009[1:length(x_2009_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2009=ggplot(data_y2009)+
  geom_point(aes(x=data_y2009[,3],y=data_y2009[,5],color="GPP"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2009[,1],y=data_y2009[,5],color="Mavg_GPP"),size=0.5)+
  ggtitle("2009")+
  xlab("GPP[kgC/m2]") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2009=ggplot(data_y2009)+
  geom_point(aes(x=data_y2009[,4],y=data_y2009[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2009[,2],y=data_y2009[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2009")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2010
stepsize = (y2010@extent@ymax - y2010@extent@ymin) / y2010@nrows
y_y2010 = seq(y2010@extent@ymax - stepsize / 2, y2010@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2010 = data.frame(y_y2010)
x_y2010 = data.frame(rowMeans(as.matrix(y2010), na.rm = TRUE))
xx_y2010 = data.frame(rowMeans(as.matrix(yy2010), na.rm = TRUE))
# Then you add this to your existing plot:
x_2010_ma=rollmean(x_y2010, k = 200)
xx_2010_ma=rollmean(xx_y2010, k = 200)
data_y2010<- data.frame(x_2010_ma,xx_2010_ma,x_y2010[1:length(x_2010_ma[,1]),1],
                        xx_y2010[1:length(x_2010_ma[,1]),1],y_y2010[1:length(x_2010_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2010=ggplot(data_y2010)+
  geom_point(aes(x=data_y2010[,3],y=data_y2010[,5],color="GPP"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2010[,1],y=data_y2010[,5],color="Mavg_GPP"),size=0.5)+
  ggtitle("2010")+
  xlab("GPP[kgC/m2]") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2010=ggplot(data_y2010)+
  geom_point(aes(x=data_y2010[,4],y=data_y2010[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2010[,2],y=data_y2010[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2010")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2011
stepsize = (y2011@extent@ymax - y2011@extent@ymin) / y2011@nrows
y_y2011 = seq(y2011@extent@ymax - stepsize / 2, y2011@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2011 = data.frame(y_y2011)
x_y2011 = data.frame(rowMeans(as.matrix(y2011), na.rm = TRUE))
xx_y2011 = data.frame(rowMeans(as.matrix(yy2011), na.rm = TRUE))
# Then you add this to your existing plot:
x_2011_ma=rollmean(x_y2011, k = 200)
xx_2011_ma=rollmean(xx_y2011, k = 200)
data_y2011<- data.frame(x_2011_ma,xx_2011_ma,x_y2011[1:length(x_2011_ma[,1]),1],
                        xx_y2011[1:length(x_2011_ma[,1]),1],y_y2011[1:length(x_2011_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2011=ggplot(data_y2011)+
  geom_point(aes(x=data_y2011[,3],y=data_y2011[,5],color="NDVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2011[,1],y=data_y2011[,5],color="Mavg_NDVI"),size=0.5)+
  ggtitle("2011")+
  xlab("NDVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors1)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2011=ggplot(data_y2011)+
  geom_point(aes(x=data_y2011[,4],y=data_y2011[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2011[,2],y=data_y2011[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2011")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2012
stepsize = (y2012@extent@ymax - y2012@extent@ymin) / y2012@nrows
y_y2012 = seq(y2012@extent@ymax - stepsize / 2, y2012@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2012 = data.frame(y_y2012)
x_y2012 = data.frame(rowMeans(as.matrix(y2012), na.rm = TRUE))
xx_y2012 = data.frame(rowMeans(as.matrix(yy2012), na.rm = TRUE))
# Then you add this to your existing plot:
x_2012_ma=rollmean(x_y2012, k = 200)
xx_2012_ma=rollmean(xx_y2012, k = 200)
data_y2012<- data.frame(x_2012_ma,xx_2012_ma,x_y2012[1:length(x_2012_ma[,1]),1],
                        xx_y2012[1:length(x_2012_ma[,1]),1],y_y2012[1:length(x_2012_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2012=ggplot(data_y2012)+
  geom_point(aes(x=data_y2012[,3],y=data_y2012[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2012[,1],y=data_y2012[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2012")+
  xlab("EVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors3)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2012=ggplot(data_y2012)+
  geom_point(aes(x=data_y2012[,4],y=data_y2012[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2012[,2],y=data_y2012[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2012")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2013
stepsize = (y2013@extent@ymax - y2013@extent@ymin) / y2013@nrows
y_y2013 = seq(y2013@extent@ymax - stepsize / 2, y2013@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2013 = data.frame(y_y2013)
x_y2013 = data.frame(rowMeans(as.matrix(y2013), na.rm = TRUE))
xx_y2013 = data.frame(rowMeans(as.matrix(yy2013), na.rm = TRUE))
# Then you add this to your existing plot:
x_2013_ma=rollmean(x_y2013, k = 200)
xx_2013_ma=rollmean(xx_y2013, k = 200)
data_y2013<- data.frame(x_2013_ma,xx_2013_ma,x_y2013[1:length(x_2013_ma[,1]),1],
                        xx_y2013[1:length(x_2013_ma[,1]),1],y_y2013[1:length(x_2013_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2013=ggplot(data_y2013)+
  geom_point(aes(x=data_y2013[,3],y=data_y2013[,5],color="NDVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2013[,1],y=data_y2013[,5],color="Mavg_NDVI"),size=0.5)+
  ggtitle("2013")+
  xlab("NDVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors1)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2013=ggplot(data_y2013)+
  geom_point(aes(x=data_y2013[,4],y=data_y2013[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2013[,2],y=data_y2013[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2013")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2000

#----2014
stepsize = (y2014@extent@ymax - y2014@extent@ymin) / y2014@nrows
y_y2014 = seq(y2014@extent@ymax - stepsize / 2, y2014@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2014 = data.frame(y_y2014)
x_y2014 = data.frame(rowMeans(as.matrix(y2014), na.rm = TRUE))
xx_y2014 = data.frame(rowMeans(as.matrix(yy2014), na.rm = TRUE))
# Then you add this to your existing plot:
x_2014_ma=rollmean(x_y2014, k = 200)
xx_2014_ma=rollmean(xx_y2014, k = 200)
data_y2014<- data.frame(x_2014_ma,xx_2014_ma,x_y2014[1:length(x_2014_ma[,1]),1],
                        xx_y2014[1:length(x_2014_ma[,1]),1],y_y2014[1:length(x_2014_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2014=ggplot(data_y2014)+
  geom_point(aes(x=data_y2014[,3],y=data_y2014[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2014[,1],y=data_y2014[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2014")+
  xlab("EVI") +
  ylab("Latitude") +
  scale_color_manual(values = colors3)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
b2014=ggplot(data_y2014)+
  geom_point(aes(x=data_y2014[,4],y=data_y2014[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2014[,2],y=data_y2014[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2014")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2014

#----2014
stepsize = (y2015@extent@ymax - y2015@extent@ymin) / y2015@nrows
y_y2015 = seq(y2015@extent@ymax - stepsize / 2, y2015@extent@ymin, -stepsize)
# The x-values will be the mean of each row in your raster:
y_y2015 = data.frame(y_y2015)
x_y2015 = data.frame(rowMeans(as.matrix(y2015), na.rm = TRUE))
xx_y2015 = data.frame(rowMeans(as.matrix(yy2015), na.rm = TRUE))
# Then you add this to your existing plot:
x_2015_ma=rollmean(x_y2015, k = 200)
xx_2015_ma=rollmean(xx_y2015, k = 200)
data_y2015<- data.frame(x_2015_ma[,1],xx_2015_ma[,1],x_y2015[1:length(x_2015_ma[,1]),1],
                        xx_y2015[1:length(x_2015_ma[,1]),1],y_y2015[1:length(x_2015_ma[,1]),1])

colors1 = c("NDVI"= "black", "Mavg_NDVI" = "Red")
colors2 = c("LAI"= "black", "Mavg_LAI" = "Green")
colors3 = c("EVI"= "black", "Mavg_EVI" = "Brown")
colors4 = c("GPP"= "black", "Mavg_GPP" = "Orange")

colors5 = c("Rice-Yield"= "black", "Mavg_Rice-Yield" = "blue")

a2015=ggplot(data_y2015)+
  geom_point(aes(x=data_y2015[,3],y=data_y2015[,5],color="EVI"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2015[,1],y=data_y2015[,5],color="Mavg_EVI"),size=0.5)+
  ggtitle("2015")+
  xlab("GPP") +
  ylab("Latitude") +
  scale_color_manual(values = colors4)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y =element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_blank(),
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a2015
b2015=ggplot(data_y2015)+
  geom_point(aes(x=data_y2015[,4],y=data_y2015[,5],color="Rice-Yield"),size=0.1)+
  # geom_point(aes(x=data_y2000[,3],y=data_y2000[,5]),color="black")+
  geom_point(aes(x=data_y2015[,2],y=data_y2015[,5],color="Mavg_Rice-Yield"),size=0.5)+
  ggtitle("2015")+
  xlab("Rice Yield[t/ha]") +
  ylab("Latitude") +
  scale_color_manual(values = colors5)+
  theme_bw() +
  # scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
b2015

memory.limit(size=56000)
library(patchwork)
combined2 = a2000 + a2001 + a2002 + a2003 +b2000 +b2001 +b2002+
            b2003 & theme(legend.position = "right")

combined3 = a2004+a2005+a2006 + a2007 + b2004 + b2005 +b2006 +b2007

combined4 = a2008+a2009+a2010+a2011+b2008 + b2009 + b2010 + b2011 

combined5 = a2012 + a2013 + a2014 + b2015 +b2012 +b2013 +b2014+
            b2015


# + f2 + f4 + ap4 + ap5
combined22 = combined2 + plot_layout(ncol = 4, guides = "collect")
combined33 = combined3 + plot_layout(ncol = 4, guides = "collect")
combined44 = combined4 + plot_layout(ncol = 4, guides = "collect")
combined55 = combined5 + plot_layout(ncol = 4, guides = "collect")
combined22
combined33
combined44
combined55

path1 = "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/"

ggsave(filename="spa_param.tiff", plot=a, path=path1, dpi=400)
ggsave(filename="l2.tiff", plot=combined33, path=path1, dpi=400)
ggsave(filename="l3.tiff", plot=combined44, path=path1, dpi=400)
ggsave(filename="l4.tiff", plot=combined55, path=path1, dpi=400)


# geom_line(aes(x=data_y2000[,1],y=data_y2000[,3]), size = 0.1)
  
  
# y2001_m = mask(y2001,sea)
y2002 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2002.tif")
# y2002_m = mask(y2002,sea)
y2003 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2003.tif")
# y2003_m = mask(y2003,sea)
y2004 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2004.tif")
# y2004_m = mask(y2004,sea)
y2005 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2005.tif")
# y2005_m = mask(y2005,sea)
y2006 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2006.tif")
# y2006_m = mask(y2006,sea)
y2007 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2007.tif")
# y2007_m = mask(y2007,sea)
y2008 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2008.tif")
# y2008_m = mask(y2008,sea)
y2009 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2009.tif")
# y2009_m = mask(y2009,sea)
y2010 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2010.tif")
# y2010_m = mask(y2010,sea)
y2011 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2011.tif")
# y2011_m = mask(y2011,sea)
y2012 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2012.tif")
# y2012_m = mask(y2012,sea)
y2013 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2013.tif")
# y2013_m = mask(y2013,sea)
y2014 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2014.tif")
# y2014_m = mask(y2014,sea)
y2015 = raster("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model/rice_2015.tif")
# y2015_m = mask(y2015,sea)

plot(y2000_m)

p1 <- "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/data/gdhy_v1.2_v1.3_20190128/rice_major/New folder/"
R1 <- list.files(p1, pattern = "tif$",full.names = TRUE)

g_yld<- stack(R1)
g_yld1 = crop(g_yld,sea)

p2 = "G:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/data/india_yield/ras/"
R2 <- list.files(p2, pattern = "tif$",full.names = TRUE)
i_yld<- stack(R2)

p3 <- "F:/OneDrive/AIT/papers/yield_estimation_kanlaya/data/model_et/"
R3 <- list.files(p3, pattern = "tif$",full.names = TRUE)
et_s<- stack(R3)

# i_yld1 = crop(i_yld,sea)

plot(i_yld[[2]])
plot(sea, add=T)

plot(y2000_m)
plot(sea, add=T)
# plot(g_yld1[[5]])



# p1 <- "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/data/aphrodite/data/"
# R1 <- list.files(p1, pattern = "nc$")
# 
# ap_rain <- raster::stack(file.path(p1, R1), varname = "precip")
# 

#rmse
# yld_corr1 = data.frame(yld_corr)
yld_cr2 = data.frame(yld_cr1)
yld_cr4 = data.frame(yld_cr3)

rind = rep(1:16,each=4)
cind = seq(1,128, by =2)
rmse = matrix(data= NA, ncol=4, nrow=16)
mad = matrix(data= NA, ncol=4, nrow=16)
cor1 = matrix(data= NA, ncol=4, nrow=16)
mae = matrix(data= NA, ncol=4, nrow=16)

rmse1 = matrix(data= NA, ncol=4, nrow=16)
mad1 = matrix(data= NA, ncol=4, nrow=16)
# cor1 = matrix(data= NA, ncol=4, nrow=16)
mae1 = matrix(data= NA, ncol=4, nrow=16)


for (i in 1:length(rind)){
  
    if (cind[i]%%8 ==1){
      rmse[rind[i],1] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],1] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      mae[rind[i],1] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      # mean(abs((y_actual-y_predict)/y_actual))*100
      rmse1[rind[i],1] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],1] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],1] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
      # cor1[rind[i],1] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
    }
    if (cind[i]%%8 ==3){
      rmse[rind[i],2] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],2] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      cor1[rind[i],2] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
      mae[rind[i],2] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      
      rmse1[rind[i],2] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],2] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],2] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
    }
    if (cind[i]%%8 ==5){
      rmse[rind[i],3] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],3] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      cor1[rind[i],3] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
      mae[rind[i],3] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      
      rmse1[rind[i],3] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],3] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],3] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
    }
    if (cind[i]%%8 ==7){
      rmse[rind[i],4] = sqrt(mean((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1])^2, na.rm = T))
      mad[rind[i],4] = mad((yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      cor1[rind[i],4] = cor(yld_cr2[,cind[i]],yld_cr2[,cind[i]+1], method = c("pearson"), use = "na.or.complete")
      mae[rind[i],4] = mean(abs(yld_cr2[,cind[i]] - yld_cr2[,cind[i]+1]), na.rm = T)
      
      rmse1[rind[i],4] = sqrt(mean((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1])^2, na.rm = T))
      mad1[rind[i],4] = mad((yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      mae1[rind[i],4] = mean(abs(yld_cr4[,cind[i]] - yld_cr4[,cind[i]+1]), na.rm = T)
      
    }

  
}

mad
mad1
rmse
rmse1
mae

# 
# library(Hmisc)
# res_2000<-rcorr(as.matrix(y_2000))
# res_2001<-rcorr(as.matrix(y_2001))
# res_2002<-rcorr(as.matrix(y_2002))
# res_2003<-rcorr(as.matrix(y_2003))
# res_2004<-rcorr(as.matrix(y_2004))
# res_2005<-rcorr(as.matrix(y_2005))
# res_2006<-rcorr(as.matrix(y_2006))
# res_2007<-rcorr(as.matrix(y_2007))
# res_2008<-rcorr(as.matrix(y_2008))
# res_2009<-rcorr(as.matrix(y_2009))
# res_2010<-rcorr(as.matrix(y_2010))
# res_2011<-rcorr(as.matrix(y_2011))
# res_2012<-rcorr(as.matrix(y_2012))
# res_2013<-rcorr(as.matrix(y_2013))
# res_2014<-rcorr(as.matrix(y_2014))
# res_2015<-rcorr(as.matrix(y_2015))
# # res2[[3]][1,]
# 
# res_2000_1= res_2000[[3]][1,2:5]
# res_2001_1= res_2001[[3]][1,2:5]
# res_2002_1= res_2002[[3]][1,2:5]
# res_2003_1= res_2003[[3]][1,2:5]
# res_2004_1= res_2004[[3]][1,2:5]
# res_2005_1= res_2005[[3]][1,2:5]
# res_2006_1= res_2006[[3]][1,2:5]
# res_2007_1= res_2007[[3]][1,2:5]
# res_2008_1= res_2008[[3]][1,2:5]
# res_2009_1= res_2009[[3]][1,2:5]
# res_2010_1= res_2010[[3]][1,2:5]
# res_2011_1= res_2011[[3]][1,2:5]
# res_2012_1= res_2012[[3]][1,2:5]
# res_2013_1= res_2013[[3]][1,2:5]
# res_2014_1= res_2014[[3]][1,2:5]
# res_2015_1= res_2015[[3]][1,2:5]
# 
# 
# chart.Correlation(res_2000_1, histogram=TRUE, pch=19,
#                   method = c("pearson"))
# 
# plot(res_2000_1)
# 
# 
# res3 = data.frame(res_2000_1,res_2001_1,res_2002_1,res_2003_1,res_2004_1,
#                   res_2005_1,res_2006_1,res_2007_1,res_2008_1,res_2009_1,
#                   res_2010_1,res_2011_1,res_2012_1,res_2013_1,res_2014_1, res_2015_1)
# res4 = t(res3)
# colnames(res4)=c("NDVI","EVI","LAI","GPP")
# rownames(res4)=c("2000","2001","2002","2003",
#                  "2004","2005","2006","2007",
#                  "2008","2009","2010","2011",
#                  "2012","2013","2014","2015")
# 
# library(plotrix)
# mad_mean = data.frame(mad)
# colnames(mad_mean) <- c("NDVI", "EVI", "LAI","GPP")

# library(reshape2)
# library(ggplot2)
# year = seq(2015,2000,-1)
# var = c("NDVI","EVI","LAI","GPP")
# mad.df <- reshape2::melt(mad, c("y", "x"), value.name = "z")
# mad1.df <- reshape2::melt(mad1, c("y", "x"), value.name = "z")
# rmse.df <- reshape2::melt(rmse, c("y", "x"), value.name = "z")
# rmse1.df <- reshape2::melt(rmse1, c("y", "x"), value.name = "z")
# 
# mad_mean = ggplot(data=mad.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'MAD (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# 
# mad_max = ggplot(data=mad1.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'MAD (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# 
# rmse_mean = ggplot(data=rmse.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'RMSE (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# 
# rmse_max = ggplot(data=rmse1.df,aes(x=x,y=y))+
#   geom_raster(aes(fill=z))+
#   scale_fill_gradient(low="grey90", high="red")+
#   labs(fill= 'RMSE (t/ha)')+
#   # labs(x="letters", y="LETTERS", title="Matrix")+
#   scale_x_continuous(expand = c(0,0),breaks = 1:4, labels=var)+
#   scale_y_continuous(expand = c(0,0),breaks = 1:16, labels=year)+
#   # geom_tile()+
#   theme_bw()+
#   theme(axis.title.x = element_blank(),
#         axis.title.y = element_blank(),
#         axis.text.x = element_text(size=10),
#         axis.text.y = element_text(size=10),
#         # panel.grid.major = element_text(size=10),
#         # panel.grid.minor =  element_text(size=10),
#         legend.title=element_text(size=10), 
#         legend.text=element_text(size=10),
#         legend.position = "right",
#         legend.key = element_blank(),
#         plot.title = element_text(size=8)
#   )
# 
# mad_mean
# mad_max
# rmse_mean
# rmse_max
# 
# path1 = "C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/"
# ggsave(filename="mad_mean.tiff", plot=mad_mean, path=path1, dpi=300)
# ggsave(filename="mad_max.tiff", plot=mad_max, path=path1, dpi=300)
# ggsave(filename="rmse_mean.tiff", plot=rmse_mean, path=path1, dpi=300)
# ggsave(filename="rmse_max.tiff", plot=rmse_max, path=path1, dpi=300)
# 
# library(ggplot2)
# ggplot(data = mad_mean, aes(x=)) + 
#   geom_tile()
# 
# 
# extent(g_yld1[[1]])= extent(y2000_m);
# 
# plot(y2000_m)
# plot(g_yld1[[1]])




plot(y2001,legend=FALSE)
plot(sea, add=T)
plot(y2002,legend=FALSE)
plot(sea, add=T)
plot(y2003,legend=FALSE)
plot(sea, add=T)
plot(y2004,legend=FALSE)
plot(sea, add=T)
plot(y2005,legend=FALSE)
plot(sea, add=T)


image(y2000)

plot(y2001,
     # maxpixels=ncell(zreate),
     # col=qcol,
     # colNA=mapbg,
     # xaxt='n',
     # yaxt='n',
     # ext=map_extent,
     # breaks=tq,
     # bty='n',
     legend=FALSE)
plot(sea, add=T)
image(y2000)
image(y2000)
image(y2000)
image(y2000)


par(mfrow=c(1,1), cex=3, mar=c(3,3,3,7), bg=bgcol, col=txtcol)

# first plot


#third plot and par() call
par(mfrow=c(1,1), cex=3, mar=c(3,3,3,7), bg=bgcol, col=txtcol, new=TRUE)
plot(r0,
     maxpixels=ncell(r0),
     col="#9e9ac8",
     xaxt='n',
     yaxt='n',
     ext=map_extent, #PRENAFILTERING fix
     bty='n',
     legend=FALSE)

y2000_m1 <- rasterToPoints(y2000)
#Make the points a dataframe for ggplot
df <- data.frame(y2000_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2000_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2000") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2000_m1

y2001_m1 <- rasterToPoints(y2001)
#Make the points a dataframe for ggplot
df <- data.frame(y2001_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2001_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2001") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2002_m1 <- rasterToPoints(y2002)
#Make the points a dataframe for ggplot
df <- data.frame(y2002_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2002_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2003_m1 <- rasterToPoints(y2003)
#Make the points a dataframe for ggplot
df <- data.frame(y2003_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2003_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


y2004_m1 <- rasterToPoints(y2004)
#Make the points a dataframe for ggplot
df <- data.frame(y2004_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2004_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2005_m1 <- rasterToPoints(y2005)
#Make the points a dataframe for ggplot
df <- data.frame(y2005_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2005_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2006_m1 <- rasterToPoints(y2006)
#Make the points a dataframe for ggplot
df <- data.frame(y2006_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2006_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2007_m1 <- rasterToPoints(y2007)
#Make the points a dataframe for ggplot
df <- data.frame(y2007_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2007_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2008_m1 <- rasterToPoints(y2008)
#Make the points a dataframe for ggplot
df <- data.frame(y2008_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2008_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2009_m1 <- rasterToPoints(y2009)
#Make the points a dataframe for ggplot
df <- data.frame(y2009_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2009_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2010_m1 <- rasterToPoints(y2010)
#Make the points a dataframe for ggplot
df <- data.frame(y2010_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2010_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2011_m1 <- rasterToPoints(y2011)
#Make the points a dataframe for ggplot
df <- data.frame(y2011_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2011_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2012_m1 <- rasterToPoints(y2012)
#Make the points a dataframe for ggplot
df <- data.frame(y2012_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2012_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
y2013_m1 <- rasterToPoints(y2013)
#Make the points a dataframe for ggplot
df <- data.frame(y2013_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2013_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2014_m1 <- rasterToPoints(y2014)
#Make the points a dataframe for ggplot
df <- data.frame(y2014_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2014_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2015_m1 <- rasterToPoints(y2015)
#Make the points a dataframe for ggplot
df <- data.frame(y2015_m1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
y2015_m1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )



#--------------------------------------------------------------------

g_yld1_2000 <- rasterToPoints(g_yld1[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2000)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2000=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2000") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

# y2000_m1

g_yld1_2001 <- rasterToPoints(g_yld1[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2001)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2001=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2001") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2002 <- rasterToPoints(g_yld1[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2002)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2002=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2003 <- rasterToPoints(g_yld1[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2003)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2003=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


g_yld1_2004 <- rasterToPoints(g_yld1[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2004)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2004=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2005 <- rasterToPoints(g_yld1[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2005)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2005=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2006 <- rasterToPoints(g_yld1[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2006)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2006=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2007 <- rasterToPoints(g_yld1[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2007)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2007=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2008 <- rasterToPoints(g_yld1[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2008)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2008=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2009 <- rasterToPoints(g_yld1[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2009)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2009=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2010 <- rasterToPoints(g_yld1[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2010)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2010=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2011 <- rasterToPoints(g_yld1[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2011)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2011=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2012 <- rasterToPoints(g_yld1[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2012)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2012=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
g_yld1_2013 <- rasterToPoints(g_yld1[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2013)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2013=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2014 <- rasterToPoints(g_yld1[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2014)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2014=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

g_yld1_2015 <- rasterToPoints(g_yld1[[16]])
#Make the points a dataframe for ggplot
df <- data.frame(g_yld1_2015)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
g_yld1_2015=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

#----------------------------------------------------------------------
i_yld1_2000 <- rasterToPoints(i_yld1[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2000)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2000=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2000") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

y2000_m1

i_yld1_2001 <- rasterToPoints(i_yld1[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2001)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2001=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2001") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2002 <- rasterToPoints(i_yld1[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2002)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2002=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2003 <- rasterToPoints(i_yld1[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2003)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2003=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


i_yld1_2004 <- rasterToPoints(i_yld1[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2004)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2004=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2005 <- rasterToPoints(i_yld1[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2005)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2005=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2006 <- rasterToPoints(i_yld1[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2006)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2006=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2007 <- rasterToPoints(i_yld1[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2007)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2007=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2008 <- rasterToPoints(i_yld1[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2008)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2008=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2009 <- rasterToPoints(i_yld1[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2009)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2009=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2010 <- rasterToPoints(i_yld1[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2010)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2010=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2011 <- rasterToPoints(i_yld1[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2011)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2011=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2012 <- rasterToPoints(i_yld1[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2012)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2012=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
i_yld1_2013 <- rasterToPoints(i_yld1[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2013)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2013=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2014 <- rasterToPoints(i_yld1[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2014)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2014=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

i_yld1_2015 <- rasterToPoints(i_yld1[[16]])
#Make the points a dataframe for ggplot
df <- data.frame(i_yld1_2015)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
i_yld1_2015=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=sea, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'Rice Yield\n (t/ha)')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(0,10))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )


#--------------------------------------------------------------------
plot()
memory.limit(size=56000)
library(patchwork)
combined2 = y2000_m1+g_yld1_2000+i_yld1_2000+
            y2001_m1+g_yld1_2001+i_yld1_2001+
            y2002_m1+g_yld1_2002+i_yld1_2002+
            y2003_m1+g_yld1_2003+i_yld1_2003
combined3 = combined2 + plot_layout(ncol = 3, guides = "collect")
combined3

path1 = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/maps/New folder/new_maps/save/"

ggsave(filename="method.tiff", plot=combined3, path=path1, dpi=300)
ggsave(filename="lapse_rate2_temp.tiff", plot=combined3, path=path1, dpi=300)


#--------------------------
yld_cr2 = data.frame(yld_cr1)
yld_cr4 = data.frame(yld_cr3)



mae_2000 = ggplot(yld_cr2, aes(x = yld_cr2[,7], y = yld_cr2[,8])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2000_1 = mae_2000+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[1,4], digits = 2),"t/ha"), size=3)
mae_2000_1

mae_2001 = ggplot(yld_cr2, aes(x = yld_cr2[,11], y = yld_cr2[,12])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2001_1 = mae_2001+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[2,2], digits = 2),"t/ha"), size=3)
mae_2001_1

mae_2002 = ggplot(yld_cr2, aes(x = yld_cr2[,23], y = yld_cr2[,24])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2002_1 = mae_2001+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[3,4], digits = 2),"t/ha"), size=3)
mae_2002_1

mae_2003 = ggplot(yld_cr2, aes(x = yld_cr2[,27], y = yld_cr2[,28])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2003_1 = mae_2003+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[4,2], digits = 2),"t/ha"), size=3)
mae_2003_1

mae_2004 = ggplot(yld_cr2, aes(x = yld_cr2[,39], y = yld_cr2[,40])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2004_1 = mae_2004+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[5,4], digits = 2),"t/ha"), size=3)
mae_2004_1


mae_2005 = ggplot(yld_cr2, aes(x = yld_cr2[,47], y = yld_cr2[,48])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2005_1 = mae_2005+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[6,4], digits = 2),"t/ha"), size=3)
mae_2005_1

mae_2006 = ggplot(yld_cr2, aes(x = yld_cr2[,53], y = yld_cr2[,54])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2006_1 = mae_2006+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[7,3], digits = 2),"t/ha"), size=3)
mae_2006_1

mae_2007 = ggplot(yld_cr2, aes(x = yld_cr2[,59], y = yld_cr2[,60])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2007_1 = mae_2006+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[8,2], digits = 2),"t/ha"), size=3)
mae_2007_1

mae_2008 = ggplot(yld_cr2, aes(x = yld_cr2[,67], y = yld_cr2[,68])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2008_1 = mae_2008+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[9,2], digits = 2),"t/ha"), size=3)
mae_2008_1

mae_2009 = ggplot(yld_cr2, aes(x = yld_cr2[,79], y = yld_cr2[,80])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2009_1 = mae_2009+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[10,4], digits = 2),"t/ha"), size=3)
mae_2009_1

mae_2010 = ggplot(yld_cr2, aes(x = yld_cr2[,87], y = yld_cr2[,88])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2010_1 = mae_2010+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[11,4], digits = 2),"t/ha"), size=3)
mae_2010_1


mae_2011 = ggplot(yld_cr2, aes(x = yld_cr2[,89], y = yld_cr2[,90])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2011_1 = mae_2011+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[12,1], digits = 2),"t/ha"), size=3)
mae_2011_1


mae_2012 = ggplot(yld_cr2, aes(x = yld_cr2[,99], y = yld_cr2[,100])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2012_1 = mae_2012+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[13,2], digits = 2),"t/ha"), size=3)
mae_2012_1


mae_2013 = ggplot(yld_cr2, aes(x = yld_cr2[,105], y = yld_cr2[,106])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2013_1 = mae_2013+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[14,1], digits = 2),"t/ha"), size=3)
mae_2013_1


mae_2014 = ggplot(yld_cr2, aes(x = yld_cr2[,115], y = yld_cr2[,116])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2014_1 = mae_2014+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[15,2], digits = 2),"t/ha"), size=3)
mae_2014_1


mae_2015 = ggplot(yld_cr2, aes(x = yld_cr2[,127], y = yld_cr2[,128])) +
  geom_point(size=3)+
  # stat_smooth(method = "lm",
  #             col = "#C42126",
  #             se = FALSE,
  #             size = 1) +
  labs(
    x = "ICRISAT yield (t/ha)",
    y = "Downscaled yield (t/ha)",
    # color = "Gear",
    title = ""
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  xlim(0,6)+
  ylim(0,6)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)

mae_2015_1 = mae_2015+annotate(geom="text", x=1, y=6, label = paste("MAE = ", round(mae[16,4], digits = 2),"t/ha"), size=3)
mae_2015_1


a=plot(x = yld_cr2[,127], y = yld_cr2[,128], main="Scatterplot Example",
     xlab="Car Weight ", ylab="Miles Per Gallon ", pch=19)

# m <- rbind(c(1,2,3,4), c(5,6,7,8), c(9,10,11,12),c(13,14,15,16))
# layout(m)


tiff("F:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/et1.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(y2002, xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,15))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2000", line=2, cex = 0.5)
#  mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2000, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[1]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,7], y = yld_cr2[,8], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[1,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[2]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2001", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2001, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[2]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,11], y = yld_cr2[,12], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[2,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[3]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2002", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2002, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[3]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,23], y = yld_cr2[,24], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[3,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[4]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2003", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2003, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[4]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,27], y = yld_cr2[,28], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[4,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#------------------------
tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/r2.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[5]], xaxt='n',ylab="2004",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2004", line=2, cex = 0.5)
mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2004, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[5]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,39], y = yld_cr2[,40], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[5,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[6]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2005", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2005, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[6]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,47], y = yld_cr2[,48], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[6,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[7]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2006", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2006, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[7]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,53], y = yld_cr2[,54], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[7,3], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[8]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2007", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2007, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[8]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,59], y = yld_cr2[,60], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[8,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#-------------------------------------------------------

tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/r3.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[9]], xaxt='n',ylab="2004",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2008", line=2, cex = 0.5)
mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2008, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[9]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,67], y = yld_cr2[,68], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[9,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[10]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2009", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2009, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[10]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,79], y = yld_cr2[,80], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[10,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[11]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2010", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2010, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[11]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,87], y = yld_cr2[,88], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[11,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[12]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2011", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2011, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[12]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,89], y = yld_cr2[,90], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[12,1], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#-------------------------------------------------------


tiff("G:/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/r4.tiff", units="in", width=6, height=5, res=400)

# n <- 6
# par(oma = c(1,1,1,1), mfrow = c(4, 4), mar = c(4, 4, 1, 1))
# 
# par(mfrow = c(4,4),tcl=0.5, family="serif", omi=c(0.0,0.0,0,0))
colors = topo.colors(20)
par(mfrow=c(4,4), tcl=-0.5, family="serif",oma = c(4,2,2,2))

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[13]], xaxt='n',ylab="2004",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2012", line=2, cex = 0.5)
mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2012, col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[13]], col=colors,zlim=c(0,6),xaxt='n',yaxt='n',legend=FALSE)
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,99], y = yld_cr2[,100], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[13,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)

# mtext(side=1, text="Icrisat Yield (t/ha)", line=1.5)
# mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5)


par(mai=c(0.4,0.2,0,0))
image(g_yld1[[14]], xaxt='n',ylab="2001",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2013", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2013, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[14]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,105], y = yld_cr2[,106], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[14,1], digits = 2),"t/ha"), line=0.0, cex = 0.5)


# plot(sea, add=T)
# grid.arrange(image(g_yld1[[1]]), image(g_yld1[[1]]), plot(mae_2000_1), ncol=3)

par(mai=c(0.4,0.2,0,0))
image(g_yld1[[15]], xaxt='n',ylab="2002",cex.main=1, cex.lab=0.5, cex.axis=0.5,
      legend=FALSE,col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2014", line=2, cex = 0.5)
# mtext(side=3, text="GYGA Yield(50 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2014, xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="Downscaled (0.5 km)", line=0.5,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[15]], xaxt='n',yaxt='n',legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,115], y = yld_cr2[,116], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[15,2], digits = 2),"t/ha"), line=0.0, cex = 0.5)



par(mai=c(0.4,0.2,0,0))

#       legend.args=list(text='Elevation (m)', side=3, font=1, line=0.5, cex=0.8))
plot(g_yld1[[16]],xaxt='n',ylab="2003",cex.main=1, cex.lab=0.5, cex.axis=0.5,
     col=colors,zlim=c(0,6),
     horiz = TRUE,
     legend.width=1,legend.shrink=0.75,
     legend.args=list(text='Rice Yield [t/ha]', side=1, font=1, line=2.0, cex=0.8))

plot(sea, border="grey", lwd=0.01, add=T)
# text((max.width-min.width)/2 + min.width, max.length+0.15, expression(italic("Iris virginica")))
mtext(side=2, text="2015", line=2, cex = 0.5)
# mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(y2015, yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.2,0,0))
image(i_yld[[16]], yaxt='n',cex.main=1, cex.lab=0.5, cex.axis=0.5,legend=FALSE,
      col=colors,zlim=c(0,6))
plot(sea, border="grey", lwd=0.01, add=T)
# mtext(side=3, text="ICRISAT Yield (District level)", line=0.5, cex = 0.5)
mtext(side=1, text="Longitude", line=2.0,cex = 0.5)

par(mai=c(0.4,0.4,0,0))
plot(x = yld_cr2[,127], y = yld_cr2[,128], main="",
     cex.main=1, cex.lab=0.5, cex.axis=0.5,
     xlim=c(0,6),ylim=c(0,6),xlab="ICRISAT yield (t/ha)", ylab="Downscaled yield (t/ha)", pch=19)
lines(x = c(0,6), y = c(0,6))
mtext(side=3, text=paste("MAE = ", round(mae[16,4], digits = 2),"t/ha"), line=0.0, cex = 0.5)
mtext(side=1, text="ICRISAT Yield (t/ha)", line=2.0,cex = 0.5)
mtext(side=2, text="Downscaled Yield (t/ha)", line=1.5,cex = 0.5)



dev.off()
#-------------------------------------------------------




# param3p_p10=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
#                  par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])
# 
# save(param3p_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/param_3p_p10.RData")
# save(lr_y_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_y_p10.RData")
# save(lr_x_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_x_p10.RData")
# save(lr_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_p10.RData")



