library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)
library(ncdf4)

library(raster)
library(gstat)
library(sp)


# setwd('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5_p1_n1.RData')
# load('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_2.RData')
# basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3.shp")
# # basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s1_n4.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")


basin <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia5.shp")
basin1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/mon_asia4.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s2.shp")
# basin4 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s4.shp")
# basin10 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s10.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_seg_sw.shp")
# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s2_n4.shp")
# basin3 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s3_n4.shp")
# basin4 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_s4_n4.shp")
zones = readOGR("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/gis/zone4.shp")
# fishnet1 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/fishnet_5_5_n3.shp")
# fishnet2_df <- fortify(fishnet2)

sam <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")

basin_p=basin
basin_p1=basin1
basin_p2=basin2
basin_p3=basin3
basin_p4=basin4
basin_p10=basin10
plot(basin_p2)

yld_corr = read_excel("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/analysis/yield_dis1.xlsx")

p1 <- "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/Presentation DATA/GRACE DATA/CSR_GRACE/"
R1 <- list.files(p1, pattern = "nc$")

tws_csr <- raster::stack(file.path(p1, R1), varname = "lwe_thickness")

p2 <- "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/Presentation DATA/GRACE DATA/GFZ_GRACE/"
R2 <- list.files(p2, pattern = "nc$")

tws_gfz <- raster::stack(file.path(p2, R2), varname = "lwe_thickness")

p3 <- "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/Presentation DATA/GRACE DATA/JPL_GRACE/"
R3 <- list.files(p3, pattern = "nc$")

tws_jpl <- raster::stack(file.path(p3, R3), varname = "lwe_thickness")

n1 = names(tws_csr)
n2 = names(tws_gfz)

n1_1 = colsplit(n1, "(?<=\\p{L})(?=[\\d+$])", c("char", "digit"))
n2_1 = colsplit(R2, "(?<=\\p{L})(?=[\\d+$])", c("char", "digit"))

m=c()
y=c()
m1 = c()
start = 2002

for (i in 1:length(n1_1[,2])){
  if(ceiling(n1_1[i,2]/31)%%12==0){
  m[i] = 12
  
  }
  else{
    m[i] = ceiling(n1_1[i,2]/31)%%12
  }
  y[i] = floor(n1_1[i,2]/365)+2002
  m1[i] = ceiling(n1_1[i,2]/30)
}

miss_m1 = c(1,2,3,6,7,18,36,107,111,116,127,132,137,142,143,148,153,158,164,168,
            169,174,178,180,181,185,190,191,192,193,194,195,196,197,198,199,
            200,203,204)
m2 = c(4,	5,	8,	9,	10,	11,	12,	13,	14,	15,	16,	17,	19,	20,	21,
       22,	23,	24,	25,	26,	27,	28,	29,	30,	31,	32,	33,	34,	35,	36,
       37,	38,	39,	40,	41,	42,	43,	44,	45,	46,	47,	48,	49,	50,	51,
       52,	53,	54,	55,	56,	57,	58,	59,	60,	61,	62,	63,	64,	65,	66,
       67,	68,	69,	70,	71,	72,	73,	74,	75,	76,	77,	78,	79,	80,	81,
       82,	83,	84,	85,	86,	87,	88,	89,	90,	91,	92,	93,	94,	95,	96,	97,
       98,	99,	100,	101,	102,	103,	104,	105,	106,	107,	108,
       110,	111,	112,	113,	115,	116,	117,	118,	119,	120,	121,
       122,	123,	124,	126,	127,	128,	129,	131,	132,	133,	134,
       136,	137,	138,	139,	142,	143,	144,	145,	146,	148,	149,
       150,	152,	153,	154,	155,	157,	158,	159,	160,	161,	162,
       164,	165,	168,	169,	170,	171,	173,	174,	175,	176,	179,
       180,	181,	183,	184,	185,	186)
            
  m3 = c(4,	5,	8,	9,10,	11,	12,	13,	14,	15,	16,	17,	19,	20,	21,	22,	23,
         24,	25,	26,	27,	28,	29,	30,	31,	32,33,	34,	35,	36,	37,	38,	39,
         40,	41,	42,	43,	44,	45,	46,	47,	48,	49,	50,	51,	52,	53,	54,	55,
         56,	57,	58,	59,	60,	61,	62,	63,	64,	65,	66,	67,	68,	69,	70,	71,
         72,	73,	74,	75,	76,	77,	78,	79,	80,	81,	82,	83,	84,	85,	86,	87,
         88,	89,	90,	91,	92,	93,	94,	95,	96,	97,	98,	99,	100,	101,	102,
         103,	104,	105,	106,	107,	108,	110,	111,	112,	113,
         115,	116,	117,	118,	119,	120,	121,	122,	123,	124,	126,
         127,	128,	129,	131,	132,	133,	134,	136,	137,	138,	139,
         142,	143,	144,	145,	146,	148,	149,	150,	152,	153,	154,
         155,	157,	158,	159,	160,	161,	162,	164,	165,	168,	169,
         170,	171,	173,	174,	175,	176,	179,	180,	181,	183,	184,
         185,	186)
        
# library(adamlilith)
# date.n1 = data.frame(y,m)
# date.n1_1 <- paste0(y,sprintf("%02d",date.n1$m))
# n1_from = as.numeric(date.n1_1)
# n1_to =c(200207)

tws_csr1= crop(tws_csr, basin)
tws_csr2 = mask(tws_csr1, basin)

tws_gfz1= crop(tws_gfz, basin)
tws_gfz2 = mask(tws_gfz1, basin)

tws_jpl1= crop(tws_jpl, basin)
tws_jpl2 = mask(tws_jpl1, basin)

tws_csr2_new1 = raster(tws_csr2[[1]])
tws_csr2_new1[] = NA
tws_csr2_new2 = stack(replicate(240,tws_csr2_new1))
tws_csr2_new3 = tws_csr2_new2
for(i in 1:200){
  j= m1[i]
  tws_csr2_new3[[c(j)]] <- tws_csr2[[i]]
}

tws_gfz2_new1 = raster(tws_gfz2[[1]])
tws_gfz2_new1[] = NA
tws_gfz2_new2 = stack(replicate(240,tws_gfz2_new1))
tws_gfz2_new3 = tws_gfz2_new2
for(i in 1:163){
  j= m2[i]
  tws_gfz2_new3[[c(j)]] <- tws_gfz2[[i]]
}


tws_jpl2_new1 = raster(tws_jpl2[[1]])
tws_jpl2_new1[] = NA
tws_jpl2_new2 = stack(replicate(240,tws_jpl2_new1))
tws_jpl2_new3 = tws_jpl2_new2
for(i in 1:163){
  j= m3[i]
  tws_jpl2_new3[[c(j)]] <- tws_jpl2[[i]]
}



f <- function(x) {  
  z <- which(is.na(x))
  nz <- length(z)
  nx <- length(x)
  if (nz > 0 & nz < nx) { 
    x[z] <- spline(x=1:nx, y=x, xout=z, method="natural")$y
  }
  x
}

tws_csr_int <- calc(tws_csr2_new3, f)
tws_gfz_int <- calc(tws_gfz2_new3, f)
tws_jpl_int <- calc(tws_jpl2_new3, f)
#2002-2017 april
tws_csr_int1 = tws_csr_int[[4:183]]
tws_gfz_int1 = stack(resample(tws_gfz_int[[4:183]],tws_csr_int1[[1]],'bilinear'))
tws_jpl_int1 = stack(resample(tws_jpl_int[[4:183]],tws_csr_int1[[1]],'bilinear'))



tws_ensemble = stack(tws_csr_int1,tws_gfz_int1,tws_jpl_int1)

fun_mean <- function(x) {(x[1:180]+x[181:360]+x[361:540])/3}
tws_ensemble_mean <- calc(tws_ensemble, fun=fun_mean)
# rs4 <- calc(s, fun=mean)
#------------------------------------------------------------
p4 <- "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/Presentation DATA/FAO/ASI/"
# R4 <- list.files(p4, pattern = "*.tif$")
grids <- list.files(p4, pattern = "*.tif$")
#create a raster stack from the input raster files 
asi_fao <- raster::stack(paste0(p4, grids))

fao_ind = seq(1,144,8)

asi_fao_s1 = asi_fao[[fao_ind]]
asi_fao_s2 = asi_fao_s1[[1:16]]
plot(asi_fao_s2[[1]])
asi_fao_r = stack(resample(asi_fao_s2,tws_csr_int1[[1]],'bilinear'))
plot(asi_fao_r[[1]])
# asi_fao_s2[asi_fao_s2>100]=NA
# 

plot(asi_fao_s2[[2]])


p5 <- "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/Presentation DATA/SoilMoisture_SPEI/SPEI/"
R5 <- list.files(p5, pattern = "01.nc")
R6 <- list.files(p5, pattern = "03.nc")
R7 <- list.files(p5, pattern = "06.nc")
R8 <- list.files(p5, pattern = "12.nc")
R9 <- list.files(p5, pattern = "24.nc")
R10 <- list.files(p5, pattern = "48.nc")

spei_01 <- raster::stack(file.path(p5, R5), varname = "spei")
spei_03 <- raster::stack(file.path(p5, R6), varname = "spei")
spei_06 <- raster::stack(file.path(p5, R7), varname = "spei")
spei_12 <- raster::stack(file.path(p5, R8), varname = "spei")
spei_24 <- raster::stack(file.path(p5, R9), varname = "spei")
spei_48 <- raster::stack(file.path(p5, R10), varname = "spei")

spei_01 = spei_01[[1216:1395]]
spei_03 = spei_03[[1216:1395]]
spei_06 = spei_06[[1216:1395]]
spei_12 = spei_12[[1216:1395]]
spei_24 = spei_24[[1216:1395]]
spei_48 = spei_48[[1216:1395]]

spei_01= crop(spei_01, basin)
spei_01 = mask(spei_01, basin)

spei_03= crop(spei_03, basin)
spei_03 = mask(spei_03, basin)

spei_06= crop(spei_06, basin)
spei_06 = mask(spei_06, basin)

spei_12= crop(spei_12, basin)
spei_12 = mask(spei_12, basin)

spei_24= crop(spei_24, basin)
spei_24 = mask(spei_24, basin)

spei_48= crop(spei_48, basin)
spei_48 = mask(spei_48, basin)


spei_01_r = stack(resample(spei_01,tws_csr_int1[[1]],'bilinear'))
spei_03_r = stack(resample(spei_03,tws_csr_int1[[1]],'bilinear'))
spei_06_r = stack(resample(spei_06,tws_csr_int1[[1]],'bilinear'))
spei_12_r = stack(resample(spei_12,tws_csr_int1[[1]],'bilinear'))
spei_24_r = stack(resample(spei_24,tws_csr_int1[[1]],'bilinear'))
spei_48_r = stack(resample(spei_48,tws_csr_int1[[1]],'bilinear'))


p11 <- "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/Presentation DATA/scPDSI/"
R11 <- list.files(p11, pattern = "nc")

pdsi <- raster::stack(file.path(p11, R11), varname = "scpdsi")
pdsi1 = pdsi[[1216:1395]]

pdsi1= crop(pdsi1, basin)
pdsi1 = mask(pdsi1, basin)
pdsi1_r = stack(resample(pdsi1,tws_csr_int1[[1]],'bilinear'))
#-------------------------------------------------------
#calculate cc index

jun = seq(6, 180, 12)
jul = seq(7, 180, 12)
aug = seq(8, 180, 12)
sep = seq(9, 180, 12)
jan = seq(1, 180, 12)
oct = seq(10, 180, 12)
nov = seq(11, 180, 12)
dec = seq(12, 180, 12)
feb = seq(2, 180, 12)
mar = seq(3, 180, 12)
apl = seq(4, 180, 12)
may = seq(5, 180, 12)

tws_jan1 <- calc(tws_ensemble_mean[[jan]], fun = mean)
tws_feb1 <- calc(tws_ensemble_mean[[feb]], fun = mean)
tws_mar1 <- calc(tws_ensemble_mean[[mar]], fun = mean)
tws_apl1 <- calc(tws_ensemble_mean[[apl]], fun = mean)
tws_may1 <- calc(tws_ensemble_mean[[may]], fun = mean)
tws_jun1 <- calc(tws_ensemble_mean[[jun]], fun = mean)
tws_jul1 <- calc(tws_ensemble_mean[[jul]], fun = mean)
tws_aug1 <- calc(tws_ensemble_mean[[aug]], fun = mean)
tws_sep1 <- calc(tws_ensemble_mean[[sep]], fun = mean)
tws_oct1 <- calc(tws_ensemble_mean[[oct]], fun = mean)
tws_nov1 <- calc(tws_ensemble_mean[[nov]], fun = mean)
tws_dec1 <- calc(tws_ensemble_mean[[dec]], fun = mean)

tws_jan2 = cellStats(tws_jan1, stat='mean')
tws_feb2 = cellStats(tws_feb1, stat='mean')
tws_mar2 = cellStats(tws_mar1, stat='mean')
tws_apl2 = cellStats(tws_apl1, stat='mean')
tws_may2 = cellStats(tws_may1, stat='mean')
tws_jun2 = cellStats(tws_jun1, stat='mean')
tws_jul2 = cellStats(tws_jul1, stat='mean')
tws_aug2 = cellStats(tws_aug1, stat='mean')
tws_sep2 = cellStats(tws_sep1, stat='mean')
tws_oct2 = cellStats(tws_oct1, stat='mean')
tws_nov2 = cellStats(tws_nov1, stat='mean')
tws_dec2 = cellStats(tws_dec1, stat='mean')



tws_jan2_sd = cellStats(tws_jan1, stat='sd')
tws_feb2_sd = cellStats(tws_feb1, stat='sd')
tws_mar2_sd = cellStats(tws_mar1, stat='sd')
tws_apl2_sd = cellStats(tws_apl1, stat='sd')
tws_may2_sd = cellStats(tws_may1, stat='sd')
tws_jun2_sd = cellStats(tws_jun1, stat='sd')
tws_jul2_sd = cellStats(tws_jul1, stat='sd')
tws_aug2_sd = cellStats(tws_aug1, stat='sd')
tws_sep2_sd = cellStats(tws_sep1, stat='sd')
tws_oct2_sd = cellStats(tws_oct1, stat='sd')
tws_nov2_sd = cellStats(tws_nov1, stat='sd')
tws_dec2_sd = cellStats(tws_dec1, stat='sd')

tws_mean = mean(tws_jan2,tws_feb2,tws_mar2,tws_apl2,tws_may2,tws_jun2,
                tws_jul2,tws_aug2,tws_sep2,tws_oct2,tws_nov2,tws_dec2)

tws_sd = mean(tws_jan2_sd,tws_feb2_sd,tws_mar2_sd,tws_apl2_sd,tws_may2_sd,
                   tws_jun2_sd,tws_jul2_sd,tws_aug2_sd,tws_sep2_sd,tws_oct2_sd,
                   tws_nov2_sd,tws_dec2_sd)

tws_jan1_sd <- calc(tws_ensemble_mean[[jan]], fun = sd)
tws_feb1_sd <- calc(tws_ensemble_mean[[feb]], fun = sd)
tws_mar1_sd <- calc(tws_ensemble_mean[[mar]], fun = sd)
tws_apl1_sd <- calc(tws_ensemble_mean[[apl]], fun = sd)
tws_may1_sd <- calc(tws_ensemble_mean[[may]], fun = sd)
tws_jun1_sd <- calc(tws_ensemble_mean[[jun]], fun = sd)
tws_jul1_sd <- calc(tws_ensemble_mean[[jul]], fun = sd)
tws_aug1_sd <- calc(tws_ensemble_mean[[aug]], fun = sd)
tws_sep1_sd <- calc(tws_ensemble_mean[[sep]], fun = sd)
tws_oct1_sd <- calc(tws_ensemble_mean[[oct]], fun = sd)
tws_nov1_sd <- calc(tws_ensemble_mean[[nov]], fun = sd)
tws_dec1_sd <- calc(tws_ensemble_mean[[dec]], fun = sd)




tws_d = list();
for (i in 1:180){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  
  if(i%%12 == 1){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_jan1))/tws_jan1_sd
    
  } else if(i%%12 == 2){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_feb1))/tws_feb1_sd
    
  } else if(i%%12 == 3){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_mar1))/tws_mar1_sd
    
  } else if(i%%12 == 4){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_apl1))/tws_apl1_sd
    
  } else if(i%%12 == 5){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_may1))/tws_may1_sd
    
  } else if(i%%12 == 6){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_jun1))/tws_jun1_sd
    
  } else if(i%%12 == 7){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_jul1))/tws_jul1_sd
    
  } else if(i%%12 == 8){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_aug1))/tws_aug1_sd
    
  } else if(i%%12 == 9){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_sep1))/tws_sep1_sd
    
  } else if(i%%12 == 10){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_oct1))/tws_oct1_sd
    
  } else if(i%%12 == 11){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_nov1))/tws_nov1_sd
    
  } else if(i%%12 == 0){
    tws_d[[i]] = ((tws_ensemble_mean[[i]]-tws_dec1))/tws_dec1_sd
    
  }  else {
    NULL
  }
  
}

tws_d = stack(tws_d)

plot(tws_d[[1]])
plot(spei_01_r[[1]])
plot(asi_fao_r[[2]])

#extract

# tws_d_t <- extract(tws_d, zones)
tws_d_t <-  raster::extract(x = tws_d, y = zones, FUN=mean) 
spei_01_r_t <-  raster::extract(x = spei_01_r, y = zones, FUN=mean) 
spei_03_r_t <-  raster::extract(x = spei_03_r, y = zones, FUN=mean) 
spei_06_r_t <-  raster::extract(x = spei_06_r, y = zones, FUN=mean) 
spei_12_r_t <-  raster::extract(x = spei_12_r, y = zones, FUN=mean) 
spei_24_r_t <-  raster::extract(x = spei_24_r, y = zones, FUN=mean) 
spei_48_r_t <-  raster::extract(x = spei_48_r, y = zones, FUN=mean) 
pdsi1_r_t <-  raster::extract(x = pdsi1_r, y = zones, FUN=mean) 

tws_d_t1 <-  raster::extract(x = tws_d, y = basin, FUN=mean) 
spei_01_r_t1 <-  raster::extract(x = spei_01_r, y = basin, FUN=mean) 
spei_03_r_t1 <-  raster::extract(x = spei_03_r, y = basin, FUN=mean) 
spei_06_r_t1 <-  raster::extract(x = spei_06_r, y = basin, FUN=mean) 
spei_12_r_t1 <-  raster::extract(x = spei_12_r, y = basin, FUN=mean) 
spei_24_r_t1<-  raster::extract(x = spei_24_r, y = basin, FUN=mean) 
spei_48_r_t1 <-  raster::extract(x = spei_48_r, y = basin, FUN=mean) 
pdsi1_r_t1 <-  raster::extract(x = pdsi1_r, y = basin, FUN=mean) 


time1 <- rep(seq(as.Date('2002-04-01'), as.Date('2017-03-30'), 'month'),6)
leg1 = c(rep(c("Arid"),180),rep(c("Cold"),180),rep(c("Temperate"),180),
         rep(c("Tropical"),180),rep(c("Polar"),180),rep(c("Mon-ASIA"),180))

# # time2 <- factor(time1, levels = c("Arid", "Cold", "Temperate","Tropical",
#                                   "Polar","Mon-ASIA"))

y_tws = c(tws_d_t[[1]][2,],tws_d_t[[2]][2,],tws_d_t[[3]][2,],tws_d_t[[4]][2,],
          tws_d_t[[5]][2,],tws_d_t1[[1]][1,])
y_pdsi = c(pdsi1_r_t[[1]][2,],pdsi1_r_t[[2]][2,],pdsi1_r_t[[3]][2,],pdsi1_r_t[[4]][2,],
          pdsi1_r_t[[5]][2,],pdsi1_r_t1[[1]][1,])
y_spei_12 = c(spei_12_r_t[[1]][2,],spei_12_r_t[[2]][2,],spei_12_r_t[[3]][2,],spei_12_r_t[[4]][2,],
              spei_12_r_t[[5]][2,],spei_12_r_t1[[1]][1,])

tws_d_t1 = data.frame(y_tws,time1,leg1)
pdsi_d_t1 = data.frame(y_pdsi,time1,leg1)
spei_d_t1 = data.frame(y_spei_12,time1,leg1)




# tws_d_t1$time1 = factor(tws_d_t1$time1, levels = c("Arid", "Cold", "Temperate","Tropical",
#                                           "Polar","Mon-ASIA"))
# 
# pdsi_d_t1$time1 = factor(pdsi_d_t1$time1, levels = c("Arid", "Cold", "Temperate","Tropical",
#                                                    "Polar","Mon-ASIA"))
# 
# spei_d_t1$time1 = factor(spei_d_t1$time1, levels = c("Arid", "Cold", "Temperate","Tropical",
#                                                    "Polar","Mon-ASIA"))

#plotting timeseris

a1 = ggplot(data=tws_d_t1,aes(x=time1,y=y_tws, color=leg1)) + geom_line(size=1)+
# ggtitle("Step 2: Apply 5 X 5 moving window on Aphrodite data") +
  xlab("Time") +
  ylab("WDI") +
  labs(color = 'Region')+
  # labs(fill= 'Regions')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  # scale_fill_gradientn(colours = heat.colors(10),limits=c(-3,3))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=12),
        legend.text=element_text(size=12),
        legend.position = "top",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
a1


a2 = ggplot(data=pdsi_d_t1,aes(x=time1,y=y_pdsi, color=leg1)) + geom_line(size=1)+
# ggtitle("Step 2: Apply 5 X 5 moving window on Aphrodite data") +
  xlab("Time") +
  ylab("PDSI") +
  labs(color = 'Regions')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  # scale_fill_gradientn(colours = heat.colors(10),limits=c(-3,3))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=12),
        legend.text=element_text(size=12),
        legend.position = "top",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
a2

a3 = ggplot(data=spei_d_t1,aes(x=time1,y=y_spei_12, color=leg1)) + geom_line(size=1)+
# ggtitle("Step 2: Apply 5 X 5 moving window on Aphrodite data") +
  xlab("Time") +
  ylab("SPEI-12") +
  labs(color= 'Regions')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  # scale_fill_gradientn(colours = heat.colors(10),limits=c(-3,3))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_text(size=12),
        axis.title.y = element_text(size=12),
        axis.text.x = element_text(size=12),
        axis.text.y = element_text(size=12),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=12),
        legend.text=element_text(size=12),
        legend.position = "top",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

a1
# ggsave('plot.png', dpi = 300, height = 5, width = 5, unit = 'in')
ggsave("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/maps/save/a3.tiff",a3,dpi = 300)


#-------------------------------------------------------------
#spatial

b_mjj <- c()
b_aso <- c()
b_ndjfma <- c()
for (i in 1:178){
  if(i%%12 == 2){
    b_mjj <- c(b_mjj, i)
    b_mjj <- c(b_mjj, i+1)
    b_mjj <- c(b_mjj, i+2)
    
  } 
  
}
for (i in 1:178){
  if(i%%12 == 5){
    b_aso <- c(b_aso, i)
    b_aso <- c(b_aso, i+1)
    b_aso <- c(b_aso, i+2)
  } 
}
# for (i in 4:176){
#   if(i%%12 == 11){
#     b_ndjfma <- c(b_ndjfma, i)
#     b_ndjfma <- c(b_ndjfma, i+1)
#     b_ndjfma <- c(b_ndjfma, i+2)
#     b_ndjfma <- c(b_ndjfma, i+3)
#     b_ndjfma <- c(b_ndjfma, i+4)
#   } 
# }


# #future
# nf_mjj <- c()
# nf_aso <- c()
# nf_ndjfma <- c()
# for (i in 1:358){
#   if(i%%12 == 5){
#     nf_mjj <- c(nf_mjj, i)
#     nf_mjj <- c(nf_mjj, i+1)
#     nf_mjj <- c(nf_mjj, i+2)
#   } 
# }
# for (i in 1:358){
#   if(i%%12 == 8){
#     nf_aso <- c(nf_aso, i)
#     nf_aso <- c(nf_aso, i+1)
#     nf_aso <- c(nf_aso, i+2)
#   } 

tws_mjj_a = list()
tws_aso_a = list()

pdsi_mjj_a = list()
pdsi_aso_a = list()

spei_12_mjj_a = list()
spei_12_aso_a = list()

spei_12_yw = list()
spei_12_yd = list()

j=0;
k=0;
l=0;
for (i in (seq(2,170, by=11))){
  k=k+1
  spei_12_r1 = spei_12_r[[i:c(i+6)]]
  spei_12_yw[[k]] <- calc(spei_12_r1, fun = max)
}
for (i in (seq(8,170, by=11))){
  l=l+1
  spei_12_r2 = spei_12_r[[i:c(i+6)]]
  spei_12_yd[[l]] <- calc(spei_12_r2, fun = min)
}

spei_12_yd = stack(spei_12_yd)
spei_12_yw = stack(spei_12_yw)
plot(spei_12_yw)


#apv
for (i in (seq(1,45, by=3))){
tws_d_mjj = tws_d[[b_mjj[i:c(i+2)]]]
tws_d_aso = tws_d[[b_aso[i:c(i+2)]]]

spei_12_mjj = spei_12_r[[b_mjj[i:c(i+2)]]]
spei_12_aso = spei_12_r[[b_aso[i:c(i+2)]]]

pdsi_mjj = pdsi1_r[[b_mjj[i:c(i+2)]]]
pdsi_aso = pdsi1_r[[b_aso[i:c(i+2)]]]

# tws_d_ndjfma = tws_d[[b_ndjfma]]
j = j+1
tws_mjj_a[[j]] <- calc(tws_d_mjj, fun = mean)
tws_aso_a[[j]] <- calc(tws_d_aso, fun = mean)

spei_12_mjj_a[[j]] <- calc(spei_12_mjj, fun = mean)
spei_12_aso_a[[j]] <- calc(spei_12_aso, fun = mean)

pdsi_mjj_a[[j]] <- calc(pdsi_mjj, fun = mean)
pdsi_aso_a[[j]] <- calc(pdsi_aso, fun = mean)

}



#severe droughts

spei_12_aso_a = stack(spei_12_aso_a)
spei_12_mjj_a = stack(spei_12_mjj_a)
pdsi_mjj_a = stack(pdsi_mjj_a)
pdsi_aso_a = stack(pdsi_aso_a)
tws_mjj_a = stack(tws_mjj_a)
tws_aso_a = stack(tws_aso_a)
asi_fao_r1 = asi_fao_r[[1:15]]
asi_fao_r2 = asi_fao_r1
asi_fao_r2[asi_fao_r2>251] = NA

spei_12_f = spei_12_yw
spei_12_d = spei_12_yd

pdsi_mjj_a1 = pdsi_mjj_a
tws_mjj_a1 = tws_mjj_a

spei_12_f[spei_12_f<2.5] = NA
spei_12_d[spei_12_d>-2] = NA


pdsi_mjj_a1[pdsi_mjj_a1>1] = NA
tws_mjj_a1[tws_mjj_a1>1] = NA


plot(spei_12_mjj_a1[[1]])
plot(pdsi_mjj_a1[[1]])
plot(tws_mjj_a1[[1]])
plot(asi_fao_r2[[1]])
plot(spei_12_d[[7]])

tws_mjj_a1_c <-  raster::extract(x = tws_mjj_a1, y = zones, FUN=mean) 
spei_12_mjj_a1_c <-  raster::extract(x = spei_12_mjj_a1, y = zones, FUN=mean) 
pdsi_mjj_a1_c <-  raster::extract(x = pdsi_mjj_a1, y = zones, FUN=mean) 
asi_fao_r2_c <-  raster::extract(x = asi_fao_r2, y = zones, FUN=mean) 
# spei_12_r_t1 <-  raster::extract(x = spei_12_r, y = basin, FUN=mean) 
# spei_24_r_t1<-  raster::extract(x = spei_24_r, y = basin, FUN=mean) 
# spei_48_r_t1 <-  raster::extract(x = spei_48_r, y = basin, FUN=mean) 
# pdsi1_r_t1 <-  raster::extract(x = pdsi1_r, y = basin, FUN=mean) 


time1 <- rep(seq(as.Date('2002-04-01'), as.Date('2017-03-30'), 'month'),6)
leg1 = c(rep(c("Arid"),180),rep(c("Cold"),180),rep(c("Temperate"),180),
         rep(c("Tropical"),180),rep(c("Polar"),180),rep(c("Mon-ASIA"),180))

# # time2 <- factor(time1, levels = c("Arid", "Cold", "Temperate","Tropical",
#                                   "Polar","Mon-ASIA"))

y_tws_c1 = c(tws_mjj_a1_c[[1]][2,],tws_mjj_a1_c[[2]][2,],
          tws_mjj_a1_c[[3]][2,],tws_mjj_a1_c[[4]][2,],
          tws_mjj_a1_c[[5]][2,])
y_spei_c1 = c(spei_12_mjj_a1_c[[1]][2,],spei_12_mjj_a1_c[[2]][2,],
           spei_12_mjj_a1_c[[3]][2,],spei_12_mjj_a1_c[[4]][2,],
           spei_12_mjj_a1_c[[5]][2,])
y_pdsi_c1 = c(pdsi_mjj_a1_c[[1]][2,],pdsi_mjj_a1_c[[2]][2,],
              pdsi_mjj_a1_c[[3]][2,],pdsi_mjj_a1_c[[4]][2,],
              pdsi_mjj_a1_c[[5]][2,])
asi_fao_r2_c1 = c(asi_fao_r2_c[[1]][1,],asi_fao_r2_c[[2]][1,],
                 asi_fao_r2_c[[3]][1,],asi_fao_r2_c[[4]][1,],
                 asi_fao_r2_c[[5]][1,])

corr_df1 = data.frame(tws_mjj_a1_c[[1]][2,],spei_12_mjj_a1_c[[1]][2,],
                     pdsi_mjj_a1_c[[1]][2,],asi_fao_r2_c[[1]][1,])

corr_df2 = data.frame(tws_mjj_a1_c[[2]][2,],spei_12_mjj_a1_c[[2]][2,],
                      pdsi_mjj_a1_c[[2]][2,],asi_fao_r2_c[[2]][1,])

corr_df3 = data.frame(tws_mjj_a1_c[[3]][2,],spei_12_mjj_a1_c[[3]][2,],
                      pdsi_mjj_a1_c[[3]][2,],asi_fao_r2_c[[3]][1,])

corr_df4 = data.frame(tws_mjj_a1_c[[4]][2,],spei_12_mjj_a1_c[[4]][2,],
                      pdsi_mjj_a1_c[[4]][2,],asi_fao_r2_c[[4]][1,])

corr_df5 = data.frame(tws_mjj_a1_c[[5]][2,],spei_12_mjj_a1_c[[5]][2,],
                      pdsi_mjj_a1_c[[5]][2,],asi_fao_r2_c[[5]][1,])

tws_d_t1 = data.frame(y_tws,time1,leg1)
pdsi_d_t1 = data.frame(y_pdsi,time1,leg1)
spei_d_t1 = data.frame(y_spei_12,time1,leg1)



yld_corr1 = data.frame(yld_corr)

y_2000 = data.frame(yld_corr1[1:450,1:5])
y_2001 = data.frame(yld_corr1[1:450,12:16])
y_2002 = data.frame(yld_corr1[1:450,23:27])
y_2003 = data.frame(yld_corr1[1:450,34:38])
y_2004 = data.frame(yld_corr1[1:450,45:49])
y_2005 = data.frame(yld_corr1[1:450,56:60])
y_2006 = data.frame(yld_corr1[1:450,67:71])
y_2007 = data.frame(yld_corr1[1:450,78:82])
y_2008 = data.frame(yld_corr1[1:450,89:93])
y_2009 = data.frame(yld_corr1[1:450,100:104])
y_2010 = data.frame(yld_corr1[1:450,111:115])
y_2011 = data.frame(yld_corr1[1:450,122:126])
y_2012 = data.frame(yld_corr1[1:450,133:137])
y_2013 = data.frame(yld_corr1[1:450,144:148])
y_2014 = data.frame(yld_corr1[1:450,155:159])
y_2015 = data.frame(yld_corr1[1:450,166:170])


library(Hmisc)
res_2000<-rcorr(as.matrix(y_2000))
res_2001<-rcorr(as.matrix(y_2001))
res_2002<-rcorr(as.matrix(y_2002))
res_2003<-rcorr(as.matrix(y_2003))
res_2004<-rcorr(as.matrix(y_2004))
res_2005<-rcorr(as.matrix(y_2005))
res_2006<-rcorr(as.matrix(y_2006))
res_2007<-rcorr(as.matrix(y_2007))
res_2008<-rcorr(as.matrix(y_2008))
res_2009<-rcorr(as.matrix(y_2009))
res_2010<-rcorr(as.matrix(y_2010))
res_2011<-rcorr(as.matrix(y_2011))
res_2012<-rcorr(as.matrix(y_2012))
res_2013<-rcorr(as.matrix(y_2013))
res_2014<-rcorr(as.matrix(y_2014))
res_2015<-rcorr(as.matrix(y_2015))
# res2[[3]][1,]

res_2000_1= res_2000[[3]][1,2:5]
res_2001_1= res_2001[[3]][1,2:5]
res_2002_1= res_2002[[3]][1,2:5]
res_2003_1= res_2003[[3]][1,2:5]
res_2004_1= res_2004[[3]][1,2:5]
res_2005_1= res_2005[[3]][1,2:5]
res_2006_1= res_2006[[3]][1,2:5]
res_2007_1= res_2007[[3]][1,2:5]
res_2008_1= res_2008[[3]][1,2:5]
res_2009_1= res_2009[[3]][1,2:5]
res_2010_1= res_2010[[3]][1,2:5]
res_2011_1= res_2011[[3]][1,2:5]
res_2012_1= res_2012[[3]][1,2:5]
res_2013_1= res_2013[[3]][1,2:5]
res_2014_1= res_2014[[3]][1,2:5]
res_2015_1= res_2015[[3]][1,2:5]


res3 = data.frame(res_2000_1,res_2001_1,res_2002_1,res_2003_1,res_2004_1,
                  res_2005_1,res_2006_1,res_2007_1,res_2008_1,res_2009_1,
                  res_2010_1,res_2011_1,res_2012_1,res_2013_1,res_2014_1, res_2015_1)
res4 = t(res3)
colnames(res4)=c("NDVI","EVI","LAI","GPP")
rownames(res4)=c("2000","2001","2002","2003",
                 "2004","2005","2006","2007",
                 "2008","2009","2010","2011",
                 "2012","2013","2014","2015")

corrplot(res4)

tiff("C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/corr.tiff", units="in", width=5, height=4, res=300)

corrplot(res4, method = "circle", 
         tl.cex = 1, cl.ratio=1)

dev.off()


path1 = "C:/Users/ezhil/OneDrive/AIT/papers/yield_estimation_kanlaya/maps/new/save/"
ggsave(filename="corr.tiff", plot=b, path=path1, dpi=300)


library(ggcorrplot)
ggcorrplot(res4, hc.order = TRUE, type = "lower", lab = TRUE)
# library(reshape2)
# 
# res4 <- cbind(ID=rownames(res3),  res3)
# melt(res4)

install.packages("corrplot")

library(corrplot)
corrplot(res3, type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45)

heatmap(x = res3, col = col, symm = TRUE)


library(PerformanceAnalytics)


chart.Correlation(res3, histogram=TRUE, pch=19,
                  method = c("pearson"))


library(corrplot);

data <- array(data=res3)
              
              # , dim=c(10,10)
              # , dimnames=list(paste("A", 1:10, sep=""), paste("B", 1:10, sep="")));

corrplot(data, type="full", order="hclust", tl.col="black", tl.srt=45)


corrplot(data, method="number", is.corr=FALSE)

library(corrplot)

#Transform data to matrix
matrix_cor<-as.matrix(data[,-1])

#Set row names as df first column
row.names(matrix_cor)<-df[,1]
tiff("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/maps/save/Reg5.tiff", units="in", width=5, height=4, res=300)

corrplot(matrix_cor,
         method = "circle")

ggsave(filename="lapse_rate2_temp.tiff", plot=combined3, path=path1, dpi=300)



cr = data.frame(df1[,3],df6[,3])

a = seq(1,565691,by=1000)

df1_1 = data.frame(df1[a,3])
df2_1 = data.frame(df2[a,3])
df3_1 = data.frame(df3[a,3])
df4_1 = data.frame(df4[a,3])
df5_1 = data.frame(df5[a,3])
df6_1 = data.frame(df6[a,3])
df7_1 = data.frame(df7[a,3])
df8_1 = data.frame(df8[a,3])

colnames(df1_1) <- c("Ametryn")
colnames(df2_1) <- c("Atrazine")
colnames(df3_1) <- c("Diuron")
colnames(df4_1) <- c("Glyphosate")
colnames(df5_1) <- c("Paraquat")
colnames(df6_1) <- c("Bulk_density")
colnames(df7_1) <- c("Field_capacity")
colnames(df8_1) <- c("Organic_carbon")

tiff("C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/maps/save/Reg5.tiff", units="in", width=5, height=4, res=300)


# cr = data.frame(df1_1,df2_1,df3_1,df4_1,df5_1)

chart.Correlation(corr_df5, histogram=TRUE, pch=19,
                  method = c("pearson"))

dev.off()

tiff("C:/Users/ezhil/OneDrive/AIT/papers/leaching_data/maps/save/amet_cor.tiff", units="in", width=5, height=4, res=300)


cr1 = data.frame(df6_1,df7_1,df8_1,df1_1)

chart.Correlation(cr1, histogram=TRUE, pch=19,
                  method = c("pearson"))

dev.off()

tiff("C:/Users/ezhil/OneDrive/AIT/papers/leaching_data/maps/save/atra_cor.tiff", units="in", width=5, height=4, res=300)

cr2 = data.frame(df6_1,df7_1,df8_1,df2_1)

chart.Correlation(cr2, histogram=TRUE, pch=19,
                  method = c("pearson"))
dev.off()

tiff("C:/Users/ezhil/OneDrive/AIT/papers/leaching_data/maps/save/diu_cor.tiff", units="in", width=5, height=4, res=300)

cr3 = data.frame(df6_1,df7_1,df8_1,df3_1)

chart.Correlation(cr3, histogram=TRUE, pch=19,
                  method = c("pearson"))
dev.off()

tiff("C:/Users/ezhil/OneDrive/AIT/papers/leaching_data/maps/save/glyp_cor.tiff", units="in", width=5, height=4, res=300)

cr4 = data.frame(df6_1,df7_1,df8_1,df4_1)

chart.Correlation(cr4, histogram=TRUE, pch=19,
                  method = c("pearson"))
dev.off()

tiff("C:/Users/ezhil/OneDrive/AIT/papers/leaching_data/maps/save/paraq_cor.tiff", units="in", width=5, height=4, res=300)

cr5 = data.frame(df6_1,df7_1,df8_1,df5_1)

chart.Correlation(cr5, histogram=TRUE, pch=19,
                  method = c("pearson"))
dev.off()





spei_cor = stack(asi_fao_r2, spei_12_mjj_a1)
pdsi_cor = stack(asi_fao_r2, pdsi_mjj_a1)
tws_cor = stack(asi_fao_r2, tws_mjj_a1)
#---------------spei

spei_12_mjj_a_1 <- rasterToPoints(spei_12_mjj_a[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("SPEI_12")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
  
spei_12_mjj_a_2 <- rasterToPoints(spei_12_mjj_a[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_3 <- rasterToPoints(spei_12_mjj_a[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_mjj_a_4 <- rasterToPoints(spei_12_mjj_a[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_mjj_a_5 <- rasterToPoints(spei_12_mjj_a[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_6 <- rasterToPoints(spei_12_mjj_a[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("SPEI_12")+
  
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_7 <- rasterToPoints(spei_12_mjj_a[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_8 <- rasterToPoints(spei_12_mjj_a[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_9 <- rasterToPoints(spei_12_mjj_a[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_10 <- rasterToPoints(spei_12_mjj_a[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_mjj_a_11 <- rasterToPoints(spei_12_mjj_a[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("SPEI_12")+
  
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_mjj_a_12 <- rasterToPoints(spei_12_mjj_a[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_mjj_a_13 <- rasterToPoints(spei_12_mjj_a[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_13)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_13=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_14 <- rasterToPoints(spei_12_mjj_a[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_14)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_14=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= '2015')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_mjj_a_15 <- rasterToPoints(spei_12_mjj_a[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_15)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_15=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2016") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
#-------pdsi

pdsi_mjj_a_1 <- rasterToPoints(pdsi_mjj_a[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("PDSI")+
  
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

pdsi_mjj_a_2 <- rasterToPoints(pdsi_mjj_a[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

pdsi_mjj_a_3 <- rasterToPoints(pdsi_mjj_a[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

pdsi_mjj_a_4 <- rasterToPoints(pdsi_mjj_a[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_5 <- rasterToPoints(pdsi_mjj_a[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

pdsi_mjj_a_6 <- rasterToPoints(pdsi_mjj_a[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("PDSI")+
  
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_7 <- rasterToPoints(pdsi_mjj_a[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

pdsi_mjj_a_8 <- rasterToPoints(pdsi_mjj_a[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_9 <- rasterToPoints(pdsi_mjj_a[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_10 <- rasterToPoints(pdsi_mjj_a[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_11 <- rasterToPoints(pdsi_mjj_a[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("PDSI")+
  
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_12 <- rasterToPoints(pdsi_mjj_a[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_13 <- rasterToPoints(pdsi_mjj_a[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_13)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_13=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
pdsi_mjj_a_14 <- rasterToPoints(pdsi_mjj_a[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_14)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_14=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

pdsi_mjj_a_15 <- rasterToPoints(pdsi_mjj_a[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(pdsi_mjj_a_15)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
pdsi_mjj_a_15=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2016") +
  labs(fill= 'PDSI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
#------------------------

tws_mjj_a_1 <- rasterToPoints(tws_mjj_a[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("WDI")+
  
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

tws_mjj_a_2 <- rasterToPoints(tws_mjj_a[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_3 <- rasterToPoints(tws_mjj_a[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_4 <- rasterToPoints(tws_mjj_a[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

tws_mjj_a_5 <- rasterToPoints(tws_mjj_a[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_6 <- rasterToPoints(tws_mjj_a[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("WDI")+
  
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_7 <- rasterToPoints(tws_mjj_a[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_8 <- rasterToPoints(tws_mjj_a[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

tws_mjj_a_9 <- rasterToPoints(tws_mjj_a[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_10 <- rasterToPoints(tws_mjj_a[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

tws_mjj_a_11 <- rasterToPoints(tws_mjj_a[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("WDI")+
  
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_12 <- rasterToPoints(tws_mjj_a[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_13 <- rasterToPoints(tws_mjj_a[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_13)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_13=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_14 <- rasterToPoints(tws_mjj_a[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_14)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_14=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_mjj_a_15 <- rasterToPoints(tws_mjj_a[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_mjj_a_15)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_mjj_a_15=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2016") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
#--------------asi

asi_fao_r2_1 <- rasterToPoints(asi_fao_r2[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("ASI")+
  
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

asi_fao_r2_2 <- rasterToPoints(asi_fao_r2[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_3 <- rasterToPoints(asi_fao_r2[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

asi_fao_r2_4 <- rasterToPoints(asi_fao_r2[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_5 <- rasterToPoints(asi_fao_r2[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_6 <- rasterToPoints(asi_fao_r2[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("ASI")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

asi_fao_r2_7 <- rasterToPoints(asi_fao_r2[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

asi_fao_r2_8 <- rasterToPoints(asi_fao_r2[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_9 <- rasterToPoints(asi_fao_r2[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_10 <- rasterToPoints(asi_fao_r2[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_11 <- rasterToPoints(asi_fao_r2[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("ASI")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_12 <- rasterToPoints(asi_fao_r2[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_13 <- rasterToPoints(asi_fao_r2[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_13)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_13=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_14 <- rasterToPoints(asi_fao_r2[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_14)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_14=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
asi_fao_r2_15 <- rasterToPoints(asi_fao_r2[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(asi_fao_r2_15)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
asi_fao_r2_15=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  xlab("Longitude") +
  ylab("2016") +
  labs(fill= 'ASI(%)')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(0,100))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
#----tws
tws_d_1 <- rasterToPoints(tws_d[[jan]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Jan")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

tws_d_2 <- rasterToPoints(tws_d[[feb]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Feb")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_3 <- rasterToPoints(tws_d[[mar]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Mar")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_4 <- rasterToPoints(tws_d[[apl]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Apl")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_5 <- rasterToPoints(tws_d[[may]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("May")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_6 <- rasterToPoints(tws_d[[jun]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Jun")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_7 <- rasterToPoints(tws_d[[jul]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Jul")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_8 <- rasterToPoints(tws_d[[aug]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Aug")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_9 <- rasterToPoints(tws_d[[sep]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Sep")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_10 <- rasterToPoints(tws_d[[oct]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Oct")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_11 <- rasterToPoints(tws_d[[nov]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Nov")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
tws_d_12 <- rasterToPoints(tws_d[[dec]])
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("Dec")+
  
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'WDI')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

#---floods/droughts

spei_12_f_1 <- rasterToPoints(spei_12_f[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_f_1

spei_12_f_2 <- rasterToPoints(spei_12_f[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_3 <- rasterToPoints(spei_12_f[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_4 <- rasterToPoints(spei_12_f[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_5 <- rasterToPoints(spei_12_f[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_6 <- rasterToPoints(spei_12_f[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_7 <- rasterToPoints(spei_12_f[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_8 <- rasterToPoints(spei_12_f[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_9 <- rasterToPoints(spei_12_f[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_10 <- rasterToPoints(spei_12_f[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_11 <- rasterToPoints(spei_12_f[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_12 <- rasterToPoints(spei_12_f[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_13 <- rasterToPoints(spei_12_f[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_13)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_13=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_14 <- rasterToPoints(spei_12_f[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_14)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_14=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_f_15 <- rasterToPoints(spei_12_f[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_f_15)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_f_15=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Floods")+
  xlab("Longitude") +
  ylab("2016") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_d_1 <- rasterToPoints(spei_12_d[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_d_2 <- rasterToPoints(spei_12_d[[2]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_2)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2003") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x =element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_d_3 <- rasterToPoints(spei_12_d[[3]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_3)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2004") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x =element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_4 <- rasterToPoints(spei_12_d[[4]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_4)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2005") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_5 <- rasterToPoints(spei_12_d[[5]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_5)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2006") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_6 <- rasterToPoints(spei_12_d[[6]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_6)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_6=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2007") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_7 <- rasterToPoints(spei_12_d[[7]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_7)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_7=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2008") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_8 <- rasterToPoints(spei_12_d[[8]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_8)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_8=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2009") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_9 <- rasterToPoints(spei_12_d[[9]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_9)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_9=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2010") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_10 <- rasterToPoints(spei_12_d[[10]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_10)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_10=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2011") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_11 <- rasterToPoints(spei_12_d[[11]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_11)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_11=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2012") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_12 <- rasterToPoints(spei_12_d[[12]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_12)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_12=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2013") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_13 <- rasterToPoints(spei_12_d[[13]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_13)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_13=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2014") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_14 <- rasterToPoints(spei_12_d[[14]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_14)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_14=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2015") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
spei_12_d_15 <- rasterToPoints(spei_12_d[[15]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_d_15)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_d_15=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_polygon(data=basin1, aes(x=long, y=lat, group=group), 
               fill=NA, color="grey50", size=0.25) +
  # geom_polygon(data = basin)+
  ggtitle("Droughts")+
  xlab("Longitude") +
  ylab("2016") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(20),limits=c(-6,6))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

spei_12_f_1
#------
spei_12_mjj_a_1 <- rasterToPoints(spei_12_mjj_a[[1]])
#Make the points a dataframe for ggplot
df <- data.frame(spei_12_mjj_a_1)
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
spei_12_mjj_a_1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  ggtitle("SPEI_12")+
  xlab("Longitude") +
  ylab("2002") +
  labs(fill= 'SPEI_12')+
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-4,4))+
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )

memory.limit(size=56000)
library(patchwork)
combined2 = spei_12_mjj_a_1 + pdsi_mjj_a_1 + tws_mjj_a_1 + asi_fao_r2_1+
  spei_12_mjj_a_2 + pdsi_mjj_a_2 + tws_mjj_a_2 + asi_fao_r2_2+
  spei_12_mjj_a_3 + pdsi_mjj_a_3 + tws_mjj_a_3 + asi_fao_r2_3+
  spei_12_mjj_a_4 + pdsi_mjj_a_4 + tws_mjj_a_4 + asi_fao_r2_4+
  spei_12_mjj_a_5 + pdsi_mjj_a_5 + tws_mjj_a_5 + asi_fao_r2_5

combined4 = spei_12_mjj_a_6 + pdsi_mjj_a_6 + tws_mjj_a_6 + asi_fao_r2_6+
  spei_12_mjj_a_7 + pdsi_mjj_a_7 + tws_mjj_a_7 + asi_fao_r2_7+
  spei_12_mjj_a_8 + pdsi_mjj_a_8 + tws_mjj_a_8 + asi_fao_r2_8+
  spei_12_mjj_a_9 + pdsi_mjj_a_9 + tws_mjj_a_9 + asi_fao_r2_9+
  spei_12_mjj_a_10 + pdsi_mjj_a_10 + tws_mjj_a_10 + asi_fao_r2_10

combined6 = spei_12_mjj_a_11 + pdsi_mjj_a_11 + tws_mjj_a_11 + asi_fao_r2_11+
  spei_12_mjj_a_12 + pdsi_mjj_a_2 + tws_mjj_a_12 + asi_fao_r2_12+
  spei_12_mjj_a_13 + pdsi_mjj_a_3 + tws_mjj_a_13 + asi_fao_r2_13+
  spei_12_mjj_a_14 + pdsi_mjj_a_4 + tws_mjj_a_14 + asi_fao_r2_14+
  spei_12_mjj_a_15 + pdsi_mjj_a_5 + tws_mjj_a_15 + asi_fao_r2_15

combined8 = tws_d_1 + tws_d_2 + tws_d_3 + tws_d_4+tws_d_5+tws_d_6+
  tws_d_7+tws_d_8+tws_d_9+tws_d_10+tws_d_11+tws_d_12

combined10 = spei_12_f_1 + spei_12_d_1 + spei_12_f_2 + spei_12_d_2+
  spei_12_f_3 + spei_12_d_3 + spei_12_f_4 + spei_12_d_4+
  spei_12_f_5 + spei_12_d_5

combined12 = spei_12_f_6 + spei_12_d_6 + spei_12_f_7 + spei_12_d_7+
  spei_12_f_8 + spei_12_d_8 + spei_12_f_9 + spei_12_d_9+
  spei_12_f_10 + spei_12_d_10

combined14 = spei_12_f_11 + spei_12_d_11 + spei_12_f_12 + spei_12_d_12+
  spei_12_f_13 + spei_12_d_13 + spei_12_f_14 + spei_12_d_14+
  spei_12_f_15 + spei_12_d_15 

combined3 = combined2 + plot_layout(ncol = 4, guides = "collect") & theme(legend.position = 'right')
combined5 = combined4 + plot_layout(ncol = 4, guides = "collect") & theme(legend.position = 'right')
combined7 = combined6 + plot_layout(ncol = 4, guides = "collect") & theme(legend.position = 'right')
combined9 = combined8 + plot_layout(ncol = 4, guides = "collect") & theme(legend.position = 'bottom')
combined11 = combined10 + plot_layout(ncol = 2, guides = "collect") & theme(legend.position = 'right')
combined13 = combined12 + plot_layout(ncol = 2, guides = "collect") & theme(legend.position = 'right')
combined15 = combined14 + plot_layout(ncol = 2, guides = "collect") & theme(legend.position = 'right')

combined15

path1 = "C:/Users/ezhil/OneDrive/AIT/guest_lecture/IITR/maps/save/"

ggsave(filename="fd3.tiff", plot=combined15, path=path1, dpi=300)
ggsave(filename="lapse_rate2_temp.tiff", plot=combined3, path=path1, dpi=300)



# fun_mae_nolr <- function(x) {mean(abs((x[1:192] - x[193:384])))}
# sd_mae_nolr <- calc(stat_ras_2p_p1_n1, fun_mae_nolr)
# 
# plot(sd_mae_nolr)
# 
# #rmse
# fun_sqrt_nolr <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
# sd_sqrt_nolr <- calc(stat_ras_2p_p1_n1, fun_sqrt_nolr)
# 
# plot(sd_sqrt_nolr)

#r2

rsq <- function (x) cor(x[1:15], x[16:30], na.rm=T)
spei_cor1 <- calc(spei_cor, rsq)
plot(spei_cor1)



# tws_d_ndjfma1 <- calc(ap_ndjfma, fun = mean)

# ap_all = month_ap_r_p1
# ap_all1 = calc(ap_all, fun = mean)
# 
# ap_mjj1 = resample(ap_mjj1,s1_rcm1_ssp2_f_all1,'bilinear')

plot()
#reproject
# st_lr_p = projectRaster(month_st_lr, crs=wgs)
# month_apv_r1_p = projectRaster(month_apv_r1, crs=wgs)
# month_rcm_o1_p =  projectRaster(month_rcm_o1, crs=wgs)
# month_rcm_p1_p =  projectRaster(month_rcm_p1, crs=wgs)
# 
# 
# month_st_lr1 = mask(st_lr_p, basin)
# month_apv_lr1 = mask(month_apv_r1_p, basin)
# month_rcm_o1_lr1 = mask(month_rcm_o1_p, basin)
# month_rcm_p1_lr1 = mask(month_rcm_p1_p, basin)


# #future comparison
# rcm_f26_mjj1_p = projectRaster(rcm_f26_mjj1, crs=wgs84)
# rcm_f26_aso1_p =  projectRaster(rcm_f26_aso1, crs=wgs84)
# rcm_f26_ndjfma1_p =  projectRaster(rcm_f26_ndjfma1, crs=wgs84)
# 
# 
# rcm_f26_mjj1_p1 = mask(rcm_f26_mjj1_p, basin)
# rcm_f26_aso1_p1 = mask(rcm_f26_aso1_p, basin)
# rcm_f26_ndjfma1_p1 = mask(rcm_f26_ndjfma1_p, basin)
# 
# rcm_f85_mjj1_p = projectRaster(rcm_f85_mjj1, crs=wgs84)
# rcm_f85_aso1_p =  projectRaster(rcm_f85_aso1, crs=wgs84)
# rcm_f85_ndjfma1_p =  projectRaster(rcm_f85_ndjfma1, crs=wgs84)
# 
# 
# rcm_f85_mjj1_p1 = mask(rcm_f85_mjj1_p, basin)
# rcm_f85_aso1_p1 = mask(rcm_f85_aso1_p, basin)
# rcm_f85_ndjfma1_p1 = mask(rcm_f85_ndjfma1_p, basin)
# 
# 
# 
# ap_mjj1_p = projectRaster(ap_mjj1, crs=wgs84)
# ap_aso1_p =  projectRaster(ap_aso1, crs=wgs84)
# ap_ndjfma1_p =  projectRaster(ap_ndjfma1, crs=wgs84)
# 
# 
# ap_mjj1_p1 = mask(ap_mjj1_p, basin)
# ap_aso1_p1 = mask(ap_aso1_p, basin)
# ap_ndjfma1_p1 = mask(ap_ndjfma1_p, basin)
# plot(ap_aso1_p1)
# # extent(ap_ndjfma1_p1)=extent(basin)

#------
# s1_rcm1_ssp1_all_pc = ((s1_rcm1_ssp1_all1-ap_all1)/ap_all1)*100
# s1_rcm1_ssp2_all_pc = ((s1_rcm1_ssp2_all1-ap_all1)/ap_all1)*100
# 
# 
# s1_rcm1_ssp1_n_mjj1_pc = ((s1_rcm1_ssp1_n_mjj1-ap_mjj1)/ap_mjj1)*100
# s1_rcm1_ssp1_n_aso1_pc = ((s1_rcm1_ssp1_n_aso1-ap_aso1)/ap_aso1)*100
# s1_rcm1_ssp1_n_ndjfma1_pc = ((s1_rcm1_ssp1_n_ndjfma1-ap_ndjfma1)/ap_ndjfma1)*100
# s1_rcm1_ssp1_n_all1_pc = ((s1_rcm1_ssp1_n_all1-ap_all1)/ap_all1)*100
# 
# 
# s1_rcm1_ssp2_n_mjj1_pc = ((s1_rcm1_ssp2_n_mjj1-ap_mjj1)/ap_mjj1)*100
# s1_rcm1_ssp2_n_aso1_pc = ((s1_rcm1_ssp2_n_aso1-ap_aso1)/ap_aso1)*100
# s1_rcm1_ssp2_n_ndjfma1_pc = ((s1_rcm1_ssp2_n_ndjfma1-ap_ndjfma1)/ap_ndjfma1)*100
# s1_rcm1_ssp2_n_all1_pc = ((s1_rcm1_ssp2_n_all1-ap_all1)/ap_all1)*100
# 
# s1_rcm1_ssp1_m_mjj1_pc = ((s1_rcm1_ssp1_m_mjj1-ap_mjj1)/ap_mjj1)*100
# s1_rcm1_ssp1_m_aso1_pc = ((s1_rcm1_ssp1_m_aso1-ap_aso1)/ap_aso1)*100
# s1_rcm1_ssp1_m_ndjfma1_pc = ((s1_rcm1_ssp1_m_ndjfma1-ap_ndjfma1)/ap_ndjfma1)*100
# s1_rcm1_ssp1_m_all1_pc = ((s1_rcm1_ssp1_m_all1-ap_all1)/ap_all1)*100
# 
# s1_rcm1_ssp2_m_mjj1_pc = ((s1_rcm1_ssp2_m_mjj1-ap_mjj1)/ap_mjj1)*100
# s1_rcm1_ssp2_m_aso1_pc = ((s1_rcm1_ssp2_m_aso1-ap_aso1)/ap_aso1)*100
# s1_rcm1_ssp2_m_ndjfma1_pc = ((s1_rcm1_ssp2_m_ndjfma1-ap_ndjfma1)/ap_ndjfma1)*100
# s1_rcm1_ssp2_m_all1_pc = ((s1_rcm1_ssp2_m_all1-ap_all1)/ap_all1)*100
# 
# 
# s1_rcm1_ssp1_f_mjj1_pc = ((s1_rcm1_ssp1_f_mjj1-ap_mjj1)/ap_mjj1)*100
# s1_rcm1_ssp1_f_aso1_pc = ((s1_rcm1_ssp1_f_aso1-ap_aso1)/ap_aso1)*100
# s1_rcm1_ssp1_f_ndjfma1_pc = ((s1_rcm1_ssp1_f_ndjfma1-ap_ndjfma1)/ap_ndjfma1)*100
# s1_rcm1_ssp1_f_all1_pc = ((s1_rcm1_ssp1_f_all1-ap_all1)/ap_all1)*100
# 
# s1_rcm1_ssp2_f_mjj1_pc = ((s1_rcm1_ssp2_f_mjj1-ap_mjj1)/ap_mjj1)*100
# s1_rcm1_ssp2_f_aso1_pc = ((s1_rcm1_ssp2_f_aso1-ap_aso1)/ap_aso1)*100
# s1_rcm1_ssp2_f_ndjfma1_pc = ((s1_rcm1_ssp2_f_ndjfma1-ap_ndjfma1)/ap_ndjfma1)*100
# s1_rcm1_ssp2_f_all1_pc = ((s1_rcm1_ssp2_f_all1-ap_all1)/ap_all1)*100
# 
# plot(s1_rcm1_ssp1_n_mjj1_pc)
# plot(s1_rcm1_ssp2_n_mjj1_pc)

# f85_mjj1_pc = ((rcm_f85_mjj1_p1-ap_mjj1_p1)/ap_mjj1_p1)*100
# f85_aso1_pc = ((rcm_f85_aso1_p1-ap_aso1_p1)/ap_aso1_p1)*100
# f85_ndjfma1_pc = ((rcm_f85_ndjfma1_p1-ap_ndjfma1_p1)/ap_ndjfma1_p1)*100
#-----

tws_d_mjj1 <- rasterToPoints(tws_d_mjj)
#Make the points a dataframe for ggplot
df <- data.frame(tws_d_mjj1)
tws_d_mjj1_df = df
#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
tws_d_mjj1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  # geom_contour()+
  
  # geom_sf(data = basin_p)+
  ggtitle("MJJ") +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'Precipitation\n(mm)')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  # scale_colour_gradient(low = "yellow", high = "red", na.value = NA)
  scale_fill_gradientn(colours = rainbow(50), limits=c(-3,3))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank()
  )
tws_d_mjj1



p4 <- "F:/OneDrive/AIT/papers/rainfall_biascorrection/data/cmip6_gcm/monthly/MIROC6/pr_hist/"
R4 <- list.files(p4, pattern = "nc$")

gcm3_rain_hist <- raster::stack(file.path(p4, R4), varname = "pr")
gcm3_rain_hist_c <- crop(gcm3_rain_hist,basin_p)

p5 <- "F:/OneDrive/AIT/papers/rainfall_biascorrection/data/cmip6_gcm/monthly/MRI-ESM2-0/pr_hist/"
R5 <- list.files(p5, pattern = "nc$")

gcm4_rain_hist <- raster::stack(file.path(p5, R5), varname = "pr")
gcm4_rain_hist_c <- crop(gcm4_rain_hist,basin_p)

# ncpath <- "C:/Users/WEM/OneDrive/AIT/papers/rainfall_biascorrection/data/aphrodite"
# ncname <- "APHRO_MA_025deg_V1101.1951-2007.nc.gz"  
# ncfname <- paste(ncpath, ncname, ".nc", sep="")
#observation
#dem
dem = raster('C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/data/cmip6_gcm/dem/elev.0.25-deg.nc')


dem_c <- crop(dem,basin_p10)
dem_m = mask(dem_c, basin_p10)

plot(dem_c)
plot(basin_p10, add=T)
# 
# s1_crop <- crop(ap_rain,basin_p)
# 
# s1_ap = s1_crop[[6941:20089]]
# #1970-1989#
# s1_ap_c = s1_crop[[6941:14245]]
# #1990-2005
# s1_ap_v =s1_crop[[14246:20089]]
# 
# # s1_ap_v = s1_ap[[7671:13149]]
# # plot(s1_ap[[1]],add=T)
# #1970-2005
# s1_gcm1 = gcm1_rain_hist_c[[1441:1872]]*86400*30
# s1_gcm2 = gcm2_rain_hist_c[[241:672]]*86400*30
# s1_gcm3 = gcm3_rain_hist_c[[241:672]]*86400*30
# s1_gcm4 = gcm4_rain_hist_c[[1441:1872]]*86400*30
# 
# plot(s1_gcm1[[1]])
# 
# #converting aphro to month
# #ap analysis #monthly stacks
# s1_ap1 = s1_ap
# 
# plot(s1_ap1[[1]])
# 
# #get the date from the names of the layers and extract the month
# idx_1_a <- seq(as.Date('1970-01-01'), as.Date('2005-12-31'), 'day')
# idx_2_a <- seq(as.Date('1970-01-01'), as.Date('2005-12-31'), 'month')
# idx_3_a <- seq(1,12)
# 
# names(s1_ap1)=idx_1_a
# 
# indices_a <- format(as.Date(names(s1_ap1), format = "X%Y.%m.%d"), format = "%y.%m")
# indices_a <- as.numeric(indices_a)
# 
# #sum layers
# month_ap<- stackApply(s1_ap1, indices_a, fun = sum)
# names(month_ap) <- idx_2_a
# 
# #mean_month
# indices1_a <- format(as.Date(names(month_ap), format = "X%Y.%m.%d"), format = "%m")
# indices1_a <- as.numeric(indices1_a)
# 
# month_ap1<- stackApply(month_ap, indices1_a, fun = mean)
# names(month_ap1) = idx_3_a
# 
# indices2_a = names(month_ap1)
# # indices2 = as.numeric(indices2)
# 
# #yearly rainfall
# year_ap = sum(month_ap1)
# 
# #RESAMPLE
# 
# # month_rcm_f26_r = list();
# 
# 
# 
# # month_ap_c_p1 = crop(month_ap_r,basin_p3)
# # 
# # s1_gcm1_c_p1 = crop(s1_gcm1,basin_p3)
# 

dem_c_p1 <- crop(dem,basin_p10)
dem_m_p1 = mask(dem_c_p1, basin_p10)

plot(dem_m_p1)
# month_gcm1_resam_p1 =list();
# month_ap_resam_p1 = list();

# for (i in 1:432){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   month_ap_resam_p1[[i]] = resample(month_ap_c_p1[[i]],dem_c_p1,'bilinear')
#   month_gcm1_resam_p1[[i]] = resample(s1_gcm1_c_p1[[i]],dem_c_p1,'bilinear')
# }

# month_rcm_f85_r = list()
# for (i in 1:360){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   month_rcm_f85_r[[i]] = resample(month_rcm_f85[[i]],r3,'bilinear')
# }

# for (i in 1:432){
#   #241:432
#   print(i)
#   month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
# }

# month_ap_resam1_p1 = stack(month_ap_resam_p1)
# month_gcm1_resam1_p1 = stack(month_gcm1_resam_p1)
# # month_rcm_f26_r = stack(month_rcm_f26_r)
# # month_rcm_f85_r = stack(month_rcm_f85_r)
# 
# save(month_ap_r, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_5_month_ap_r.RData")
# # # Save multiple objects
# # save(data1, data2, file = "data.RData")
# # # To load the data again
# # load("data.RData")
# 
# 
# # focal analsyis and laprserate--------------------------------------------------
# yy = (month_ap_resam1_p1)
# xx = (month_gcm1_resam1_p1)

# plot(sch_5[[1]])
w=c(5,5)
# sch_5_p1[[1]]
# month_ap_r = sch_5_p1[[1:432]]
# month_ap_c_p1 = crop(month_ap_r,basin_p1)
# 
# plot(basin_p1)
# plot(basin_p2, add=T)
# plot(basin_p4)

# gcm1_rain_hist_c1 = gcm1_rain_hist_c[[1441:1872]]
# 
# yy = sch_5_p1[[1:432]]

s1_gcm1 = gcm1_rain_hist[[1441:1872]]*86400*30
# s1_gcm2 = gcm2_rain_hist_c[[241:672]]*86400*30
# s1_gcm3 = gcm3_rain_hist_c[[241:672]]*86400*30
# s1_gcm4 = gcm4_rain_hist_c[[1441:1872]]*86400*30

# s1_gcm1_c <- crop(s1_gcm1,basin_p1)
# s1_gcm1_c <- mask(s1_gcm1_c,basin_p1)
month_ap_r1 = sch_5_p1[[1:432]]
month_ap_r2 = sch_5_p2[[1:432]]
month_ap_r <- mosaic(month_ap_r1, month_ap_r2, fun=min)

# month_ap_c_p1 = crop(month_ap_r,basin_p1)
# month_ap_c_p1 = mask(month_ap_c_p1,basin_p1)



# plot(month_ap_r[[432]])
# plot(basin_p1, add=T)

month_gcm1_r_p1 =list();
month_ap_r_p1 = list();
month_gcm1_r_p1_bi = list();
# dem_m1_p1= list();
# plot(month_ap_c_p1[[1]])
for (i in 1:432){
  #241:432
  print(i)
  # dem_m1_p1[[i]]=resample(dem_m_p1,dem_m_p1,'bilinear')
  month_ap_r_p1[[i]] = resample(month_ap_r[[i]],dem_m_p1,'bilinear')
  month_gcm1_r_p1[[i]] = resample(s1_gcm1[[i]],dem_m_p1,'ngb')
  month_gcm1_r_p1_bi[[i]] = resample(s1_gcm1[[i]],dem_m_p1,'bilinear')
  
}
plot(dem_m_p1)

dem_m1_p1 = stack(replicate(432,dem_m_p1))
# yy = sch_5_p1[[1:432]]
# xx = sch_5_p1[[433:864]]
# # xx = sch_5_p1[[865:1296]]
# 
# yy_p3 = crop(yy,basin_p1)
# xx_p3 = crop(xx,basin_p1)
# 
yy_p3 = list()
xx_p3 = list()
yy_p3 = stack(month_ap_r_p1)
xx_p3 = stack(month_gcm1_r_p1)
xx_p3_bi = stack(month_gcm1_r_p1_bi)
# dem_m1_p1 = stack(dem_m1_p1)

plot(yy_p3[[1]])
plot(xx_p3_bi[[1]])
plot(xx_p3[[1]])

# ap_w = crop(yy_p3[[7]], fishnet1)
# 
# gcm_w = crop(xx_p3_bi[[7]], fishnet1)
# 
# dem_w = crop(dem_m1_p1[[7]], fishnet1)
# 
# plot(dem_w)
# plot(fishnet1, add=T)
# 
# ap_w1 <- rasterToPoints(ap_w)
# #Make the points a dataframe for ggplot
# df_ap_w1 <- data.frame(ap_w1)
# 
# gcm_w1 <- rasterToPoints(gcm_w)
# #Make the points a dataframe for ggplot
# df_gcm_w1 <- data.frame(gcm_w1)
# 
# dem_w1 <- rasterToPoints(dem_w)
# #Make the points a dataframe for ggplot
# df_dem_w1 <- data.frame(dem_w1)
# 
# data1 = data.frame(df_dem_w1[,3],df_ap_w1[,3])
# data2 = data.frame(df_dem_w1[,3],df_gcm_w1[,3])
# 
# fit_ap<-lm(data1[,2] ~ data1[,1])
# fit_gcm<-lm(data2[,2] ~ data2[,1])
# 
# ap_slope = fit_ap$coefficients[2]
# gcm_slope = fit_gcm$coefficients[2]


# yy_p3_s = yy_p3[[1:180]]

#biascorrection

jun = seq(6, 240, 12)
jul = seq(7, 240, 12)
aug = seq(8, 240, 12)
sep = seq(9, 240, 12)
jan = seq(1, 240, 12)
oct = seq(10, 240, 12)
nov = seq(11, 240, 12)
dec = seq(12, 240, 12)
feb = seq(2, 240, 12)
mar = seq(3, 240, 12)
apl = seq(4, 240, 12)
may = seq(5, 240, 12)

# m_seq = seq(1, 360, 36)
# 
# jun2 = seq(6, 360, 12)
# jul2 = seq(7, 360, 12)
# aug2 = seq(8, 360, 12)
# sep2 = seq(9, 360, 12)
# oct2 = seq(10, 360, 12)
# nov2 = seq(11, 360, 12)
# dec2 = seq(12, 360, 12)
# jan2 = seq(1, 360, 12)
# feb2 = seq(2, 360, 12)
# mar2 = seq(3, 360, 12)
# apl2 = seq(4, 360, 12)
# may2 = seq(5, 360, 12)
# 
# xx_p3_jan = xx_p3_bi[[jan]]
# xx_p3_feb = xx_p3_bi[[feb]]
# xx_p3_mar = xx_p3_bi[[mar]]
# xx_p3_apl = xx_p3_bi[[apl]]
# xx_p3_may = xx_p3_bi[[may]]
# xx_p3_jun = xx_p3_bi[[jun]]
# xx_p3_jul = xx_p3_bi[[jul]]
# xx_p3_aug = xx_p3_bi[[aug]]
# xx_p3_sep = xx_p3_bi[[sep]]
# xx_p3_oct = xx_p3_bi[[oct]]
# xx_p3_nov = xx_p3_bi[[nov]]
# xx_p3_dec = xx_p3_bi[[dec]]
# 
# xx_p3_jan1 <- calc(xx_p3_jan, fun = mean)
# xx_p3_feb1 <- calc(xx_p3_feb, fun = mean)
# xx_p3_mar1 <- calc(xx_p3_mar, fun = mean)
# xx_p3_apl1 <- calc(xx_p3_apl, fun = mean)
# xx_p3_may1 <- calc(xx_p3_may, fun = mean)
# xx_p3_jun1 <- calc(xx_p3_jun, fun = mean)
# xx_p3_jul1 <- calc(xx_p3_jul, fun = mean)
# xx_p3_aug1 <- calc(xx_p3_aug, fun = mean)
# xx_p3_sep1 <- calc(xx_p3_sep, fun = mean)
# xx_p3_oct1 <- calc(xx_p3_oct, fun = mean)
# xx_p3_nov1 <- calc(xx_p3_nov, fun = mean)
# xx_p3_dec1 <- calc(xx_p3_dec, fun = mean)
# 
# #----------------
# yy_p3_jan = yy_p3[[jan]]
# yy_p3_feb = yy_p3[[feb]]
# yy_p3_mar = yy_p3[[mar]]
# yy_p3_apl = yy_p3[[apl]]
# yy_p3_may = yy_p3[[may]]
# yy_p3_jun = yy_p3[[jun]]
# yy_p3_jul = yy_p3[[jul]]
# yy_p3_aug = yy_p3[[aug]]
# yy_p3_sep = yy_p3[[sep]]
# yy_p3_oct = yy_p3[[oct]]
# yy_p3_nov = yy_p3[[nov]]
# yy_p3_dec = yy_p3[[dec]]
# 
# yy_p3_jan1 <- calc(yy_p3_jan, fun = mean)
# yy_p3_feb1 <- calc(yy_p3_feb, fun = mean)
# yy_p3_mar1 <- calc(yy_p3_mar, fun = mean)
# yy_p3_apl1 <- calc(yy_p3_apl, fun = mean)
# yy_p3_may1 <- calc(yy_p3_may, fun = mean)
# yy_p3_jun1 <- calc(yy_p3_jun, fun = mean)
# yy_p3_jul1 <- calc(yy_p3_jul, fun = mean)
# yy_p3_aug1 <- calc(yy_p3_aug, fun = mean)
# yy_p3_sep1 <- calc(yy_p3_sep, fun = mean)
# yy_p3_oct1 <- calc(yy_p3_oct, fun = mean)
# yy_p3_nov1 <- calc(yy_p3_nov, fun = mean)
# yy_p3_dec1 <- calc(yy_p3_dec, fun = mean)
# 
# #------------
# 
# ls_jan = yy_p3_jan1/xx_p3_jan1
# ls_feb = yy_p3_feb1/xx_p3_feb1
# ls_mar = yy_p3_mar1/xx_p3_mar1
# ls_apl = yy_p3_apl1/xx_p3_apl1
# ls_may = yy_p3_may1/xx_p3_may1
# ls_jun = yy_p3_jun1/xx_p3_jun1
# ls_jul = yy_p3_jul1/xx_p3_jul1
# ls_aug = yy_p3_aug1/xx_p3_aug1
# ls_sep = yy_p3_sep1/xx_p3_sep1
# ls_oct = yy_p3_oct1/xx_p3_oct1
# ls_nov = yy_p3_nov1/xx_p3_nov1
# ls_dec = yy_p3_dec1/xx_p3_dec1
# 
# xx_p3_bias = list();
# plot(ls_dec)
# for (i in 1:432){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
#   if(i%%12 == 1){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_jan
#     
#   } else if(i%%12 == 2){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_feb
#     
#   } else if(i%%12 == 3){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_mar
#     
#   } else if(i%%12 == 4){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_apl
#     
#   } else if(i%%12 == 5){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_may
#     
#   } else if(i%%12 == 6){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_jun
#     
#   } else if(i%%12 == 7){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_jul
#     
#   } else if(i%%12 == 8){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_aug
#     
#   } else if(i%%12 == 9){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_sep
#     
#   } else if(i%%12 == 10){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_oct
#     
#   } else if(i%%12 == 11){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_nov
#     
#   } else if(i%%12 == 0){
#     xx_p3_bias[[i]] = xx_p3_bi[[i]] * ls_dec
#     
#   }  else {
#     NULL
#   }
#   
# }

xx_p3_bias = list()
xx_p3_bias = stack(xx_p3_bi)


plot(xx_p3[[1]])

plot(xx_p3[[1]])
plot(yy_p3[[1]])
plot((yy_p3[[1]]-xx_p3[[1]]))
plot((yy_p3[[1]]-xx_p3_bias[[1]]))


# plot(ls_dec)
# 
# st_lr2 = stack(st_lr1_jan1,st_lr1_feb1,st_lr1_mar1,st_lr1_apl1,
#                st_lr1_may1,st_lr1_jun1,st_lr1_jul1,st_lr1_aug1,
#                st_lr1_sep1,st_lr1_oct1,st_lr1_nov1,st_lr1_dec1)
# 
# 
# y <- overlay(s, s, fun=function(x, y) { sqrt(x^2 + y^2) } )

# #memory allocation
# if(.Platform$OS.type == "windows") withAutoprint({
#   memory.size()
#   memory.size(TRUE)
#   memory.limit()
# })
# memory.limit(size=56000)
# 
# gc()

# plot(xx[[3]])
# xx = sch_5_p1[[433:864]]
#focal extract
# vxx <- getValuesFocal(xx, 1, nrow(xx), ngb=w, na.rm=T, pad =T)
vyy <- getValuesFocal(yy_p3, 1, nrow(yy_p3), ngb=w, na.rm =T, pad =F)
vzz <- getValuesFocal(dem_m1_p1, 1, nrow(dem_m1_p1), ngb=w, na.rm =T, pad =F)
vxx <- getValuesFocal(xx_p3_bias, 1, nrow(xx_p3_bias), ngb=w, na.rm =T, pad =F)

plot(xx_p3_bias[[1]])

#seperating neighbour pixels
# vyy_ex1 <- lapply(vyy,"[",1:1512,2)
# # vxx_ex20 <- lapply(vxx,"[",1:1512,20)
# # vxx_ex10 <- lapply(vxx,"[",1:1512,10)
# vzz_ex1 <- lapply(vzz,"[",1:1512,1)
# 
# # vv1 = as.matrix(vxx_ex1[[1]])
# # vv1
# # vall = cbind(vxx_ex1,vxx_ex2,vxx_ex3,vyy_ex1)
# 
# st_ras = raster(ncol=27, nrow = 56)

x = xx_p3_bias[[1]]
# plot(basin_p7, add=T)
plot(x)
ncell = getValues(x)
ncell1 = length(ncell)
x
ncell1

f_y1 =list()
f_z1 = list()
f_fit1 = list()
f_fit = list()
# f_fit[[1:2]] <- raster(x)
# test_ras=list()
# 
# extent(x)=extent(r3)
# crs(x) = crs(r3)
fit =rep(NA,nrow(vxx[[1]]))
for (j in 1:432){
  fit =rep(NA,nrow(vxx[[1]]))
  for (k in 1:ncell1){
    y1 = vyy[[j]][k,]
    x1 = vzz[[j]][k,]
    xy = na.omit(data.frame(x = x1, y =y1))
    if (nrow(xy)>4){
      fit[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
    }
    else{
      fit[k] = NA
    }
  }
  f_fit[[j]] <- raster(x)
  values(f_fit[[j]])=fit
  print(j)
}


fit1 =rep(NA,nrow(vxx[[1]]))
for (j in 1:432){
  fit1 =rep(NA,nrow(vxx[[1]]))
  for (k in 1:ncell1){
    y1 = vxx[[j]][k,]
    x1 = vzz[[j]][k,]
    xy = na.omit(data.frame(x = x1, y =y1))
    if (nrow(xy)>4){
      fit1[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
    }
    else{
      fit1[k] = NA
    }
  }
  f_fit1[[j]] <- raster(x)
  values(f_fit1[[j]])=fit1
  print(j)
}

plot(f_fit[[1]])
plot(f_fit1[[1]])
st_lr1_p3_n1_y = stack(f_fit)
st_lr1_p3_n1_x = stack(f_fit1)

# 
# lr_ap_w = crop(st_lr1_p3_n1_y[[7]], fishnet1)
# lr_gcm_w = crop(st_lr1_p3_n1_x[[7]], fishnet1)
# plot(lr_ap_w)
# plot(lr_gcm_w)

#lapse rate cal
lp_y_jan = st_lr1_p3_n1_y[[jan]]
lp_y_feb = st_lr1_p3_n1_y[[feb]]
lp_y_mar = st_lr1_p3_n1_y[[mar]]
lp_y_apl = st_lr1_p3_n1_y[[apl]]
lp_y_may = st_lr1_p3_n1_y[[may]]
lp_y_jun = st_lr1_p3_n1_y[[jun]]
lp_y_jul = st_lr1_p3_n1_y[[jul]]
lp_y_aug = st_lr1_p3_n1_y[[aug]]
lp_y_sep = st_lr1_p3_n1_y[[sep]]
lp_y_oct = st_lr1_p3_n1_y[[oct]]
lp_y_nov = st_lr1_p3_n1_y[[nov]]
lp_y_dec = st_lr1_p3_n1_y[[dec]]

lp_y_jan1 <- calc(lp_y_jan, fun = sd)
lp_y_feb1 <- calc(lp_y_feb, fun = sd)
lp_y_mar1 <- calc(lp_y_mar, fun = sd)
lp_y_apl1 <- calc(lp_y_apl, fun = sd)
lp_y_may1 <- calc(lp_y_may, fun = sd)
lp_y_jun1 <- calc(lp_y_jun, fun = sd)
lp_y_jul1 <- calc(lp_y_jul, fun = sd)
lp_y_aug1 <- calc(lp_y_aug, fun = sd)
lp_y_sep1 <- calc(lp_y_sep, fun = sd)
lp_y_oct1 <- calc(lp_y_oct, fun = sd)
lp_y_nov1 <- calc(lp_y_nov, fun = sd)
lp_y_dec1 <- calc(lp_y_dec, fun = sd)

lp_x_jan = st_lr1_p3_n1_x[[jan]]
lp_x_feb = st_lr1_p3_n1_x[[feb]]
lp_x_mar = st_lr1_p3_n1_x[[mar]]
lp_x_apl = st_lr1_p3_n1_x[[apl]]
lp_x_may = st_lr1_p3_n1_x[[may]]
lp_x_jun = st_lr1_p3_n1_x[[jun]]
lp_x_jul = st_lr1_p3_n1_x[[jul]]
lp_x_aug = st_lr1_p3_n1_x[[aug]]
lp_x_sep = st_lr1_p3_n1_x[[sep]]
lp_x_oct = st_lr1_p3_n1_x[[oct]]
lp_x_nov = st_lr1_p3_n1_x[[nov]]
lp_x_dec = st_lr1_p3_n1_x[[dec]]

lp_x_jan1 <- calc(lp_x_jan, fun = sd)
lp_x_feb1 <- calc(lp_x_feb, fun = sd)
lp_x_mar1 <- calc(lp_x_mar, fun = sd)
lp_x_apl1 <- calc(lp_x_apl, fun = sd)
lp_x_may1 <- calc(lp_x_may, fun = sd)
lp_x_jun1 <- calc(lp_x_jun, fun = sd)
lp_x_jul1 <- calc(lp_x_jul, fun = sd)
lp_x_aug1 <- calc(lp_x_aug, fun = sd)
lp_x_sep1 <- calc(lp_x_sep, fun = sd)
lp_x_oct1 <- calc(lp_x_oct, fun = sd)
lp_x_nov1 <- calc(lp_x_nov, fun = sd)
lp_x_dec1 <- calc(lp_x_dec, fun = sd)



jan_lr = lp_y_jan1/lp_x_jan1
feb_lr = lp_y_feb1/lp_x_feb1
mar_lr = lp_y_mar1/lp_x_mar1
apl_lr = lp_y_apl1/lp_x_apl1
may_lr = lp_y_may1/lp_x_may1
jun_lr = lp_y_jun1/lp_x_jun1
jul_lr = lp_y_jul1/lp_x_jul1
aug_lr = lp_y_aug1/lp_x_aug1
sep_lr = lp_y_sep1/lp_x_sep1
oct_lr = lp_y_oct1/lp_x_oct1
nov_lr = lp_y_nov1/lp_x_nov1
dec_lr = lp_y_dec1/lp_x_dec1

plot(lp_x_jan[[2]])


xx_p3_lr = list();
plot(lp_y_jan1/lp_x_jan1)
# plot(basin_p8, add=T)

for (i in 1:432){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  
  if(i%%12 == 1){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_jan1/lp_x_jan1)
    
  } else if(i%%12 == 2){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_feb1/lp_x_feb1)
    
  } else if(i%%12 == 3){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_mar1/lp_x_mar1)
    
  } else if(i%%12 == 4){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_apl1/lp_x_apl1)
    
  } else if(i%%12 == 5){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_may1/lp_x_may1)
    
  } else if(i%%12 == 6){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_jun1/lp_x_jun1)
    
  } else if(i%%12 == 7){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_jul1/lp_x_jul1)
    
  } else if(i%%12 == 8){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_aug1/lp_x_aug1)
    
  } else if(i%%12 == 9){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_sep1/lp_x_sep1)
    
  } else if(i%%12 == 10){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_oct1/lp_x_oct1)
    
  } else if(i%%12 == 11){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_nov1/lp_x_nov1)
    
  } else if(i%%12 == 0){
    xx_p3_lr[[i]] = xx_p3_bias[[i]] * (lp_y_dec1/lp_x_dec1)
    
  }  else {
    NULL
  }
  
}

xx_p3_lr = stack(xx_p3_lr)

lp_y_jan1_m <- calc(lp_y_jan, fun = mean)
lp_y_feb1_m <- calc(lp_y_feb, fun = mean)
lp_y_mar1_m <- calc(lp_y_mar, fun = mean)
lp_y_apl1_m <- calc(lp_y_apl, fun = mean)
lp_y_may1_m <- calc(lp_y_may, fun = mean)
lp_y_jun1_m <- calc(lp_y_jun, fun = mean)
lp_y_jul1_m <- calc(lp_y_jul, fun = mean)
lp_y_aug1_m <- calc(lp_y_aug, fun = mean)
lp_y_sep1_m <- calc(lp_y_sep, fun = mean)
lp_y_oct1_m <- calc(lp_y_oct, fun = mean)
lp_y_nov1_m <- calc(lp_y_nov, fun = mean)
lp_y_dec1_m <- calc(lp_y_dec, fun = mean)

lp_x_jan1_m <- calc(lp_x_jan, fun = mean)
lp_x_feb1_m <- calc(lp_x_feb, fun = mean)
lp_x_mar1_m <- calc(lp_x_mar, fun = mean)
lp_x_apl1_m <- calc(lp_x_apl, fun = mean)
lp_x_may1_m <- calc(lp_x_may, fun = mean)
lp_x_jun1_m <- calc(lp_x_jun, fun = mean)
lp_x_jul1_m <- calc(lp_x_jul, fun = mean)
lp_x_aug1_m <- calc(lp_x_aug, fun = mean)
lp_x_sep1_m <- calc(lp_x_sep, fun = mean)
lp_x_oct1_m <- calc(lp_x_oct, fun = mean)
lp_x_nov1_m <- calc(lp_x_nov, fun = mean)
lp_x_dec1_m <- calc(lp_x_dec, fun = mean)


lr_y_m_p10 = stack(lp_y_jan1_m,lp_y_feb1_m,lp_y_mar1_m,lp_y_apl1_m,
                  lp_y_may1_m,lp_y_jun1_m,lp_y_jul1_m,lp_y_aug1_m,
                  lp_y_sep1_m,lp_y_oct1_m,lp_y_nov1_m,lp_y_dec1_m)

lr_x_m_p10 = stack(lp_x_jan1_m,lp_x_feb1_m,lp_x_mar1_m,lp_x_apl1_m,
                  lp_x_may1_m,lp_x_jun1_m,lp_x_jul1_m,lp_x_aug1_m,
                  lp_x_sep1_m,lp_x_oct1_m,lp_x_nov1_m,lp_x_dec1_m)

lr_rain_p10 = xx_p3_lr

# save(param3p_p2_n2, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/param_3p_p2_n2.RData")
save(lr_y_m_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_y_m_p10.RData")
save(lr_x_m_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_x_m_p10.RData")
save(lr_rain_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_rain_p10.RData")



# for (i in 1:432){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
#   if(i%%12 == 1){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_jan1/lp_x_jan1)
#     
#   } else if(i%%12 == 2){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_feb1/lp_x_feb1)
#     
#   } else if(i%%12 == 3){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_mar1/lp_x_mar1)
#     
#   } else if(i%%12 == 4){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_apl1/lp_x_apl1)
#     
#   } else if(i%%12 == 5){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_may1/lp_x_may1)
#     
#   } else if(i%%12 == 6){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_jun1/lp_x_jun1)
#     
#   } else if(i%%12 == 7){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_jul1/lp_x_jul1)
#     
#   } else if(i%%12 == 8){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_aug1/lp_x_aug1)
#     
#   } else if(i%%12 == 9){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_sep1/lp_x_sep1)
#     
#   } else if(i%%12 == 10){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_oct1/lp_x_oct1)
#     
#   } else if(i%%12 == 11){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_nov1/lp_x_nov1)
#     
#   } else if(i%%12 == 0){
#     xx_p3_lr[[i]] = xx_p3[[i]] * (lp_y_dec1/lp_x_dec1)
#     
#   }  else {
#     NULL
#   }
#   
# }



plot(xx_p3_lr[[1]])
# st_lr1_n2 = st_lr1_n1*100

# setwd("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment")

ratio= xx_p3_lr

plot(ratio[[5]])
# sch_5_p1_n1 = stack(yy_p3,xx_p3_bias,ratio)
# 
# 
# yy_p3 = sch_5_p1_n1[[1:432]]
# xx_p3_bias = sch_5_p1_n1[[433:864]]
# plot(yy_p3[[1]])
# 
# save(sch_5,'F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4.RData')
# save(sch_5_p1_n1, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5_p1_n1.RData")


# yy = sch_5[[1:432]]
# yy1 = stack(mask(yy,basin_p1))

# proj4string(s1_gcm_all) <- utm47Q
# extent(s1_gcm_all) = ap_5km


# projection(b) <- "+init=epsg:28992"
# transform to longitude/latitude
# eqcyl = CRS("+init=epsg:4087")
# yy1_p <- projectRaster(yy, crs = eqcyl, method='ngb')
# proj4string(yy) <- eqcyl


# yy_p = spTransform(yy[[1]], eqcyl)

# projection(yy1) <- CRS("+init=epsg:4087")



# xx = sch_5[[433:864]]

# xx1_p <- projectRaster(xx, crs = eqcyl, method='ngb')

# xx1 = stack(mask(xx,basin_p1))

# st_lr1 = sch_5[[865:1296]]
# st_lr1_p <- projectRaster(st_lr1, crs = eqcyl, method='ngb')

# st_lr1_s = stack(mask(st_lr1,basin_p1))

# xx1_p1 = list();
# st_lr1_p1 =list();
# 
# for (i in 1:432){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   xx1_p1[[i]] = resample(xx1_p[[i]],yy1_p[[1]],'bilinear')
#   st_lr1_p1[[i]] = resample(st_lr1_p[[i]],yy1_p[[1]],'bilinear')
# }
# 
# 
# 
# xx1_p2 = stack(xx1_p1)
# st_lr1_p2 = stack(st_lr1_p1)
# yy1_p2 = stack(yy1_p)
# 
# 
# 
# plot(st_lr1_p[[1]])
# 

# s1_gcm_all = s1_gcm1_c[[1:23741]]*86400

#fitting month sequence
# jun = seq(6, 180, 12)
# jul = seq(7, 180, 12)
# aug = seq(8, 180, 12)
# sep = seq(9, 180, 12)
# oct = seq(10, 180, 12)
# nov = seq(11, 180, 12)
# dec = seq(12, 180, 12)
# jan = seq(1, 180, 12)
# feb = seq(2, 180, 12)
# mar = seq(3, 180, 12)
# apl = seq(4, 180, 12)
# may = seq(5, 180, 12)
# 
# m_seq = seq(1, 360, 36)
# 
# jun2 = seq(6, 360, 12)
# jul2 = seq(7, 360, 12)
# aug2 = seq(8, 360, 12)
# sep2 = seq(9, 360, 12)
# oct2 = seq(10, 360, 12)
# nov2 = seq(11, 360, 12)
# dec2 = seq(12, 360, 12)
# jan2 = seq(1, 360, 12)
# feb2 = seq(2, 360, 12)
# mar2 = seq(3, 360, 12)
# apl2 = seq(4, 360, 12)
# may2 = seq(5, 360, 12)

# b_mjj <- c()
# b_aso <- c()
# b_ndjfma <- c()
# for (i in 1:430){
#   if(i%%12 == 5){
#     b_mjj <- c(b_mjj, i)
#     b_mjj <- c(b_mjj, i+1)
#     b_mjj <- c(b_mjj, i+2)
#     
#   } 
#   
# }
# for (i in 1:430){
#   if(i%%12 == 8){
#     b_aso <- c(b_aso, i)
#     b_aso <- c(b_aso, i+1)
#     b_aso <- c(b_aso, i+2)
#   } 
# }
# for (i in 1:428){
#   if(i%%12 == 11){
#     b_ndjfma <- c(b_ndjfma, i)
#     b_ndjfma <- c(b_ndjfma, i+1)
#     b_ndjfma <- c(b_ndjfma, i+2)
#     b_ndjfma <- c(b_ndjfma, i+3)
#     b_ndjfma <- c(b_ndjfma, i+4)
#   } 
# }
# #future
# f_mjj <- c()
# f_aso <- c()
# f_ndjfma <- c()
# for (i in 1:358){
#   if(i%%12 == 5){
#     f_mjj <- c(f_mjj, i)
#     f_mjj <- c(f_mjj, i+1)
#     f_mjj <- c(f_mjj, i+2)
#   } 
# }
# for (i in 1:358){
#   if(i%%12 == 8){
#     f_aso <- c(f_aso, i)
#     f_aso <- c(f_aso, i+1)
#     f_aso <- c(f_aso, i+2)
#   } 
# }
# for (i in 1:356){
#   if(i%%12 == 11){
#     f_ndjfma <- c(f_ndjfma, i)
#     f_ndjfma <- c(f_ndjfma, i+1)
#     f_ndjfma <- c(f_ndjfma, i+2)
#     f_ndjfma <- c(f_ndjfma, i+3)
#     f_ndjfma <- c(f_ndjfma, i+4)
#   } 
# }
# 
# 
# 
# 
# st_lr1_jan = st_lr1[[jan]]
# st_lr1_feb = st_lr1[[feb]]
# st_lr1_mar = st_lr1[[mar]]
# st_lr1_apl = st_lr1[[apl]]
# st_lr1_may = st_lr1[[may]]
# st_lr1_jun = st_lr1[[jun]]
# st_lr1_jul = st_lr1[[jul]]
# st_lr1_aug = st_lr1[[aug]]
# st_lr1_sep = st_lr1[[sep]]
# st_lr1_oct = st_lr1[[oct]]
# st_lr1_nov = st_lr1[[nov]]
# st_lr1_dec = st_lr1[[dec]]
# 
# st_lr1_jan1 <- calc(st_lr1_jan, fun = mean)
# st_lr1_feb1 <- calc(st_lr1_feb, fun = mean)
# st_lr1_mar1 <- calc(st_lr1_mar, fun = mean)
# st_lr1_apl1 <- calc(st_lr1_apl, fun = mean)
# st_lr1_may1 <- calc(st_lr1_may, fun = mean)
# st_lr1_jun1 <- calc(st_lr1_jun, fun = mean)
# st_lr1_jul1 <- calc(st_lr1_jul, fun = mean)
# st_lr1_aug1 <- calc(st_lr1_aug, fun = mean)
# st_lr1_sep1 <- calc(st_lr1_sep, fun = mean)
# st_lr1_oct1 <- calc(st_lr1_oct, fun = mean)
# st_lr1_nov1 <- calc(st_lr1_nov, fun = mean)
# st_lr1_dec1 <- calc(st_lr1_dec, fun = mean)
# 
# st_lr2 = stack(st_lr1_jan1,st_lr1_feb1,st_lr1_mar1,st_lr1_apl1,
#                st_lr1_may1,st_lr1_jun1,st_lr1_jul1,st_lr1_aug1,
#                st_lr1_sep1,st_lr1_oct1,st_lr1_nov1,st_lr1_dec1)
# 
# st_lr3 = stack(replicate(36, st_lr2))
# plot(st_lr3[[2]])
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_feb = stack(replicate(30, st_lr1_feb1))
# st_lr2_mar = stack(replicate(30, st_lr1_mar1))
# st_lr2_apl = stack(replicate(30, st_lr1_apl1))
# st_lr2_may = stack(replicate(30, st_lr1_may1))
# st_lr2_jun = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))
# st_lr2_jan = stack(replicate(30, st_lr1_jan1))


#---functions

# fun2=function(x) { if (is.na(x[1])){ NA } else { cochrane.orcutt(lm(x[1:36] ~ x[37:72]+x[73:108]))$coefficients[2] }}
# fun3 <- function(x) { lm(x ~ v1)$coefficients[2] }
# # x2 <- calc(s, fun)
# fun4 = function(x) { if (is.na(x[1])){ NA } else { m <- lm(x[1:36] ~ x[37:72]+x[73:108]);summary(m)$coefficients[,1]}}
# 
# fun1 <- function(x) { if (is.na(x[1])){ NA }
#   else { lm(x[1:36] ~ x[37:72]+x[73:108])$coefficients[1]}}

nlayers = 20

coeffun <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[21:40]
  x2 <- x[41:60]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1) & !is.na(x2))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(obs[x.nona] ~ x1[x.nona] + x2[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1:3]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}

coeffun_nonl <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[21:40]
  # x2 <- x[73:108]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(obs[x.nona] ~ x1[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1:2]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}


# fun1 <- function(x) { if (is.na(x[1]))
# { NA } 
#   else {model = summary(lm(x[1:36] ~ x[37:72]));model$r.squared}}
# 
# fun2 <- function(x) { model <- summary(lm(x ~ time)); c(model$coefficients[2,1], model$r.squared) }
# x2 <- calc(s, fun2)
#---stacking------------

# c2 = (yy1[[jan]])
# v1 = xx1[[jan]]
# 
# p1 = calc(c2, fun3)
# 
# s2 = stack(yy1_p2[[jan]],xx1_p2[[jan]],st_lr1_p2[[jan]])
# 
# all(is.na(yy1_p2))
# all(is.na(xx1_p2))
# all(is.na(st_lr1_p2))


# sch_jan3 = stack(yy_p3[[jan[1:30]]],xx_p3_bias[[jan[1:30]]],ratio[[jan[1:30]]])
# sch_feb3 = stack(yy_p3[[feb[1:30]]],xx_p3_bias[[feb[1:30]]],ratio[[feb[1:30]]])
# sch_mar3 = stack(yy_p3[[mar[1:30]]],xx_p3_bias[[mar[1:30]]],ratio[[mar[1:30]]])
# sch_apl3 = stack(yy_p3[[apl[1:30]]],xx_p3_bias[[apl[1:30]]],ratio[[apl[1:30]]])
# sch_may3 = stack(yy_p3[[may[1:30]]],xx_p3_bias[[may[1:30]]],ratio[[may[1:30]]])
# sch_jun3 = stack(yy_p3[[jun[1:30]]],xx_p3_bias[[jun[1:30]]],ratio[[jun[1:30]]])
# sch_jul3 = stack(yy_p3[[jul[1:30]]],xx_p3_bias[[jul[1:30]]],ratio[[jul[1:30]]])
# sch_aug3 = stack(yy_p3[[aug[1:30]]],xx_p3_bias[[aug[1:30]]],ratio[[aug[1:30]]])
# sch_sep3 = stack(yy_p3[[sep[1:30]]],xx_p3_bias[[sep[1:30]]],ratio[[sep[1:30]]])
# sch_oct3 = stack(yy_p3[[oct[1:30]]],xx_p3_bias[[oct[1:30]]],ratio[[oct[1:30]]])
# sch_nov3 = stack(yy_p3[[nov[1:30]]],xx_p3_bias[[nov[1:30]]],ratio[[nov[1:30]]])
# sch_dec3 = stack(yy_p3[[dec[1:30]]],xx_p3_bias[[dec[1:30]]],ratio[[dec[1:30]]])


sch_jan3 = stack(yy_p3[[jan[1:20]]],ratio[[jan[1:20]]])
sch_feb3 = stack(yy_p3[[feb[1:20]]],ratio[[feb[1:20]]])
sch_mar3 = stack(yy_p3[[mar[1:20]]],ratio[[mar[1:20]]])
sch_apl3 = stack(yy_p3[[apl[1:20]]],ratio[[apl[1:20]]])
sch_may3 = stack(yy_p3[[may[1:20]]],ratio[[may[1:20]]])
sch_jun3 = stack(yy_p3[[jun[1:20]]],ratio[[jun[1:20]]])
sch_jul3 = stack(yy_p3[[jul[1:20]]],ratio[[jul[1:20]]])
sch_aug3 = stack(yy_p3[[aug[1:20]]],ratio[[aug[1:20]]])
sch_sep3 = stack(yy_p3[[sep[1:20]]],ratio[[sep[1:20]]])
sch_oct3 = stack(yy_p3[[oct[1:20]]],ratio[[oct[1:20]]])
sch_nov3 = stack(yy_p3[[nov[1:20]]],ratio[[nov[1:20]]])
sch_dec3 = stack(yy_p3[[dec[1:20]]],ratio[[dec[1:20]]])


sch_jan3_nonl = stack(yy_p3[[jan[1:20]]],xx_p3_bias[[jan[1:20]]])
sch_feb3_nonl = stack(yy_p3[[feb[1:20]]],xx_p3_bias[[feb[1:20]]])
sch_mar3_nonl = stack(yy_p3[[mar[1:20]]],xx_p3_bias[[mar[1:20]]])
sch_apl3_nonl = stack(yy_p3[[apl[1:20]]],xx_p3_bias[[apl[1:20]]])
sch_may3_nonl = stack(yy_p3[[may[1:20]]],xx_p3_bias[[may[1:20]]])
sch_jun3_nonl = stack(yy_p3[[jun[1:20]]],xx_p3_bias[[jun[1:20]]])
sch_jul3_nonl = stack(yy_p3[[jul[1:20]]],xx_p3_bias[[jul[1:20]]])
sch_aug3_nonl = stack(yy_p3[[aug[1:20]]],xx_p3_bias[[aug[1:20]]])
sch_sep3_nonl = stack(yy_p3[[sep[1:20]]],xx_p3_bias[[sep[1:20]]])
sch_oct3_nonl = stack(yy_p3[[oct[1:20]]],xx_p3_bias[[oct[1:20]]])
sch_nov3_nonl = stack(yy_p3[[nov[1:20]]],xx_p3_bias[[nov[1:20]]])
sch_dec3_nonl = stack(yy_p3[[dec[1:20]]],xx_p3_bias[[dec[1:20]]])


# sch_jan3_nonl = stack(yy_p3[[jan[1:20]]],xx_p3_bias[[jan[1:20]]])
# sch_feb3_nonl = stack(yy_p3[[feb[1:20]]],xx_p3_bias[[feb[1:20]]])
# sch_mar3_nonl = stack(yy_p3[[mar[1:20]]],xx_p3_bias[[mar[1:20]]])
# sch_apl3_nonl = stack(yy_p3[[apl[1:20]]],xx_p3_bias[[apl[1:20]]])
# sch_may3_nonl = stack(yy_p3[[may[1:20]]],xx_p3_bias[[may[1:20]]])
# sch_jun3_nonl = stack(yy_p3[[jun[1:20]]],xx_p3_bias[[jun[1:20]]])
# sch_jul3_nonl = stack(yy_p3[[jul[1:20]]],xx_p3_bias[[jul[1:20]]])
# sch_aug3_nonl = stack(yy_p3[[aug[1:20]]],xx_p3_bias[[aug[1:20]]])
# sch_sep3_nonl = stack(yy_p3[[sep[1:20]]],xx_p3_bias[[sep[1:20]]])
# sch_oct3_nonl = stack(yy_p3[[oct[1:20]]],xx_p3_bias[[oct[1:20]]])
# sch_nov3_nonl = stack(yy_p3[[nov[1:20]]],xx_p3_bias[[nov[1:20]]])
# sch_dec3_nonl = stack(yy_p3[[dec[1:20]]],xx_p3_bias[[dec[1:20]]])

#------------parameter estimation----------
par_jan3 <- calc(sch_jan3, coeffun_nonl)
par_feb3 <- calc(sch_feb3, coeffun_nonl)
par_mar3 <- calc(sch_mar3, coeffun_nonl)
par_apl3 <- calc(sch_apl3, coeffun_nonl)
par_may3 <- calc(sch_may3, coeffun_nonl)
par_jun3 <- calc(sch_jun3, coeffun_nonl)
par_jul3 <- calc(sch_jul3, coeffun_nonl)
par_aug3 <- calc(sch_aug3, coeffun_nonl)
par_sep3 <- calc(sch_sep3, coeffun_nonl)
par_oct3 <- calc(sch_oct3, coeffun_nonl)
par_nov3 <- calc(sch_nov3, coeffun_nonl)
par_dec3 <- calc(sch_dec3, coeffun_nonl)

# par_jan3 <- calc(sch_jan3, coeffun)
# par_feb3 <- calc(sch_feb3, coeffun)
# par_mar3 <- calc(sch_mar3, coeffun)
# par_apl3 <- calc(sch_apl3, coeffun)
# par_may3 <- calc(sch_may3, coeffun)
# par_jun3 <- calc(sch_jun3, coeffun)
# par_jul3 <- calc(sch_jul3, coeffun)
# par_aug3 <- calc(sch_aug3, coeffun)
# par_sep3 <- calc(sch_sep3, coeffun)
# par_oct3 <- calc(sch_oct3, coeffun)
# par_nov3 <- calc(sch_nov3, coeffun)
# par_dec3 <- calc(sch_dec3, coeffun)

par_jan3_nonl <- calc(sch_jan3_nonl, coeffun_nonl)
par_feb3_nonl <- calc(sch_feb3_nonl, coeffun_nonl)
par_mar3_nonl <- calc(sch_mar3_nonl, coeffun_nonl)
par_apl3_nonl <- calc(sch_apl3_nonl, coeffun_nonl)
par_may3_nonl <- calc(sch_may3_nonl, coeffun_nonl)
par_jun3_nonl <- calc(sch_jun3_nonl, coeffun_nonl)
par_jul3_nonl <- calc(sch_jul3_nonl, coeffun_nonl)
par_aug3_nonl <- calc(sch_aug3_nonl, coeffun_nonl)
par_sep3_nonl <- calc(sch_sep3_nonl, coeffun_nonl)
par_oct3_nonl <- calc(sch_oct3_nonl, coeffun_nonl)
par_nov3_nonl <- calc(sch_nov3_nonl, coeffun_nonl)
par_dec3_nonl <- calc(sch_dec3_nonl, coeffun_nonl)
#-----------------
plot(par_jan3_nonl[[2]])

param3p=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
              par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])

param2p=stack(par_jan3_nonl[[1:2]],par_feb3_nonl[[1:2]],par_mar3_nonl[[1:2]],par_apl3_nonl[[1:2]],par_may3_nonl[[1:2]],par_jun3_nonl[[1:2]],
              par_jul3_nonl[[1:2]],par_aug3_nonl[[1:2]],par_sep3_nonl[[1:2]],par_oct3_nonl[[1:2]],par_nov3_nonl[[1:2]],par_dec3_nonl[[1:2]])


# save(par_jan3, par_feb3, par_mar3,
#      par_apl3,par_may3,par_jun3,
#      par_jul3,par_aug3,par_sep3,
#      par_oct3,par_nov3,par_dec3,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1.RData")
# 
# save(par_jan3_nonl, par_feb3_nonl, par_mar3_nonl,
#      par_apl3_nonl,par_may3_nonl,par_jun3_nonl,
#      par_jul3_nonl,par_aug3_nonl,par_sep3_nonl,
#      par_oct3_nonl,par_nov3_nonl,par_dec3_nonl,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1_nonl.RData")
# 

plot(par_jan3[[2]])

# save(sch_5, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_4_sch_5.RData")

# summary_feb <- calc(sch_jan2, fun1, forceapply=TRUE)
# 
# summary_mar <- calc(sch_mar, fun1)
# summary_apl <- calc(sch_apl, fun1)
# 
# summary_jul <- calc(sch_jul, fun1)
# 
# summary_aug <- calc(sch_aug, fun1)
# summary_jan <- calc(sch_jan, fun1)
# summary_feb <- calc(sch_feb, fun1)
# 
# summary_mar <- calc(sch_mar, fun1)
# summary_apl <- calc(sch_apl, fun1)
# 
# summary_jul <- calc(sch_jul, fun1)
# 
# summary_aug <- calc(sch_aug, fun1)
# 
# plot(summary_aug)
# 
# 
# 
# r <- raster(ncols=36, nrows=18)
# r[] <- 1:ncell(r)
# s <- stack(r, r*2, sqrt(r))
# 
# # regression of values in one brick (or stack) with 'time'
# time <- 1:nlayers(s)
# fun <- function(x) { lm(x ~ time)$coefficients[2] }
# x2 <- calc(s, fun)
# To get slope and r.squared, you'd need to adapt the function a little

# fun2 <- function(x) { model <- summary(lm(x ~ time)); c(model$coefficients[2,1], model$r.squared) }
# x2 <- calc(s, fun2)
# 
# #----feb
# 
# rcmv_r = list()
# apv_r = list()
# # lp_r = list()
# rcm_p_nolr =list()
# rcm_f26 =list()
pred_rcm1_3p = list();

# for (i in 1:432){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
# 
#   if(i%%12 == 1){
#     pred_rcm1_3p[[i]] = (par_jan3[[3]] * ratio[[i]])+(par_jan3[[2]] * xx_p3_bias[[i]])+ par_jan3[[1]]
# 
#   } else if(i%%12 == 2){
#     pred_rcm1_3p[[i]] = (par_feb3[[3]] * ratio[[i]])+(par_feb3[[2]] * xx_p3_bias[[i]])+ par_feb3[[1]]
# 
#   } else if(i%%12 == 3){
#     pred_rcm1_3p[[i]] = (par_mar3[[3]] * ratio[[i]])+(par_mar3[[2]] * xx_p3_bias[[i]])+ par_mar3[[1]]
# 
#   } else if(i%%12 == 4){
#     pred_rcm1_3p[[i]] = (par_apl3[[3]] * ratio[[i]])+(par_apl3[[2]] * xx_p3_bias[[i]])+ par_apl3[[1]]
# 
#   } else if(i%%12 == 5){
#     pred_rcm1_3p[[i]] = (par_may3[[3]] * ratio[[i]])+(par_may3[[2]] * xx_p3_bias[[i]])+ par_may3[[1]]
# 
#   } else if(i%%12 == 6){
#     pred_rcm1_3p[[i]] = (par_jun3[[3]] * ratio[[i]])+(par_jun3[[2]] * xx_p3_bias[[i]])+ par_jun3[[1]]
# 
#   } else if(i%%12 == 7){
#     pred_rcm1_3p[[i]] = (par_jul3[[3]] * ratio[[i]])+(par_jul3[[2]] * xx_p3_bias[[i]])+ par_jul3[[1]]
# 
#   } else if(i%%12 == 8){
#     pred_rcm1_3p[[i]] = (par_aug3[[3]] * ratio[[i]])+(par_aug3[[2]] * xx_p3_bias[[i]])+ par_aug3[[1]]
# 
#   } else if(i%%12 == 9){
#     pred_rcm1_3p[[i]] = (par_sep3[[3]] * ratio[[i]])+(par_sep3[[2]] * xx_p3_bias[[i]])+ par_sep3[[1]]
# 
#   } else if(i%%12 == 10){
#     pred_rcm1_3p[[i]] = (par_oct3[[3]] * ratio[[i]])+(par_oct3[[2]] * xx_p3_bias[[i]])+ par_oct3[[1]]
# 
#   } else if(i%%12 == 11){
#     pred_rcm1_3p[[i]] = (par_nov3[[3]] * ratio[[i]])+(par_nov3[[2]] * xx_p3_bias[[i]])+ par_nov3[[1]]
# 
#   } else if(i%%12 == 0){
#     pred_rcm1_3p[[i]] = (par_dec3[[3]] * ratio[[i]])+(par_dec3[[2]] * xx_p3_bias[[i]])+ par_dec3[[1]]
# 
#   }  else {
#     NULL
#   }
# 
# }


for (i in 1:432){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')

  if(i%%12 == 1){
    pred_rcm1_3p[[i]] = (par_jan3[[2]] * ratio[[i]])+ par_jan3[[1]]

  } else if(i%%12 == 2){
    pred_rcm1_3p[[i]] = (par_feb3[[2]] * ratio[[i]])+ par_feb3[[1]]

  } else if(i%%12 == 3){
    pred_rcm1_3p[[i]] = (par_mar3[[2]] * ratio[[i]])+ par_mar3[[1]]

  } else if(i%%12 == 4){
    pred_rcm1_3p[[i]] = (par_apl3[[2]] * ratio[[i]])+ par_apl3[[1]]

  } else if(i%%12 == 5){
    pred_rcm1_3p[[i]] = (par_may3[[2]] * ratio[[i]])+ par_may3[[1]]

  } else if(i%%12 == 6){
    pred_rcm1_3p[[i]] = (par_jun3[[2]] * ratio[[i]])+ par_jun3[[1]]

  } else if(i%%12 == 7){
    pred_rcm1_3p[[i]] = (par_jul3[[2]] * ratio[[i]])+ par_jul3[[1]]

  } else if(i%%12 == 8){
    pred_rcm1_3p[[i]] = (par_aug3[[2]] * ratio[[i]])+ par_aug3[[1]]

  } else if(i%%12 == 9){
    pred_rcm1_3p[[i]] = (par_sep3[[2]] * ratio[[i]])+ par_sep3[[1]]

  } else if(i%%12 == 10){
    pred_rcm1_3p[[i]] = (par_oct3[[2]] * ratio[[i]])+ par_oct3[[1]]

  } else if(i%%12 == 11){
    pred_rcm1_3p[[i]] = (par_nov3[[2]] * ratio[[i]])+ par_nov3[[1]]

  } else if(i%%12 == 0){
    pred_rcm1_3p[[i]] = (par_dec3[[2]] * ratio[[i]])+ par_dec3[[1]]

  }  else {
    NULL
  }

}

pred_rcm1_2p = list();
for (i in 1:432){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  
  if(i%%12 == 1){
    pred_rcm1_2p[[i]] = (par_jan3_nonl[[2]] * xx_p3_bias[[i]])+ par_jan3_nonl[[1]]
    
  } else if(i%%12 == 2){
    pred_rcm1_2p[[i]] = (par_feb3_nonl[[2]] * xx_p3_bias[[i]])+ par_feb3_nonl[[1]]
    
  } else if(i%%12 == 3){
    pred_rcm1_2p[[i]] = (par_mar3_nonl[[2]] * xx_p3_bias[[i]])+ par_mar3_nonl[[1]]
    
  } else if(i%%12 == 4){
    pred_rcm1_2p[[i]] = (par_apl3_nonl[[2]] * xx_p3_bias[[i]])+ par_apl3_nonl[[1]]
    
  } else if(i%%12 == 5){
    pred_rcm1_2p[[i]] = (par_may3_nonl[[2]] * xx_p3_bias[[i]])+ par_may3_nonl[[1]]
    
  } else if(i%%12 == 6){
    pred_rcm1_2p[[i]] = (par_jun3_nonl[[2]] * xx_p3_bias[[i]])+ par_jun3_nonl[[1]]
    
  } else if(i%%12 == 7){
    pred_rcm1_2p[[i]] = (par_jul3_nonl[[2]] * xx_p3_bias[[i]])+ par_jul3_nonl[[1]]
    
  } else if(i%%12 == 8){
    pred_rcm1_2p[[i]] = (par_aug3_nonl[[2]] * xx_p3_bias[[i]])+ par_aug3_nonl[[1]]
    
  } else if(i%%12 == 9){
    pred_rcm1_2p[[i]] = (par_sep3_nonl[[2]] * xx_p3_bias[[i]])+ par_sep3_nonl[[1]]
    
  } else if(i%%12 == 10){
    pred_rcm1_2p[[i]] = (par_oct3_nonl[[2]] * xx_p3_bias[[i]])+ par_oct3_nonl[[1]]
    
  } else if(i%%12 == 11){
    pred_rcm1_2p[[i]] = (par_nov3_nonl[[2]] * xx_p3_bias[[i]])+ par_nov3_nonl[[1]]
    
  } else if(i%%12 == 0){
    pred_rcm1_2p[[i]] = (par_dec3_nonl[[2]] * xx_p3_bias[[i]])+ par_dec3_nonl[[1]]
    
  }  else {
    NULL
  }
  
}
# for (i in 1:432){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
#   if(i%%12 == 1){
#     pred_rcm1_2p[[i]] = (par_jan3_nonl[[2]] * xx_p3_bias[[i]])+ par_jan3_nonl[[1]]
#     
#   } else if(i%%12 == 2){
#     pred_rcm1_2p[[i]] = (par_feb3_nonl[[2]] * xx_p3_bias[[i]])+ par_feb3_nonl[[1]]
#     
#   } else if(i%%12 == 3){
#     pred_rcm1_2p[[i]] = (par_mar3_nonl[[2]] * xx_p3_bias[[i]])+ par_mar3_nonl[[1]]
#     
#   } else if(i%%12 == 4){
#     pred_rcm1_2p[[i]] = (par_apl3_nonl[[2]] * xx_p3_bias[[i]])+ par_apl3_nonl[[1]]
#     
#   } else if(i%%12 == 5){
#     pred_rcm1_2p[[i]] = (par_may3_nonl[[2]] * xx_p3_bias[[i]])+ par_may3_nonl[[1]]
#     
#   } else if(i%%12 == 6){
#     pred_rcm1_2p[[i]] = (par_jun3_nonl[[2]] * xx_p3_bias[[i]])+ par_jun3_nonl[[1]]
#     
#   } else if(i%%12 == 7){
#     pred_rcm1_2p[[i]] = (par_jul3_nonl[[2]] * xx_p3_bias[[i]])+ par_jul3_nonl[[1]]
#     
#   } else if(i%%12 == 8){
#     pred_rcm1_2p[[i]] = (par_aug3_nonl[[2]] * xx_p3_bias[[i]])+ par_aug3_nonl[[1]]
#     
#   } else if(i%%12 == 9){
#     pred_rcm1_2p[[i]] = (par_sep3_nonl[[2]] * xx_p3_bias[[i]])+ par_sep3_nonl[[1]]
#     
#   } else if(i%%12 == 10){
#     pred_rcm1_2p[[i]] = (par_oct3_nonl[[2]] * xx_p3_bias[[i]])+ par_oct3_nonl[[1]]
#     
#   } else if(i%%12 == 11){
#     pred_rcm1_2p[[i]] = (par_nov3_nonl[[2]] * xx_p3_bias[[i]])+ par_nov3_nonl[[1]]
#     
#   } else if(i%%12 == 0){
#     pred_rcm1_2p[[i]] = (par_dec3_nonl[[2]] * xx_p3_bias[[i]])+ par_dec3_nonl[[1]]
#     
#   }  else {
#     NULL
#   }
#   
# }

# rcm_f85 =list()
# 
# for (i in 1:360){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   
#   if(i%%12 == 1){
#     rcm_f85[[i]] = (par_jan2[[3]] * st_lr1_jan1[[1]])+(par_jan2[[2]] * month_rcm_f85_r[[i]])+ par_jan2[[1]]
#     
#   } else if(i%%12 == 2){
#     rcm_f85[[i]] = (par_feb2[[3]] * st_lr1_feb1[[1]])+(par_feb2[[2]] * month_rcm_f85_r[[i]])+ par_feb2[[1]]
#     
#   } else if(i%%12 == 3){
#     rcm_f85[[i]] = (par_mar2[[3]] * st_lr1_mar1[[1]])+(par_mar2[[2]] * month_rcm_f85_r[[i]])+ par_mar2[[1]]
#     
#   } else if(i%%12 == 4){
#     rcm_f85[[i]] = (par_apl2[[3]] * st_lr1_apl1[[1]])+(par_apl2[[2]] * month_rcm_f85_r[[i]])+ par_apl2[[1]]
#     
#   } else if(i%%12 == 5){
#     rcm_f85[[i]] = (par_may2[[3]] * st_lr1_may1[[1]])+(par_may2[[2]] * month_rcm_f85_r[[i]])+ par_may2[[1]]
#     
#   } else if(i%%12 == 6){
#     rcm_f85[[i]] = (par_jun2[[3]] * st_lr1_jun1[[1]])+(par_jun2[[2]] * month_rcm_f85_r[[i]])+ par_jun2[[1]]
#     
#   } else if(i%%12 == 7){
#     rcm_f85[[i]] = (par_jul2[[3]] * st_lr1_jul1[[1]])+(par_jul2[[2]] * month_rcm_f85_r[[i]])+ par_jul2[[1]]
#     
#   } else if(i%%12 == 8){
#     rcm_f85[[i]] = (par_aug2[[3]] * st_lr1_aug1[[1]])+(par_aug2[[2]] * month_rcm_f85_r[[i]])+ par_aug2[[1]]
#     
#   } else if(i%%12 == 9){
#     rcm_f85[[i]] = (par_sep2[[3]] * st_lr1_sep1[[1]])+(par_sep2[[2]] * month_rcm_f85_r[[i]])+ par_sep2[[1]]
#     
#   } else if(i%%12 == 10){
#     rcm_f85[[i]] = (par_oct2[[3]] * st_lr1_oct1[[1]])+(par_oct2[[2]] * month_rcm_f85_r[[i]])+ par_oct2[[1]]
#     
#   } else if(i%%12 == 11){
#     rcm_f85[[i]] = (par_nov2[[3]] * st_lr1_nov1[[1]])+(par_nov2[[2]] * month_rcm_f85_r[[i]])+ par_nov2[[1]]
#     
#   } else if(i%%12 == 0){
#     rcm_f85[[i]] = (par_dec2[[3]] * st_lr1_dec1[[1]])+(par_dec2[[2]] * month_rcm_f85_r[[i]])+ par_dec2[[1]]
#     
#   }  else {
#     NULL
#   }
#   
# }

pred_rcm1_2p_s = stack(pred_rcm1_2p[241:432])
pred_rcm1_3p_s = stack(pred_rcm1_3p[241:432])

# pred_rcm1_2p_s1 = stack(pred_rcm1_2p_s[[jan[1:16]]])
# pred_rcm1_3p_s1 = stack(pred_rcm1_3p_s[[jan[1:16]]])


pred_rcm1_3p_s[pred_rcm1_3p_s<0] = 0

yy_p3_v = yy_p3[[241:432]]
xx_p3_bias_v = xx_p3_bias[[241:432]]

# yy_p3_v1 = yy_p3_v[[jan[1:16]]]
# xx_p3_bias_v1 = xx_p3_bias_v[[jan[1:16]]]


stat_ras_bl_p1_n1 = stack(yy_p3_v, xx_p3_bias_v)
stat_ras_2p_p1_n1 = stack(yy_p3_v, pred_rcm1_2p_s)
stat_ras_3p_p1_n1= stack(yy_p3_v, pred_rcm1_3p_s)

# stat_ras_bl_p1_n1 = stack(yy_p3_v1, xx_p3_bias_v1)
# stat_ras_2p_p1_n1 = stack(yy_p3_v1, pred_rcm1_2p_s1)
# stat_ras_3p_p1_n1= stack(yy_p3_v1, pred_rcm1_3p_s1)


plot(stat_ras_3p_p1_n1[[243]])

plot(stat_ras_2p_p1_n1[[243]])
# save(stat_ras_bl_p1_n1,stat_ras_2p_p1_n1,stat_ras_3p_p1_n1,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_val1_n1.RData")
# 
# save(par_jan3_nonl, par_feb3_nonl, par_mar3_nonl,
#      par_apl3_nonl,par_may3_nonl,par_jun3_nonl,
#      par_jul3_nonl,par_aug3_nonl,par_sep3_nonl,
#      par_oct3_nonl,par_nov3_nonl,par_dec3_nonl,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1_nonl.RData")




fun_mae_nolr <- function(x) {mean(abs((x[1:192] - x[193:384])))}
sd_mae_nolr <- calc(stat_ras_2p_p1_n1, fun_mae_nolr)

plot(sd_mae_nolr)

#rmse
fun_sqrt_nolr <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
sd_sqrt_nolr <- calc(stat_ras_2p_p1_n1, fun_sqrt_nolr)

plot(sd_sqrt_nolr)

#r2

rsq <- function (x) cor(x[1:192], x[193:384]) ^ 2
sd_r2_nolr <- calc(stat_ras_2p_p1_n1, rsq)
plot(sd_r2_nolr)

# function(x, y) summary(lm(y~x))$r.squared
# fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
# sd_r2 <- calc(stat_ras, fun_r2)

# function(x, y) summary(lm(y~x))$r.squared
# fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
# sd_r2 <- calc(stat_ras, fun_r2)
# 
# plot(sd_r2)

fun_mae <- function(x) {mean(abs((x[1:192] - x[193:384])))}
sd_mae <- calc(stat_ras_3p_p1_n1, fun_mae)

plot(sd_mae)

#rmse
fun_sqrt <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
sd_sqrt <- calc(stat_ras_3p_p1_n1, fun_sqrt)

plot(sd_sqrt)


rsq_3p <- function (x) cor(x[1:192], x[193:384]) ^ 2
sd_r2 <- calc(stat_ras_3p_p1_n1, rsq_3p)
plot(sd_r2)


#bilinear
fun_mae_bl <- function(x) {mean(abs((x[1:192] - x[193:384])))}
sd_mae_bl <- calc(stat_ras_bl_p1_n1, fun_mae_bl)

plot(sd_mae_bl)

#rmse
fun_sqrt_bl <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
sd_sqrt_bl <- calc(stat_ras_bl_p1_n1, fun_sqrt_bl)

plot(sd_sqrt_bl)

a = (sd_r2-sd_r2_nolr)/sd_r2_nolr
a[a<0.0]=NA

plot(a)


plot(((sd_sqrt-sd_sqrt_nolr)/sd_sqrt_nolr))
plot(((sd_r2-sd_r2_nolr)/sd_r2_nolr))

plot(dem_m_p1[[1]])
aa = ((sd_sqrt-sd_sqrt_nolr)/sd_sqrt_nolr)

aa[aa>0.02]=NA

plot(aa)


#r2

# function(x, y) summary(lm(y~x))$r.squared
fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
sd_r2 <- calc(stat_ras_2p, fun_r2)




plot(rcm_f85[[3250]])
plot(month_rcm_f85_r[[350]])



# for (i in 1:360){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   month_rcm_f26_r[[i]] = resample(rcm_f26[[i]],r3,'bilinear')
# }
# 
# for (i in 1:360){
#   #241:432
#   print(i)
#   # month_rcm_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # month_ap_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#   month_rcm_f85_r[[i]] = resample(rcm_f85[[i]],r3,'bilinear')
# }



#calcualte seaon avg
rcm_f26_mjj = rcm_f26_s[[f_mjj]]
rcm_f26_aso = rcm_f26_s[[f_aso]]
rcm_f26_ndjfma = rcm_f26_s[[f_ndjfma]]

rcm_f26_mjj1 <- calc(rcm_f26_mjj, fun = mean)
rcm_f26_aso1 <- calc(rcm_f26_aso, fun = mean)
rcm_f26_ndjfma1 <- calc(rcm_f26_ndjfma, fun = mean)

rcm_f85_mjj = rcm_f85_s[[f_mjj]]
rcm_f85_aso = rcm_f85_s[[f_aso]]
rcm_f85_ndjfma = rcm_f85_s[[f_ndjfma]]

rcm_f85_mjj1 <- calc(rcm_f85_mjj, fun = mean)
rcm_f85_aso1 <- calc(rcm_f85_aso, fun = mean)
rcm_f85_ndjfma1 <- calc(rcm_f85_ndjfma, fun = mean)


#apv
ap_mjj = month_ap_r[[b_mjj]]
ap_aso = month_ap_r[[b_aso]]
ap_ndjfma = month_ap_r[[b_ndjfma]]

ap_mjj1 <- calc(ap_mjj, fun = mean)
ap_aso1 <- calc(ap_aso, fun = mean)
ap_ndjfma1 <- calc(ap_ndjfma, fun = mean)

plot(ap_mjj1)


# ggplot() + geom_polygon(data = fishnet2, aes(x = long, y = lat, group = group), colour = "black", fill = NA)


dem_wp <- rasterToPoints(dem_w)
#Make the points a dataframe for ggplot
df <- data.frame(dem_wp)

#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
ap1=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_path(data = fishnet2_df, 
            aes(x = long, y = lat, group = group),
            color = 'black', fill = 'white', size = .5)+
  # geom_sf(data = fishnet1, fill = NA, colour = "blue", size = 0.25)+
  # geom_sf(data = basin_p)+
  ggtitle("Step 1: Apply 5 X 5 moving window on DEM") +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'DEM (m)')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  scale_fill_gradientn(colours = terrain.colors(10))+
  # geom_polygon(data = fishnet2, aes(x = long, y = lat, group = group), colour = "black", fill = NA)+


  # coord_sf()+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
  # geom_polygon(data = fishnet1)
# ap1_1 = ap1+geom_polygon(data = fishnet1, aes(x = long, y = lat, group = group), colour = "black", fill = NA)+
ap1


library(grid)
ap_wp <- rasterToPoints(ap_w)
#Make the points a dataframe for ggplot
df <- data.frame(ap_wp)

#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
ap2=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_path(data = fishnet2_df, 
            aes(x = long, y = lat, group = group),
            color = 'black', fill = 'white', size = .5)+
  # geom_sf(data = basin_p)+
  ggtitle("Step 2: Apply 5 X 5 moving window on Aphrodite data") +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'Precipitation (mm)')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  scale_fill_gradientn(colours = heat.colors(10),limits=c(0,70))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
ap2

gcm_wp <- rasterToPoints(gcm_w)
#Make the points a dataframe for ggplot
df <- data.frame(gcm_wp)

#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
ap3=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_path(data = fishnet2_df, 
            aes(x = long, y = lat, group = group),
            color = 'black', fill = 'white', size = .5)+
  # geom_sf(data = basin_p)+
  ggtitle("Step 2: Apply 5 X 5 moving window on GCM data") +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'Precipitation(mm)')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  scale_fill_gradientn(colours = heat.colors(10),limits=c(0,70))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_blank(),
        axis.title.y = element_text(size=10),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
ap3

lr_ap_wp <- rasterToPoints(lr_ap_w)
#Make the points a dataframe for ggplot
df <- data.frame(lr_ap_wp)

#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
ap4=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_path(data = fishnet2_df, 
            aes(x = long, y = lat, group = group),
            color = 'black', fill = 'white', size = .5)+
  # geom_sf(data = basin_p)+
  ggtitle("Step 4: Create lapse rate layer from slope values") +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'Lapse rate (mm/m)')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-0.05,0.05))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
ap4

lr_gcm_wp <- rasterToPoints(lr_gcm_w)
#Make the points a dataframe for ggplot
df <- data.frame(lr_gcm_wp)

#Make appropriate column headings
colnames(df) <- c("Longitude", "Latitude", "MAP")
# b.dem <- seq(min(df$MAP),max(df$MAP),length.out=100)
ap5=ggplot(data=df, aes(y=Latitude, x=Longitude)) +
  geom_raster(aes(fill=MAP)) +
  geom_path(data = fishnet2_df, 
            aes(x = long, y = lat, group = group),
            color = 'black', fill = 'white', size = .5)+
  # geom_sf(data = basin_p)+
  ggtitle("Step 4: Create lapse rate layer from slope values") +
  xlab("Longitude") +
  ylab("Latitude") +
  labs(fill= 'Lapse rate (mm/m)')+
  
  # scale_y_continuous(breaks = seq(25, 50, len = 3)) +
  
  # geom_point(data=sites, aes(x=x, y=y), color="white", size=3, shape=4) +
  theme_bw() +
  scale_fill_gradientn(colours = topo.colors(10),limits=c(-0.05,0.05))+
  # coord_equal() +
  # scale_fill_gradientn(name="Altitude",colours = rainbow(20),
  #                      "MAP (mm/yr)", 
  #                      limits=c(-300,500)) +
  # geom_tile(aes(Longitude,Latitude,alpha=MAP), fill = "grey20") 
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_text(size=10), 
        legend.text=element_text(size=10),
        legend.position = "right",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )
ap5


f1 = ggplot(data1, aes(x = data1[,1], y = data1[,2])) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Altitude (m)",
    y = "Precipitation (mm)",
    # color = "Gear",
    title = "Step 3: Extract 5 X 5 window values from\nAphrodite-DEM data and fit linear regression model"
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  # xlim(0,1)+
  # ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)
f1
f2 = f1+annotate(geom="text", x=2400, y=65, label = paste("Slope = Lapse rate = ", round(ap_slope, digits = 3),"mm/m"), size=3)

f2

f3 = ggplot(data1, aes(x = data2[,1], y = data2[,2])) +
  geom_point(size=3)+
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1) +
  labs(
    x = "Altitude (m)",
    y = "Precipitation (mm)",
    # color = "Gear",
    title = "Step 3: Extract 5 X 5 window values from\nGCM-DEM data and fit linear regression model"
    # fit linear regression model and assign slope values as lapse rates",
    # subtitle = "Relationship break down by gear class",
    # caption = "Authors own computation"
  ) +
  # xlim(0,1)+
  # ylim(0,1)+
  theme_bw()+
  
  theme(axis.title.x = element_text(size=10),
        axis.title.y = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        # panel.grid.major = element_blank(),
        # panel.grid.minor = element_blank(),
        legend.position = "",
        legend.key = element_blank(),
        plot.title = element_text(size=8)
  )+
  # coord_equal() +
  geom_abline(intercept = 0, slope = 1)
f3
f4 = f3+annotate(geom="text", x=2400, y=60, label = paste("Slope = Lapse rate = ", round(gcm_slope, digits = 3),"mm/m"), size=3)

f4


memory.limit(size=56000)
library(patchwork)
combined2 = ap1 + ap1 + ap2 + ap3 + f2 + f4 + ap4 + ap5
combined3 = combined2 + plot_layout(ncol = 2, guides = "collect")
combined3

path1 = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/maps/New folder/new_maps/save/"

ggsave(filename="method.tiff", plot=combined3, path=path1, dpi=300)
ggsave(filename="lapse_rate2_temp.tiff", plot=combined3, path=path1, dpi=300)

#------------sample extraction


pred_rcm1_2p_s = stack(pred_rcm1_2p[241:432])
pred_rcm1_3p_s = stack(pred_rcm1_3p[241:432])

# pred_rcm1_2p_s1 = stack(pred_rcm1_2p_s[[jan[1:16]]])
# pred_rcm1_3p_s1 = stack(pred_rcm1_3p_s[[jan[1:16]]])


pred_rcm1_3p_s[pred_rcm1_3p_s<0] = 0

yy_p3_v = yy_p3[[241:432]]
xx_p3_bias_v = xx_p3_bias[[241:432]]

# yy_p3_v1 = yy_p3_v[[jan[1:16]]]
# xx_p3_bias_v1 = xx_p3_bias_v[[jan[1:16]]]


stat_ras_bl_p1_n1 = stack(yy_p3_v, xx_p3_bias_v)
stat_ras_2p_p1_n1 = stack(yy_p3_v, pred_rcm1_2p_s)
stat_ras_3p_p1_n1= stack(yy_p3_v, pred_rcm1_3p_s)

ap_sam = extract(yy_p3_v,sam)

save(stat_ras_bl_p1_n1, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_bl_p10_n1.RData")
save(stat_ras_2p_p1_n1, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_2p_p10_n1.RData")
save(stat_ras_3p_p1_n1, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_3p_p10_n1.RData")


save(param2p, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/param_2p_p10_n1.RData")
save(param3p, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/param_3p_p10_n1.RData")


lr_y_p10 = stack(lp_y_jan1,lp_y_feb1,lp_y_mar1,lp_y_apl1,lp_y_may1,lp_y_jun1,lp_y_jul1,lp_y_aug1,
                lp_y_sep1,lp_y_oct1,lp_y_nov1,lp_y_dec1)

lr_x_p10 = stack(lp_x_jan1,lp_x_feb1,lp_x_mar1,lp_x_apl1,lp_x_may1,lp_x_jun1,lp_x_jul1,lp_x_aug1,
                lp_x_sep1,lp_x_oct1,lp_x_nov1,lp_x_dec1)

lr_p10 = stack(jan_lr,feb_lr,mar_lr,apl_lr,may_lr,jun_lr,jul_lr,aug_lr,sep_lr,oct_lr,nov_lr,
              dec_lr)


# ap_sam = extract(yy_p3_v,sam)

# save(stat_ras_bl_p1_n1, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_bl_p2_n1.RData")
# save(stat_ras_2p_p1_n1, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_2p_p2_n1.RData")
# save(stat_ras_3p_p1_n1, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_3p_p2_n1.RData")
# save(stat_ras_bias_p2_n1, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/stat_ras_bias_p2_n1.RData")
# 
# save(param2p, file = "F:/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/param_2p_p2_n1.RData")

param3p_p10=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
                 par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])

save(param3p_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/param_3p_p10.RData")
save(lr_y_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_y_p10.RData")
save(lr_x_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_x_p10.RData")
save(lr_p10, file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/ma/lr_p10.RData")



